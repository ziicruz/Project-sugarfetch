# Project Sugar - System Documentation

## 1. Technical Architecture

Project Sugar is structured as a decoupled full-stack application. It consists of a React-based frontend client intended for customers and administrators, and a Node.js/Express REST API backend managing the business logic and database operations.

### Frontend (`Project_Sugar`)
- **Core:** React, Vite, TypeScript
- **Data Fetching:** TanStack React Query (`@tanstack/react-query`)
- **UI Components:** Radix UI primitives (shadcn/ui elements), Material-UI (`@mui/material`), & Lucide React for iconography.
- **Styling:** Tailwind CSS (utility-first CSS)
- **Deployment:** Vercel (configured via `vercel.json`)

### Backend (`Sugar_api`)
- **Environment:** Node.js, Express.js (`^5.2.1`), TypeScript
- **Database:** MongoDB paired with Mongoose object modeling (`^9.3.0`)
- **Authentication:** JSON Web Tokens (JWT) for stateless sessions and Argon2 for robust password hashing.
- **Infrastructure:** Dockerized setup (`Dockerfile`) with Multer for handling file uploads (e.g., payment receipts).
- **Security & Logging:** CORS middleware for cross-origin management, Morgan for HTTP request logging.

---

## 2. Development Plan

### Phase 1: Project Initialization & Infrastructure Setup
- Set up monorepo/multi-repo structure.
- Scaffold React UI with Vite and shadcn/ui.
- Setup Express app, configure MongoDB connection, and initialize basic routing.

### Phase 2: Identity & Access Management
- Develop the user models covering `Customer`, `Admin`, and `SuperAdmin`.
- Implement JWT-based authentication and secure role-based middleware logic (e.g., `requireSuperAdmin.ts`).
- Setup Argon2 hashing for credentials storage.

### Phase 3: Core Application Features
- **Menu System:** Develop endpoints and UI to list, add, edit, and organize menu items. Focus on categories like Frappes, Milktea, etc.
- **Checkout & Cart:** Implement `CartContext` on the frontend, integrating QR scanning capabilities and building the checkout flow.
- **Payment Verification:** Build out the payment upload endpoints and Admin verification modals.

### Phase 4: Operations & Analytics
- **Order Management:** Build real-time or polled tracking pages, and admin order fulfillment screens.
- **Inventory:** Connect menu orders to inventory schema so stock automatically depletes. Develop low stock indicators. 
- **Z-Read & Analytics:** SuperAdmin views to aggregate sales data, generate Z-reads, and view shop performance metrics.

### Phase 5: Polish & Deployment
- Full integration testing and UI refinement.
- Dockerizing the backend services for reproducible builds.
- Final deployment: Vercel for the frontend, AWS/Render for the backend.

---

## 3. Security Measures

- **Password Hashing:** Utilizing **Argon2**, one of the most secure and modern hashing algorithms, safeguarding against brute-force and rainbow table attacks.
- **Stateless Authentication:** Using **JWT Tokens** ensuring the server doesn't maintain session state, while tokens are kept with expiry limits.
- **Role-Based Access Control (RBAC):** Strict middleware implementation restricting sensitive endpoints to `Admin` and `SuperAdmin` users only (preventing privilege escalation).
- **CORS Protection:** Configured to only accept requests from trusted frontend domain(s).
- **Environment Variables:** Secrets (DB URIs, JWT secrets) are managed strictly outside of version control via `.env` files.
- **Input Validation:** Employing robust schemas on the APIs to sanitize incoming payloads and avoid NoSQL injection or malformed data attacks.
- **Secure File Uploads:** Uploaded payment receipts are isolated in an `uploads/` directory with specific routing checks to prevent arbitrary code execution via file endpoints.

---

## 4. Roadmap

**Q1: MVP Launch (Minimum Viable Product)**
- [x] Basic UI structure and navigation.
- [x] Database schemas definitions and testing.
- [x] Customer cart flow and Menu generation.
- [ ] Stabilize API-Frontend connections for ordering and payment receipt upload.

**Q2: Operational Stability & Admin Tools**
- [ ] Full release of Admin UI for order management.
- [ ] End-to-end payment status flow (Pending -> Verified -> Preparing -> Complete).
- [ ] Inventory depletion logic integration.
- [ ] SuperAdmin user management tools.

**Q3: Analytics & Advanced Features**
- [ ] Advanced sales analytics parsing and visual charts for SuperAdmins.
- [ ] Inventory prediction and automatic low-stock notifications.
- [ ] Migration to fully containerized cloud-native backend deployment using Docker.

**Q4: Scaling & Customer Experience**
- [ ] WebSockets integration for live order tracking and real-time Admin notifications.
- [ ] Implementing customer loyalty accounts and rewards logic.
- [ ] Third-party payment gateway integration (e.g., PayMongo, Stripe) as an alternative to manual receipt uploads.
