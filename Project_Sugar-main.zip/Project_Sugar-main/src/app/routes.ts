import { createBrowserRouter } from 'react-router';

import { QRLanding } from './components/customer/QRLanding';
import { MenuPage } from './components/customer/MenuPage';
import { CartPage } from './components/customer/CartPage';
import { OrderConfirmation } from './components/customer/OrderConfirmation';
import { PaymentPage } from './components/customer/PaymentPage';
import { TrackingPage } from './components/customer/TrackingPage';

import { AdminLogin } from './components/admin/AdminLogin';
import { AdminLayout } from './components/admin/AdminLayout';
import { Dashboard } from './components/admin/Dashboard';
import { OrderManagement } from './components/admin/OrderManagement';
import { MenuManagement } from './components/admin/MenuManagement';
import { Analytics } from './components/admin/Analytics';

import { SuperAdminLogin } from './components/superadmin/SuperAdminLogin';
import { SuperAdminLayout } from './components/superadmin/SuperAdminLayout';
import { SuperAdminDashboard } from './components/superadmin/SuperAdminDashboard';
import { AdminManagement } from './components/superadmin/AdminManagement';
import { ZReadPage } from './components/superadmin/ZReadPage';
import { InventoryManagement as AdminInventory } from './components/admin/InventoryManagement';
import { InventoryManagement as SuperAdminInventory } from './components/superadmin/InventoryManagement';
export const router = createBrowserRouter([
  // Customer Routes
  { path: '/', Component: QRLanding },
  { path: '/menu', Component: MenuPage },
  { path: '/cart', Component: CartPage },
  { path: '/order-confirmation', Component: OrderConfirmation },
  { path: '/payment', Component: PaymentPage },
  { path: '/tracking', Component: TrackingPage },

  // Admin Routes
  { path: '/admin', Component: AdminLogin },
  {
    path: '/admin',
    Component: AdminLayout,
    children: [
      { path: 'dashboard', Component: Dashboard },
      { path: 'orders', Component: OrderManagement },
      { path: 'menu-management', Component: MenuManagement },
      { path: 'analytics', Component: Analytics },
      { path: 'inventory', Component: AdminInventory },
    ],
  },

  // Super Admin Routes
  { path: '/super-admin', Component: SuperAdminLogin },
  {
    path: '/super-admin',
    Component: SuperAdminLayout,
    children: [
      { path: 'dashboard', Component: SuperAdminDashboard },
      { path: 'admins', Component: AdminManagement },
      { path: 'z-read', Component: ZReadPage },
      { path: 'inventory', Component: SuperAdminInventory },
    ],
  },
]);
