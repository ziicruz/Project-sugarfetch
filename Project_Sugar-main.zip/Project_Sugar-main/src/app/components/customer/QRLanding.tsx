import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Coffee, MapPin } from 'lucide-react';
import { motion } from 'motion/react';

const floatingBeans = [
  { x: '10%', y: '15%', size: 5, delay: 0, rotate: 25 },
  { x: '85%', y: '20%', size: 4, delay: 0.6, rotate: -30 },
  { x: '15%', y: '75%', size: 6, delay: 1.2, rotate: 45 },
  { x: '80%', y: '70%', size: 4, delay: 0.3, rotate: -20 },
  { x: '50%', y: '10%', size: 3, delay: 0.9, rotate: 60 },
  { x: '92%', y: '50%', size: 5, delay: 1.5, rotate: -45 },
];

export function QRLanding() {
  const navigate = useNavigate();
  const [customerName, setCustomerName] = useState('');

  return (
    <div className="min-h-screen bg-[#FAFAF8] flex flex-col items-center justify-center px-6 py-12 relative overflow-hidden">
      {/* Floating coffee beans */}
      {floatingBeans.map((bean, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full bg-[#78553B]"
          style={{
            left: bean.x,
            top: bean.y,
            width: bean.size,
            height: bean.size,
            rotate: bean.rotate,
          }}
          animate={{
            y: [0, -10, 0],
            opacity: [0.06, 0.14, 0.06],
            rotate: [bean.rotate, bean.rotate + 30, bean.rotate],
          }}
          transition={{
            duration: 3.5,
            repeat: Infinity,
            delay: bean.delay,
            ease: 'easeInOut',
          }}
        />
      ))}

      {/* Subtle coffee ring background */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[320px] h-[320px] rounded-full pointer-events-none"
        style={{
          border: '1px solid rgba(120,85,59,0.04)',
          boxShadow: '0 0 60px rgba(120,85,59,0.03)',
        }}
      />
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[420px] h-[420px] rounded-full pointer-events-none"
        style={{
          border: '1px solid rgba(120,85,59,0.025)',
        }}
      />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-sm flex flex-col items-center gap-8 relative z-10"
      >
        {/* Logo with steam */}
        <div className="relative">
          <img src='Sugar.jpg' alt="Sugar Cafe" className="w-32 h-32 object-contain" />
          {/* Steam above logo */}
          <div className="absolute -top-4 left-1/2 -translate-x-1/2 flex gap-2">
            {[0, 1, 2].map(i => (
              <motion.div
                key={i}
                className="w-1 rounded-full bg-[#D4854A]/20"
                style={{ height: 8 }}
                animate={{
                  y: [-2, -16, -28],
                  x: [0, i % 2 === 0 ? 3 : -3, i % 2 === 0 ? -2 : 2],
                  opacity: [0, 0.4, 0],
                  scale: [0.5, 1, 1.3],
                }}
                transition={{
                  duration: 1.8,
                  repeat: Infinity,
                  delay: i * 0.35,
                  ease: 'easeOut',
                }}
              />
            ))}
          </div>
        </div>

        <div className="text-center space-y-1.5">
          <h1 className="text-[#1C1917] tracking-tight">Welcome to Sugar Cafe</h1>
          <p className="text-[#7C6E65] flex items-center justify-center gap-1.5">
            Scan, Order, Enjoy
            <Coffee className="w-3.5 h-3.5 text-[#D4854A]" />
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] border border-[rgba(0,0,0,0.04)] p-5 w-full text-center space-y-3">
          <div className="flex items-center justify-center gap-2 text-[#78553B]">
            <MapPin className="w-4 h-4" />
          </div>
          <div className="h-px bg-[rgba(0,0,0,0.05)]" />
          <div className="text-left">
            <label className="block text-xs text-[#A8A29E] mb-1.5">Customer Name</label>
            <input
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder="Enter your name"
              className="w-full border border-[rgba(0,0,0,0.08)] rounded-lg px-3 py-2.5 text-sm text-[#1C1917] focus:outline-none focus:ring-2 focus:ring-[#78553B]/20"
            />
          </div>
          <p className="text-[#7C6E65] text-sm">Your order will be served to your table</p>
        </div>

        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={() => {
            const normalizedName = customerName.trim();
            if (!normalizedName) return;
            document.cookie = `customer_name=${encodeURIComponent(normalizedName)}; Path=/; Max-Age=${60 * 60 * 24}; SameSite=Strict`;
            navigate('/menu');
          }}
          disabled={!customerName.trim()}
          className="w-full bg-[#78553B] hover:bg-[#5F432E] disabled:bg-[#C7BBB1] disabled:cursor-not-allowed text-white py-3.5 rounded-xl flex items-center justify-center gap-2.5 transition-colors shadow-[0_1px_2px_rgba(0,0,0,0.05)]"
        >
          <Coffee className="w-5 h-5" />
          Browse Menu
        </motion.button>

        <p className="text-[#A8A29E] text-xs text-center">Powered by SugarFETCH POS</p>
      </motion.div>
    </div>
  );
}
