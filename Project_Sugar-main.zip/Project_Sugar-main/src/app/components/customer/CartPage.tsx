import { useNavigate } from 'react-router';
import { ArrowLeft, Minus, Plus, Trash2, Coffee, Flame, Snowflake } from 'lucide-react';
import { motion } from 'motion/react';
import { useCart } from '../../context/CartContext';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { getItemTemperature } from './AddToCartFeedback';

export function CartPage() {
  const { cart, updateQuantity, removeFromCart, total, itemCount } = useCart();
  const navigate = useNavigate();
  const baseSubtotal = cart.reduce((sum, item) => sum + item.basePrice * item.quantity, 0);
  const addOnsSubtotal = cart.reduce((sum, item) => sum + (item.unitPrice - item.basePrice) * item.quantity, 0);

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-[#FAFAF8] flex flex-col items-center justify-center px-6 gap-4 relative overflow-hidden">
        {/* Floating coffee beans background */}
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full bg-[#78553B]"
            style={{
              width: 4 + Math.random() * 4,
              height: 4 + Math.random() * 4,
              left: `${15 + Math.random() * 70}%`,
              top: `${15 + Math.random() * 70}%`,
            }}
            animate={{
              y: [0, -8, 0],
              opacity: [0.06, 0.12, 0.06],
              rotate: [0, 180, 360],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: i * 0.5,
            }}
          />
        ))}

        {/* Empty coffee cup illustration */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative"
        >
          <div className="w-20 h-20 rounded-2xl bg-[#F5F0EB] flex items-center justify-center relative">
            <Coffee className="w-8 h-8 text-[#A8A29E]" />
            {/* Empty steam - faint */}
            <motion.div
              className="absolute -top-3 left-1/2 -translate-x-1/2 w-1 h-3 rounded-full bg-[#D4854A]/20"
              animate={{ y: [-2, -8], opacity: [0.2, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
          </div>
        </motion.div>
        <h2 className="text-[#1C1917]">Your cup is empty</h2>
        <p className="text-[#7C6E65] text-center text-sm">Let's brew something delicious for you</p>
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={() => navigate('/menu')}
          className="bg-[#1C1917] text-white px-6 py-3 rounded-xl mt-2 flex items-center gap-2"
        >
          <Coffee className="w-4 h-4" />
          Browse Menu
        </motion.button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAF8] pb-44">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-[#FAFAF8]/80 backdrop-blur-xl border-b border-[rgba(0,0,0,0.04)] px-4 py-3.5 flex items-center gap-3">
        <button onClick={() => navigate('/menu')} className="p-2 rounded-lg bg-white border border-[rgba(0,0,0,0.06)] hover:border-[rgba(0,0,0,0.12)] transition-colors">
          <ArrowLeft className="w-4 h-4 text-[#1C1917]" />
        </button>
        <div className="flex items-center gap-2">
          <h2 className="text-[#1C1917] tracking-tight">Your Order</h2>
          <Coffee className="w-4 h-4 text-[#D4854A]" />
        </div>
        <span className="ml-auto text-[#A8A29E] text-sm">{itemCount} items</span>
      </div>

      <div className="px-4 pt-3">
        <button
          onClick={() => navigate('/menu')}
          className="w-full bg-white border border-[rgba(0,0,0,0.08)] rounded-xl py-2.5 text-sm text-[#5F432E] hover:bg-[#F5F0EB] transition-colors"
        >
          + Add More Orders
        </button>
      </div>

      {/* Items */}
      <div className="px-4 pt-3 space-y-2.5">
        {cart.map(item => {
          const temp = getItemTemperature(item.name, item.category);
          return (
            <motion.div
              key={item.cartItemId}
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-xl p-3 flex gap-3 shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)] relative overflow-hidden"
            >
              {/* Subtle temperature accent line on left */}
              <div
                className={`absolute left-0 top-0 bottom-0 w-[3px] rounded-l-xl ${
                  temp === 'hot'
                    ? 'bg-gradient-to-b from-orange-400 to-orange-300'
                    : temp === 'cold'
                    ? 'bg-gradient-to-b from-sky-400 to-sky-300'
                    : 'bg-gradient-to-b from-[#D4854A] to-[#D4854A]/50'
                }`}
              />

              <div className="relative">
                <ImageWithFallback src={item.image} alt={item.name} className="w-20 h-20 rounded-lg object-cover shrink-0" />
                {/* Temperature indicator on thumbnail */}
                {(temp === 'hot' || temp === 'cold') && (
                  <div className={`absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center ${
                    temp === 'hot' ? 'bg-orange-500' : 'bg-sky-500'
                  }`}>
                    {temp === 'hot'
                      ? <Flame className="w-2.5 h-2.5 text-white" />
                      : <Snowflake className="w-2.5 h-2.5 text-white" />
                    }
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-start">
                  <h4 className="text-[#1C1917] text-sm truncate pr-2">{item.name}</h4>
                  <button onClick={() => removeFromCart(item.cartItemId)} className="text-[#D6D3D1] hover:text-red-500 shrink-0 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="text-[#78553B] text-sm">&#8369;{item.unitPrice}</span>
                  {temp !== 'neutral' && (
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-md ${
                      temp === 'hot' ? 'bg-orange-50 text-orange-500' : 'bg-sky-50 text-sky-500'
                    }`}>
                      {temp === 'hot' ? 'Hot' : 'Iced'}
                    </span>
                  )}
                </div>
                {(item.size || item.addOns.length > 0 || item.notes) && (
                  <div className="mt-1.5 space-y-0.5">
                    {item.size && (
                      <p className="text-[11px] text-[#7C6E65]">Size: {item.size}</p>
                    )}
                    {item.addOns.length > 0 && (
                      <p className="text-[11px] text-[#7C6E65]">
                        Add-ons: {item.addOns.map((addOn) => addOn.name).join(', ')}
                      </p>
                    )}
                    {item.notes && (
                      <p className="text-[11px] text-[#7C6E65]">Note: {item.notes}</p>
                    )}
                  </div>
                )}
                <div className="flex items-center gap-2.5 mt-2">
                  <button
                    onClick={() => updateQuantity(item.cartItemId, item.quantity - 1)}
                    className="w-7 h-7 rounded-md bg-[#F5F0EB] flex items-center justify-center text-[#78553B] hover:bg-[#EDE5DC] transition-colors"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <span className="text-[#1C1917] text-sm w-4 text-center">{item.quantity}</span>
                  <button
                    onClick={() => updateQuantity(item.cartItemId, item.quantity + 1)}
                    className="w-7 h-7 rounded-md bg-[#F5F0EB] flex items-center justify-center text-[#78553B] hover:bg-[#EDE5DC] transition-colors"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                  <span className="ml-auto text-[#1C1917] text-sm">&#8369;{item.unitPrice * item.quantity}</span>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Coffee bean divider */}
      <div className="flex items-center justify-center gap-2 py-4 px-4">
        <div className="h-px flex-1 bg-[rgba(0,0,0,0.05)]" />
        <Coffee className="w-3.5 h-3.5 text-[#D6D3D1]" />
        <div className="h-px flex-1 bg-[rgba(0,0,0,0.05)]" />
      </div>

      {/* Order Summary Fixed Bottom */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[rgba(0,0,0,0.06)] p-4 space-y-3 shadow-[0_-1px_12px_rgba(0,0,0,0.04)]">
        <div className="flex justify-between text-sm text-[#7C6E65]">
          <span>Base subtotal</span>
          <span>&#8369;{baseSubtotal}</span>
        </div>
        <div className="flex justify-between text-sm text-[#7C6E65]">
          <span>Add-ons and size</span>
          <span>&#8369;{addOnsSubtotal}</span>
        </div>
        <div className="flex justify-between text-[#1C1917]">
          <span>Grand Total(inc. fees and tax)</span>
          <span className="text-xl text-[#78553B]">&#8369;{total}</span>
        </div>
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={() => navigate('/order-confirmation')}
          className="w-full bg-[#1C1917] hover:bg-[#292524] text-white py-3.5 rounded-xl transition-colors flex items-center justify-center gap-2"
        >
          <Coffee className="w-4 h-4" />
          Confirm Order
        </motion.button>
      </div>
    </div>
  );
}
