import { useMemo } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, CheckCircle, Coffee, Flame, Snowflake } from 'lucide-react';
import { motion } from 'motion/react';
import { useCart } from '../../context/CartContext';
import { getItemTemperature } from './AddToCartFeedback';

export function OrderConfirmation() {
  const { cart, total } = useCart();
  const navigate = useNavigate();
  const baseSubtotal = cart.reduce((sum, item) => sum + item.basePrice * item.quantity, 0);
  const addOnsSubtotal = cart.reduce((sum, item) => sum + (item.unitPrice - item.basePrice) * item.quantity, 0);
  const orderNumber = useMemo(
    () => `SC-${String(Math.floor(Math.random() * 9000) + 1000)}`,
    [],
  );

  return (
    <div className="min-h-screen bg-[#FAFAF8] pb-8">
      <div className="sticky top-0 z-10 bg-[#FAFAF8]/80 backdrop-blur-xl border-b border-[rgba(0,0,0,0.04)] px-4 py-3.5 flex items-center gap-3">
        <button onClick={() => navigate('/cart')} className="p-2 rounded-lg bg-white border border-[rgba(0,0,0,0.06)] hover:border-[rgba(0,0,0,0.12)] transition-colors">
          <ArrowLeft className="w-4 h-4 text-[#1C1917]" />
        </button>
        <div className="flex items-center gap-2">
          <h2 className="text-[#1C1917] tracking-tight">Order Summary</h2>
          <Coffee className="w-4 h-4 text-[#D4854A]" />
        </div>
      </div>

      <div className="px-4 pt-4 space-y-3">
        <button
          onClick={() => navigate('/menu')}
          className="w-full bg-white border border-[rgba(0,0,0,0.08)] rounded-xl py-2.5 text-sm text-[#5F432E] hover:bg-[#F5F0EB] transition-colors"
        >
          + Add More Orders
        </button>

        {/* Order Info Card */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl p-5 shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)] text-center space-y-3 relative overflow-hidden"
        >
          {/* Subtle steam background */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 flex gap-3 pointer-events-none">
            {[0, 1, 2].map(i => (
              <motion.div
                key={i}
                className="w-1 rounded-full bg-[#D4854A]/10"
                style={{ height: 8 }}
                animate={{
                  y: [-2, -20],
                  opacity: [0, 0.3, 0],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: i * 0.4,
                }}
              />
            ))}
          </div>

          <div className="w-12 h-12 rounded-full bg-emerald-50 flex items-center justify-center mx-auto">
            <CheckCircle className="w-6 h-6 text-emerald-500" />
          </div>
          <h3 className="text-[#1C1917]">Order Ready to Submit</h3>
          <div className="bg-[#F5F0EB] rounded-lg py-2 px-4 inline-flex items-center gap-2">
            <Coffee className="w-3.5 h-3.5 text-[#D4854A]" />
            <span className="text-[#7C6E65] text-sm">Order #</span>
            <span className="text-[#1C1917]">{orderNumber}</span>
          </div>
          <p className="text-[#A8A29E] text-sm">Review your order before payment</p>
        </motion.div>

        {/* Items with temperature indicators */}
        <div className="bg-white rounded-xl p-4 shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)]">
          <h4 className="text-[#1C1917] text-sm mb-3">Items</h4>
          <div className="space-y-2">
            {cart.map(item => {
              const temp = getItemTemperature(item.name, item.category);
              return (
                <div key={item.cartItemId} className="text-sm">
                  <div className="flex justify-between items-center">
                    <span className="text-[#57534E] flex items-center gap-1.5">
                      {temp === 'hot' && <Flame className="w-3 h-3 text-orange-400" />}
                      {temp === 'cold' && <Snowflake className="w-3 h-3 text-sky-400" />}
                      {item.quantity}x {item.name}
                    </span>
                    <span className="text-[#78553B]">&#8369;{item.unitPrice * item.quantity}</span>
                  </div>
                  {(item.size || item.addOns.length > 0 || item.notes) && (
                    <div className="ml-5 mt-0.5 text-[11px] text-[#8A817A] space-y-0.5">
                      {item.size && <p>Size: {item.size}</p>}
                      {item.addOns.length > 0 && <p>Add-ons: {item.addOns.map((addOn) => addOn.name).join(', ')}</p>}
                      {item.notes && <p>Note: {item.notes}</p>}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          {/* Coffee divider */}
          <div className="flex items-center gap-2 my-3">
            <div className="h-px flex-1 bg-[rgba(0,0,0,0.05)]" />
            <Coffee className="w-3 h-3 text-[#E7E5E4]" />
            <div className="h-px flex-1 bg-[rgba(0,0,0,0.05)]" />
          </div>
          <div className="space-y-1.5">
            <div className="flex justify-between text-sm text-[#7C6E65]">
              <span>Base subtotal</span>
              <span>&#8369;{baseSubtotal}</span>
            </div>
            <div className="flex justify-between text-sm text-[#7C6E65]">
              <span>Add-ons and size</span>
              <span>&#8369;{addOnsSubtotal}</span>
            </div>
            
          </div>
          <div className="flex justify-between mt-2">
            <span className="text-[#1C1917]">Grand Total(inc. fees and tax)</span>
            <span className="text-[#78553B] text-xl">&#8369;{total}</span>
          </div>
        </div>

        {/* Payment Options */}
        <div className="bg-white rounded-xl p-4 shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)]">
          <h4 className="text-[#1C1917] text-sm mb-3">Payment Method</h4>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {['GCash', 'Maya', 'Bank QR', 'Cash'].map(method => (
              <motion.button
                key={method}
                whileTap={{ scale: 0.97 }}
                onClick={() =>
                  navigate(`/payment?method=${encodeURIComponent(method)}&order=${encodeURIComponent(orderNumber)}`)
                }
                className="bg-[#F5F0EB] hover:bg-[#1C1917] hover:text-white text-[#44312A] py-3 rounded-lg text-sm transition-colors"
              >
                {method}
              </motion.button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
