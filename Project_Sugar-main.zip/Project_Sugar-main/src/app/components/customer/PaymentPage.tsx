import { useMemo, useState, type ChangeEvent } from 'react';
import { useNavigate, useSearchParams } from 'react-router';
import { ArrowLeft, Upload, CheckCircle, Coffee, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { useCart } from '../../context/CartContext';
import { useCreatePaymentMutation } from '../../../hooks/usePayment';
import type { PaymentMethod } from '../../../schema/paymentSchema';

const paymentQrMap: Record<PaymentMethod, string> = {
  GCash: '/Gcash.jpg',
  Maya: '/Maya.jpg',
  'Bank QR': '/Mari.jpg',
  Cash: '/Gcash.jpg',
};

function toPaymentMethod(value: string | null): PaymentMethod {
  if (value === 'GCash' || value === 'Maya' || value === 'Bank QR' || value === 'Cash') {
    return value;
  }
  return 'GCash';
}

function getCustomerNameFromCookie(): string {
  const token = document.cookie
    .split('; ')
    .find((cookie) => cookie.startsWith('customer_name='))
    ?.split('=')[1];
  return token ? decodeURIComponent(token) : '';
}

export function PaymentPage() {
  const [searchParams] = useSearchParams();
  const method = toPaymentMethod(searchParams.get('method'));
  const orderNumberFromQuery = searchParams.get('order') ?? '';
  const { cart, total, clearCart } = useCart();
  const navigate = useNavigate();
  const createPaymentMutation = useCreatePaymentMutation();
  const [customerName, setCustomerName] = useState(() => getCustomerNameFromCookie());
  const [paymentImage, setPaymentImage] = useState<File | null>(null);
  const [paymentImagePreview, setPaymentImagePreview] = useState('');
  const [cashTendered, setCashTendered] = useState('');
  const [localError, setLocalError] = useState('');
  const isCash = method === 'Cash';
  const baseSubtotal = useMemo(() => cart.reduce((sum, item) => sum + item.basePrice * item.quantity, 0), [cart]);
  const addOnsSubtotal = useMemo(() => cart.reduce((sum, item) => sum + (item.unitPrice - item.basePrice) * item.quantity, 0), [cart]);
  const tenderedAmount = useMemo(() => {
    const parsed = Number(cashTendered);
    return Number.isFinite(parsed) ? parsed : 0;
  }, [cashTendered]);
  const hasCashInput = cashTendered.trim().length > 0;
  const isInsufficientCash = isCash && hasCashInput && tenderedAmount < total;
  const changeAmount = isCash && hasCashInput && tenderedAmount >= total ? tenderedAmount - total : 0;
  const isSubmitDisabled =
    createPaymentMutation.isPending ||
    (!isCash && !paymentImage) ||
    (isCash && (!hasCashInput || tenderedAmount < total));

  const cartPayload = useMemo(
    () =>
      cart.map((item) => ({
        itemId: item.id,
        name: item.name,
        quantity: item.quantity,
        price: item.unitPrice,
        size: item.size,
        notes: item.notes,
        addOns: item.addOns,
        lineTotal: item.unitPrice * item.quantity,
      })),
    [cart],
  );

  const handleFileSelect = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setLocalError('Please upload an image file.');
      return;
    }
    setPaymentImage(file);
    setPaymentImagePreview(URL.createObjectURL(file));
    setLocalError('');
  };

  const handleConfirm = async () => {
    setLocalError('');
    if (!isCash && !paymentImage) {
      setLocalError('Payment proof image is required.');
      return;
    }
    if (!customerName.trim()) {
      setLocalError('Customer name is required.');
      return;
    }

    if (isCash) {
      if (!hasCashInput) {
        setLocalError('Please enter cash amount tendered.');
        return;
      }
      if (tenderedAmount < total) {
        setLocalError('Cash tendered is not enough for this order.');
        return;
      }
    }

    if (cart.length === 0) {
      setLocalError('Your cart is empty.');
      return;
    }

    try {
      const payment = await createPaymentMutation.mutateAsync({
        customerName: customerName.trim(),
        orderNumber: orderNumberFromQuery,
        paymentMethod: method,
        amount: total,
        cart: cartPayload,
        paymentImage: isCash ? null : paymentImage,
      });
      clearCart();
      navigate(`/tracking?paymentId=${encodeURIComponent(payment._id)}`);
    } catch (error) {
      // Error handled via mutation state.
    }
  };

  return (
    <div className="min-h-screen bg-[#FAFAF8] pb-8">
      <div className="sticky top-0 z-10 bg-[#FAFAF8]/80 backdrop-blur-xl border-b border-[rgba(0,0,0,0.04)] px-4 py-3.5 flex items-center gap-3">
        <button onClick={() => navigate('/order-confirmation')} className="p-2 rounded-lg bg-white border border-[rgba(0,0,0,0.06)] hover:border-[rgba(0,0,0,0.12)] transition-colors">
          <ArrowLeft className="w-4 h-4 text-[#1C1917]" />
        </button>
        <h2 className="text-[#1C1917] tracking-tight">Pay with {method}</h2>
      </div>

      <div className="px-4 pt-4 space-y-3">
        {!isCash ? (
          <>
            {/* QR Code */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-xl p-6 shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)] text-center space-y-4"
            >
              <div className="bg-[#F5F0EB] rounded-xl p-4 inline-flex flex-col items-center gap-3 relative">
                <img
                  src={paymentQrMap[method]}
                  alt={`${method} QR code`}
                  className="w-[240px] max-w-full rounded-lg border border-[rgba(0,0,0,0.08)] bg-white"
                />
                <p className="text-[#57534E] text-sm">Scan to pay via {method}</p>
                <div className="absolute -top-2 right-4 flex gap-1.5">
                  {[0, 1].map(i => (
                    <motion.div
                      key={i}
                      className="w-0.5 rounded-full bg-[#D4854A]/15"
                      style={{ height: 6 }}
                      animate={{ y: [-1, -10], opacity: [0, 0.3, 0] }}
                      transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.3 }}
                    />
                  ))}
                </div>
              </div>

              <div className="space-y-0.5">
                <p className="text-[#A8A29E] text-sm">Amount to Pay</p>
                <p className="text-[#78553B] text-3xl">&#8369;{total}</p>
              </div>
            </motion.div>

            {/* Instructions */}
            <div className="bg-white rounded-xl p-4 shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)]">
              <h4 className="text-[#1C1917] text-sm mb-2">Payment Instructions</h4>
              <ol className="text-[#7C6E65] text-sm space-y-1.5 list-decimal list-inside">
                <li>Open your {method} app</li>
                <li>Scan the QR code above</li>
                <li>Enter the exact amount: &#8369;{total}</li>
                <li>Complete the payment</li>
                <li>Upload proof of payment</li>
              </ol>
            </div>
          </>
        ) : (
          <div className="bg-white rounded-xl p-4 shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)]">
            <h4 className="text-[#1C1917] text-sm mb-2">Cash Payment</h4>
            <p className="text-sm text-[#7C6E65]">
              Please pay at the counter upon pickup. No payment proof upload is required.
            </p>
            <p className="text-[#78553B] text-xl mt-2 font-semibold">Amount Due: &#8369;{total}</p>
            <div className="mt-3 space-y-2">
              <label className="block text-xs text-[#57534E]">Cash Tendered</label>
              <input
                type="number"
                min={0}
                step={0.01}
                inputMode="decimal"
                value={cashTendered}
                onChange={(e) => {
                  setCashTendered(e.target.value);
                  if (localError) setLocalError('');
                }}
                placeholder="Enter amount received"
                className="w-full border border-[rgba(0,0,0,0.08)] rounded-lg px-3 py-2.5 text-sm text-[#1C1917]"
              />
              {hasCashInput && (
                <div className={`text-sm ${isInsufficientCash ? 'text-red-600' : 'text-emerald-600'}`}>
                  {isInsufficientCash
                    ? `Insufficient cash by ₱${(total - tenderedAmount).toFixed(2)}`
                    : `Change: ₱${changeAmount.toFixed(2)}`}
                </div>
              )}
            </div>
          </div>
        )}

        <div className="bg-white rounded-xl p-4 shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)]">
          <h4 className="text-[#1C1917] text-sm mb-2">Order Computation</h4>
          <div className="space-y-1.5 text-sm">
            <div className="flex justify-between text-[#7C6E65]">
              <span>Base subtotal</span>
              <span>₱{baseSubtotal}</span>
            </div>
            <div className="flex justify-between text-[#7C6E65]">
              <span>Add-ons and size</span>
              <span>₱{addOnsSubtotal}</span>
            </div>
            <div className="h-px bg-[rgba(0,0,0,0.07)] my-1.5" />
            <div className="flex justify-between text-[#1C1917]">
              <span>Total to pay</span>
              <span className="text-[#78553B] font-semibold">₱{total}</span>
            </div>
          </div>
        </div>

        {/* Customer + Proof */}
        <div className="bg-white rounded-xl p-4 shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)]">
          <h4 className="text-[#1C1917] text-sm mb-3">Customer Name</h4>
          <input
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            className="w-full border border-[rgba(0,0,0,0.08)] rounded-lg px-3 py-2.5 text-sm text-[#1C1917] mb-3"
            placeholder="Enter customer name"
          />

          {!isCash && (
            <>
              <h4 className="text-[#1C1917] text-sm mb-3">Upload Payment Proof</h4>
              <label
                className={`w-full py-4 rounded-lg border-2 border-dashed flex items-center justify-center gap-2 transition-all text-sm cursor-pointer ${
                  paymentImage
                    ? 'border-emerald-300 bg-emerald-50 text-emerald-600'
                    : 'border-[rgba(0,0,0,0.1)] text-[#7C6E65] hover:border-[#78553B]/40 hover:text-[#78553B]'
                }`}
              >
                <input type="file" accept="image/*" className="hidden" onChange={handleFileSelect} />
                {paymentImage ? (
                  <>
                    <CheckCircle className="w-4 h-4" />
                    Receipt uploaded: {paymentImage.name}
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4" />
                    Tap to upload screenshot
                  </>
                )}
              </label>
              {paymentImagePreview ? (
                <img
                  src={paymentImagePreview}
                  alt="Payment preview"
                  className="mt-3 w-full max-h-48 object-contain rounded-lg border border-[rgba(0,0,0,0.06)]"
                />
              ) : null}
            </>
          )}
        </div>

        {localError ? (
          <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-sm text-red-600">
            {localError}
          </div>
        ) : null}
        {createPaymentMutation.error ? (
          <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-sm text-red-600">
            {createPaymentMutation.error.message}
          </div>
        ) : null}

        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={handleConfirm}
          disabled={isSubmitDisabled}
          className={`w-full py-3.5 rounded-xl transition-colors flex items-center justify-center gap-2 ${
            isSubmitDisabled
              ? 'bg-[#E7E0D8] text-[#A8A29E] cursor-not-allowed'
              : 'bg-[#1C1917] hover:bg-[#292524] text-white'
          }`}
        >
          {createPaymentMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Coffee className="w-4 h-4" />}
          {createPaymentMutation.isPending ? 'Submitting payment...' : isCash ? 'Place Cash Order' : "I've Completed Payment"}
        </motion.button>
      </div>
    </div>
  );
}