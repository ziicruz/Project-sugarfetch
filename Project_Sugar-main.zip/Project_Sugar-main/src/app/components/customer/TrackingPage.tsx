import { useMemo } from 'react';
import { useNavigate, useSearchParams } from 'react-router';
import { CheckCircle, Clock, Coffee, ChefHat, Package, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { useTrackPaymentQuery } from '../../../hooks/usePayment';

const stages = [
  { key: 'received', label: 'Order Received', icon: CheckCircle, description: 'Your order has been received' },
  { key: 'preparing', label: 'Brewing', icon: ChefHat, description: 'Our barista is crafting your order' },
  { key: 'ready', label: 'Ready for Pickup', icon: Package, description: 'Your order is ready at the counter' },
  { key: 'completed', label: 'Enjoy!', icon: Coffee, description: 'Enjoy your freshly brewed order!' },
];

function BrewingAnimation() {
  return (
    <div className="flex items-center gap-1.5 mt-1">
      {[0, 1, 2].map(i => (
        <motion.div
          key={i}
          className="w-1.5 h-1.5 rounded-full bg-[#D4854A]"
          animate={{
            scale: [1, 1.5, 1],
            opacity: [0.4, 1, 0.4],
          }}
          transition={{
            duration: 0.8,
            repeat: Infinity,
            delay: i * 0.2,
          }}
        />
      ))}
      <span className="text-[10px] text-[#D4854A] ml-1">Brewing...</span>
    </div>
  );
}

export function TrackingPage() {
  const [searchParams] = useSearchParams();
  const paymentId = searchParams.get('paymentId');
  const { data: payment, isLoading, error } = useTrackPaymentQuery(paymentId);
  const navigate = useNavigate();

  const currentStage = useMemo(() => {
    if (!payment) return 0;
    return Math.max(0, stages.findIndex((stage) => stage.key === payment.status));
  }, [payment]);

  const estimatedTime = currentStage === 0 ? '8-10 min' : currentStage === 1 ? '3-5 min' : currentStage === 2 ? 'Now' : 'Completed';

  return (
    <div className="min-h-screen bg-[#FAFAF8] px-4 py-6 relative overflow-hidden">
      {/* Background coffee beans */}
      {[
        { x: '8%', y: '12%' },
        { x: '88%', y: '25%' },
        { x: '12%', y: '85%' },
        { x: '82%', y: '78%' },
      ].map((pos, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full bg-[#78553B]"
          style={{ left: pos.x, top: pos.y, width: 4, height: 4 }}
          animate={{ opacity: [0.04, 0.1, 0.04], y: [0, -5, 0] }}
          transition={{ duration: 3, repeat: Infinity, delay: i * 0.7 }}
        />
      ))}

      <div className="max-w-md mx-auto space-y-4 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl p-5 shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)] text-center space-y-2"
        >
          {/* Animated cup */}
          <motion.div
            animate={currentStage === 1 ? {
              rotate: [-1, 1, -1.5, 1.5, 0],
            } : {}}
            transition={{ duration: 0.6, repeat: currentStage === 1 ? Infinity : 0, repeatDelay: 1 }}
            className="inline-block"
          >
            <div className="bg-[#F5F0EB] rounded-lg py-2 px-4 inline-flex items-center gap-2">
              <Coffee className="w-4 h-4 text-[#D4854A]" />
              <span className="text-[#7C6E65] text-sm">Order #</span>
              <span className="text-[#1C1917]">{payment?.orderNumber || payment?._id?.slice(-8) || '—'}</span>
            </div>
          </motion.div>
          <div className="flex items-center justify-center gap-2 text-[#7C6E65]">
            <Clock className="w-4 h-4" />
            <span className="text-sm">Estimated: {estimatedTime}</span>
          </div>
          {currentStage === 1 && !isLoading && !error && <BrewingAnimation />}
        </motion.div>

        {isLoading ? (
          <div className="bg-white rounded-xl p-6 text-center text-[#7C6E65] border border-[rgba(0,0,0,0.04)]">
            <Loader2 className="w-5 h-5 animate-spin mx-auto mb-2" />
            Loading order status...
          </div>
        ) : null}
        {error ? (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-600">
            {error.message}
          </div>
        ) : null}
        {!paymentId ? (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-700">
            Missing order reference. Please place an order again from the menu.
          </div>
        ) : null}

        {/* Progress Tracker */}
        <div className="bg-white rounded-xl p-5 shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)]">
          <div className="flex items-center gap-2 mb-4">
            <h3 className="text-[#1C1917] text-sm">Order Progress</h3>
            <Coffee className="w-3.5 h-3.5 text-[#D4854A]/50" />
          </div>
          <div className="space-y-0">
            {stages.map((stage, idx) => {
              const Icon = stage.icon;
              const isActive = idx === currentStage;
              const isDone = idx < currentStage;
              const isPending = idx > currentStage;

              return (
                <motion.div
                  key={stage.key}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="flex gap-3"
                >
                  <div className="flex flex-col items-center">
                    <motion.div
                      animate={isActive ? { scale: [1, 1.08, 1] } : {}}
                      transition={isActive ? { duration: 1.5, repeat: Infinity } : {}}
                      className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 transition-all ${
                        isDone ? 'bg-emerald-500 text-white' :
                        isActive ? 'bg-[#D4854A] text-white' :
                        'bg-[#F0EBE6] text-[#A8A29E]'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </motion.div>
                    {idx < stages.length - 1 && (
                      <motion.div
                        className={`w-0.5 h-8 transition-colors`}
                        animate={{
                          backgroundColor: isDone ? '#6ee7b7' : '#E7E5E4',
                        }}
                      />
                    )}
                  </div>
                  <div className="pt-1.5 pb-4">
                    <p className={`text-sm ${isPending ? 'text-[#A8A29E]' : 'text-[#1C1917]'}`}>
                      {stage.label}
                      {isActive && stage.key === 'preparing' && (
                        <motion.span
                          animate={{ opacity: [1, 0.3, 1] }}
                          transition={{ duration: 1, repeat: Infinity }}
                          className="ml-1.5 text-[#D4854A]"
                        >
                          ☕
                        </motion.span>
                      )}
                    </p>
                    <p className="text-xs text-[#A8A29E]">{stage.description}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Items Ordered */}
        <div className="bg-white rounded-xl p-4 shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)]">
          <h4 className="text-[#1C1917] text-sm mb-3">Items Ordered</h4>
          <div className="space-y-2 text-sm">
            {payment?.cart?.map((item, index) => (
              <div key={`${item.itemId ?? item.name}-${index}`} className="flex justify-between text-[#57534E]">
                <span>{item.quantity}x {item.name}</span>
                <span className="text-[#78553B]">&#8369;{item.price * item.quantity}</span>
              </div>
            ))}
            {!payment?.cart?.length ? (
              <div className="text-[#A8A29E] text-sm">No items found for this order.</div>
            ) : null}
            {/* Coffee divider */}
            <div className="flex items-center gap-2 my-2">
              <div className="h-px flex-1 bg-[rgba(0,0,0,0.05)]" />
              <Coffee className="w-3 h-3 text-[#E7E5E4]" />
              <div className="h-px flex-1 bg-[rgba(0,0,0,0.05)]" />
            </div>
            <div className="flex justify-between">
              <span className="text-[#1C1917]">Total</span>
              <span className="text-[#78553B]">&#8369;{payment?.amount ?? 0}</span>
            </div>
          </div>
        </div>

        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={() => navigate('/')}
          className="w-full bg-[#F5F0EB] text-[#78553B] py-3 rounded-xl hover:bg-[#EDE5DC] transition-colors text-sm flex items-center justify-center gap-2"
        >
          <Coffee className="w-4 h-4" />
          Back to Home
        </motion.button>
      </div>
    </div>
  );
}
