import { useState, useMemo, useEffect } from 'react';
import React from 'react';
import { useNavigate } from 'react-router';
import { ShoppingCart, Plus, Search, Coffee, CupSoda, Cake, Sandwich } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { categories, MenuItem } from '../../data/mock-data';
import { useCart } from '../../context/CartContext';
import { ProductModal } from './ProductModal';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { getItemTemperature } from './AddToCartFeedback';
import { useMenusQuery, resolveMenuImageUrl, type MenuItemApi } from '../../../hooks/useMenu';

function toCartMenuItem(item: MenuItemApi): MenuItem {
  return {
    id: item._id,
    name: item.name,
    description: item.description,
    price: item.price,
    category: item.category,
    image: resolveMenuImageUrl(item.image),
    available: item.available,
  };
}

function getCustomerNameFromCookie(): string {
  const token = document.cookie
    .split('; ')
    .find((cookie) => cookie.startsWith('customer_name='))
    ?.split('=')[1];
  return token ? decodeURIComponent(token) : 'Customer';
}

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

const categoryChips: Record<string, { icon: React.ReactNode; emoji: string }> = {
  all: { icon: <Coffee className="w-3.5 h-3.5" />, emoji: '☕' },
  coffee: { icon: <Coffee className="w-3.5 h-3.5" />, emoji: '☕' },
  'milk-tea': { icon: <CupSoda className="w-3.5 h-3.5" />, emoji: '🧋' },
  desserts: { icon: <Cake className="w-3.5 h-3.5" />, emoji: '🍰' },
  snacks: { icon: <Sandwich className="w-3.5 h-3.5" />, emoji: '🥪' },
};

export function MenuPage() {
  const { data: menuData = [], isLoading, error } = useMenusQuery();
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<MenuItem | null>(null);
  const { itemCount } = useCart();
  const navigate = useNavigate();
  const menuItems = useMemo(() => menuData.map(toCartMenuItem), [menuData]);
  const customerName = useMemo(getCustomerNameFromCookie, []);

  useEffect(() => {
    if (!selectedProduct) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [selectedProduct]);

  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = { all: 0 };
    menuItems.forEach(item => {
      counts.all = (counts.all || 0) + 1;
      counts[item.category] = (counts[item.category] || 0) + 1;
    });
    return counts;
  }, [menuItems]);

  const filtered = useMemo(
    () =>
      menuItems.filter(item => {
        const matchCategory = activeCategory === 'all' || item.category === activeCategory;
        const matchSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
        return matchCategory && matchSearch;
      }),
    [menuItems, activeCategory, searchQuery],
  );

  return (
    <div className="min-h-screen bg-[#FAFAF8] pb-24">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-[#FAFAF8]/80 backdrop-blur-xl px-4 lg:px-8 pt-5 pb-3">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-[#A8A29E] text-xs">{getGreeting()},</p>
              <h2 className="text-[#1C1917] text-lg tracking-tight font-semibold flex items-center gap-1.5">
                {customerName}
                <motion.div
                  animate={{ rotate: [0, -8, 8, -4, 0] }}
                  transition={{ duration: 2, repeat: Infinity, repeatDelay: 4 }}
                >
                  <Coffee className="w-4 h-4 text-[#D4854A]" />
                </motion.div>
              </h2>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => navigate('/cart')}
                className="relative p-2.5 rounded-xl bg-[#78553B] text-white transition-colors hover:bg-[#5F432E]"
              >
                <ShoppingCart className="w-[18px] h-[18px]" />
                {itemCount > 0 && (
                  <motion.span
                    key={itemCount}
                    initial={{ scale: 0.5 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-1.5 -right-1.5 bg-[#D4854A] text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center font-medium"
                  >
                    {itemCount}
                  </motion.span>
                )}
              </button>
            </div>
          </div>

          {/* Search */}
          <div className="relative max-w-md">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A8A29E]" />
            <input
              type="text"
              placeholder="Search coffee, desserts..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-[rgba(0,0,0,0.06)] rounded-xl py-3 pl-10 pr-4 text-sm text-[#1C1917] placeholder-[#C7BBB1] focus:outline-none focus:ring-2 focus:ring-[#78553B]/20 focus:border-[#78553B]/30 transition-shadow"
            />
          </div>

        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 lg:px-8">
        {/* Category Chips */}
        <div className="pt-3 pb-2">
          <h3 className="text-[#1C1917] text-sm font-semibold mb-2.5">Categories</h3>
          <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
            {categories.map((cat) => {
              const isActive = activeCategory === cat.id;
              const chip = categoryChips[cat.id];
              const count = categoryCounts[cat.id] || 0;

              return (
                <motion.button
                  key={cat.id}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`relative shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${
                    isActive
                      ? 'bg-[#78553B] text-white shadow-md shadow-[#78553B]/20'
                      : 'bg-white text-[#57534E] border border-[rgba(0,0,0,0.06)] hover:border-[rgba(0,0,0,0.12)]'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeCategoryBg"
                      className="absolute inset-0 bg-[#78553B] rounded-xl"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10 flex items-center gap-1.5">
                    {chip.icon}
                    {cat.label}
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-md ${
                      isActive
                        ? 'bg-white/20 text-white'
                        : 'bg-[#F5F0EB] text-[#A8A29E]'
                    }`}>
                      {count}
                    </span>
                  </span>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Section Label */}
        <div className="pt-2 pb-1 flex items-center justify-between">
          <h3 className="text-[#1C1917] text-sm font-semibold">
            {activeCategory === 'all' ? 'Popular' : categories.find(c => c.id === activeCategory)?.label ?? 'Menu'}
          </h3>
          <span className="text-xs text-[#A8A29E]">{filtered.length} items</span>
        </div>

        {/* Loading / Error */}
        {isLoading ? (
          <div className="pt-6 text-center text-sm text-[#7C6E65]">Loading menu...</div>
        ) : null}
        {error ? (
          <div className="pt-4">
            <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-sm text-red-600">
              {error.message}
            </div>
          </div>
        ) : null}

        {/* Product Grid — responsive columns */}
        <div className="pt-1 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 lg:gap-4">
          {filtered.map(item => {
            const temp = getItemTemperature(item.name, item.category);
            const isUnavailable = !item.available;

            return (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.25 }}
                onClick={() => setSelectedProduct(item)}
                className={`relative rounded-2xl overflow-hidden shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)] transition-shadow group ${
                  isUnavailable
                    ? 'bg-[#F4F1ED] cursor-default opacity-65'
                    : 'bg-white cursor-pointer hover:shadow-[0_4px_16px_rgba(0,0,0,0.08)]'
                }`}
              >
                <div className="aspect-square overflow-hidden relative bg-[#F5F0EB]">
                  <ImageWithFallback
                    src={item.image}
                    alt={item.name}
                    className={`w-full h-full object-cover transition-transform duration-300 ${
                      isUnavailable ? '' : 'group-hover:scale-105'
                    }`}
                  />
                  {isUnavailable && (
                    <div className="absolute inset-0 bg-white/35 backdrop-blur-[1px]" />
                  )}
                  {(temp === 'hot' || temp === 'cold') && (
                    <div className={`absolute top-2 left-2 px-1.5 py-0.5 rounded-lg text-[10px] backdrop-blur-sm font-medium ${
                      temp === 'hot' ? 'bg-orange-500/80 text-white' : 'bg-sky-500/80 text-white'
                    }`}>
                      {temp === 'hot' ? '🔥 Hot' : '❄️ Iced'}
                    </div>
                  )}
                  {isUnavailable && (
                    <div className="absolute top-2 right-2 px-2 py-0.5 rounded-lg text-[10px] font-semibold bg-[#1C1917]/80 text-white">
                      Unavailable
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <p className="text-[#A8A29E] text-[10px] uppercase tracking-wide">
                    {item.category.replace('-', ' ')}
                  </p>
                  <h4 className={`text-sm font-medium truncate mt-0.5 ${isUnavailable ? 'text-[#8B857D]' : 'text-[#1C1917]'}`}>
                    {item.name}
                  </h4>
                  <p className={`text-xs line-clamp-1 mt-0.5 hidden sm:block ${isUnavailable ? 'text-[#B1AAA1]' : 'text-[#A8A29E]'}`}>
                    {item.description}
                  </p>
                  <div className="flex items-center justify-between mt-2">
                    <span className={`font-semibold ${isUnavailable ? 'text-[#9B948B]' : 'text-[#78553B]'}`}>
                      &#8369; {item.price}
                    </span>
                    <motion.button
                      whileTap={{ scale: 0.85 }}
                      onClick={e => {
                        e.stopPropagation();
                        if (!isUnavailable) setSelectedProduct(item);
                      }}
                      disabled={isUnavailable}
                      className={`w-8 h-8 rounded-xl flex items-center justify-center transition-colors shadow-sm ${
                        isUnavailable
                          ? 'bg-[#E7E1D9] text-[#B1AAA1] cursor-not-allowed shadow-none'
                          : 'bg-[#78553B] hover:bg-[#5F432E] text-white'
                      }`}
                    >
                      <Plus className="w-4 h-4" />
                    </motion.button>
                  </div>
                </div>

              </motion.div>
            );
          })}
        </div>

        {!isLoading && !error && filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-[#A8A29E]">
            <Coffee className="w-10 h-10 mb-3 opacity-30" />
            <p className="text-sm">No items found</p>
            <p className="text-xs mt-1">Try a different search or category</p>
          </div>
        )}
      </div>

      {/* Floating Cart */}
      <AnimatePresence>
        {itemCount > 0 && (
          <motion.div
            initial={{ y: 80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 80, opacity: 0 }}
            className="fixed bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-[#FAFAF8] via-[#FAFAF8]/95 to-transparent pt-8"
          >
            <motion.button
              whileTap={{ scale: 0.98 }}
              onClick={() => navigate('/cart')}
              className="w-full max-w-lg mx-auto bg-[#78553B] hover:bg-[#5F432E] text-white py-3.5 rounded-2xl flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(120,85,59,0.3)] transition-colors"
            >
              <ShoppingCart className="w-4 h-4" />
              View Cart ({itemCount} items)
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>

      {selectedProduct && (
        <ProductModal product={selectedProduct} onClose={() => setSelectedProduct(null)} />
      )}
    </div>
  );
}
