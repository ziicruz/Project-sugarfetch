import { motion, AnimatePresence } from 'motion/react';

interface Props {
  show: boolean;
  type: 'hot' | 'cold' | 'neutral';
  itemName: string;
}

function SteamBurst() {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-xl">
      {/* Rising steam wisps */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={`steam-${i}`}
          className="absolute rounded-full"
          style={{
            left: `${15 + Math.random() * 70}%`,
            bottom: '20%',
            width: 6 + Math.random() * 6,
            height: 6 + Math.random() * 6,
            background: `rgba(212, 133, 74, ${0.15 + Math.random() * 0.2})`,
          }}
          initial={{ y: 0, opacity: 0, scale: 0.3 }}
          animate={{
            y: [0, -60 - Math.random() * 80],
            x: [0, (Math.random() - 0.5) * 40],
            opacity: [0, 0.7, 0],
            scale: [0.3, 1.2, 1.8],
          }}
          transition={{
            duration: 1.2 + Math.random() * 0.6,
            delay: i * 0.08,
            ease: 'easeOut',
          }}
        />
      ))}
      {/* Main steam wave from bottom */}
      <motion.div
        className="absolute bottom-0 left-0 right-0"
        initial={{ height: 0, opacity: 0 }}
        animate={{ height: '60%', opacity: [0, 0.25, 0] }}
        transition={{ duration: 1.2, ease: 'easeOut' }}
        style={{
          background: 'linear-gradient(to top, rgba(212,133,74,0.2), rgba(212,133,74,0.05), transparent)',
          filter: 'blur(8px)',
        }}
      />
      {/* Warm glow */}
      <motion.div
        className="absolute inset-0"
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 0.15, 0] }}
        transition={{ duration: 0.8 }}
        style={{
          background: 'radial-gradient(circle at 50% 70%, rgba(212,133,74,0.3), transparent 70%)',
        }}
      />
    </div>
  );
}

function IceBurst() {
  const iceCubes = [...Array(6)].map((_, i) => ({
    id: i,
    left: 20 + Math.random() * 60,
    size: 8 + Math.random() * 8,
    delay: i * 0.06,
    rotation: Math.random() * 90 - 45,
  }));

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-xl">
      {/* Falling ice cubes */}
      {iceCubes.map((cube) => (
        <motion.div
          key={`ice-${cube.id}`}
          className="absolute"
          style={{
            left: `${cube.left}%`,
            top: '-10%',
            width: cube.size,
            height: cube.size,
            borderRadius: 2,
            background: 'linear-gradient(135deg, rgba(186,230,253,0.9), rgba(147,197,253,0.7))',
            border: '1px solid rgba(255,255,255,0.6)',
            boxShadow: '0 0 6px rgba(147,197,253,0.4)',
          }}
          initial={{ y: -10, opacity: 0, rotate: 0, scale: 0.5 }}
          animate={{
            y: [0, 120 + Math.random() * 60],
            opacity: [0, 1, 0.8, 0],
            rotate: [0, cube.rotation, cube.rotation * 2],
            scale: [0.5, 1, 0.8],
          }}
          transition={{
            duration: 1 + Math.random() * 0.4,
            delay: cube.delay,
            ease: 'easeIn',
          }}
        />
      ))}
      {/* Frost particles */}
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={`frost-${i}`}
          className="absolute rounded-full"
          style={{
            left: `${10 + Math.random() * 80}%`,
            top: `${Math.random() * 60}%`,
            width: 2 + Math.random() * 3,
            height: 2 + Math.random() * 3,
            background: 'rgba(186,230,253,0.8)',
          }}
          initial={{ opacity: 0, scale: 0 }}
          animate={{
            opacity: [0, 0.8, 0],
            scale: [0, 1.5, 0.5],
            y: [0, 10 + Math.random() * 20],
          }}
          transition={{
            duration: 0.8,
            delay: 0.2 + i * 0.05,
          }}
        />
      ))}
      {/* Cold mist */}
      <motion.div
        className="absolute bottom-0 left-0 right-0"
        initial={{ height: 0, opacity: 0 }}
        animate={{ height: '50%', opacity: [0, 0.2, 0] }}
        transition={{ duration: 1.2, ease: 'easeOut' }}
        style={{
          background: 'linear-gradient(to top, rgba(147,197,253,0.15), rgba(186,230,253,0.08), transparent)',
          filter: 'blur(6px)',
        }}
      />
      {/* Cool glow */}
      <motion.div
        className="absolute inset-0"
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 0.12, 0] }}
        transition={{ duration: 0.8 }}
        style={{
          background: 'radial-gradient(circle at 50% 30%, rgba(147,197,253,0.25), transparent 70%)',
        }}
      />
    </div>
  );
}

function SparkBurst() {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-xl">
      {[...Array(6)].map((_, i) => (
        <motion.div
          key={`spark-${i}`}
          className="absolute rounded-full bg-[#D4854A]"
          style={{
            left: `${20 + Math.random() * 60}%`,
            top: `${30 + Math.random() * 40}%`,
            width: 3,
            height: 3,
          }}
          initial={{ opacity: 0, scale: 0 }}
          animate={{
            opacity: [0, 1, 0],
            scale: [0, 1.5, 0],
            x: [(Math.random() - 0.5) * 30],
            y: [(Math.random() - 0.5) * 30],
          }}
          transition={{ duration: 0.6, delay: i * 0.06 }}
        />
      ))}
    </div>
  );
}

export function AddToCartFeedback({ show, type, itemName }: Props) {
  return (
    <AnimatePresence>
      {show && (
        <>
          {type === 'hot' && <SteamBurst />}
          {type === 'cold' && <IceBurst />}
          {type === 'neutral' && <SparkBurst />}

          {/* Toast banner */}
          <motion.div
            initial={{ y: 10, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -10, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="absolute bottom-2 left-2 right-2 z-20"
          >
            <div
              className={`rounded-lg px-3 py-2 text-xs text-center backdrop-blur-md ${
                type === 'cold'
                  ? 'bg-sky-500/85 text-white'
                  : type === 'hot'
                  ? 'bg-[#78553B]/85 text-white'
                  : 'bg-[#1C1917]/85 text-white'
              }`}
            >
              {type === 'hot' && '☕ '}
              {type === 'cold' && '🧊 '}
              {type === 'neutral' && '✨ '}
              Added {itemName}!
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

/** Determine if an item is hot, cold, or neutral based on name/category */
export function getItemTemperature(name: string, category: string): 'hot' | 'cold' | 'neutral' {
  const lower = name.toLowerCase();
  if (category === 'desserts' || category === 'snacks') return 'neutral';
  if (lower.includes('iced') || lower.includes('cold') || lower.includes('frappe') || lower.includes('frappuccino') || lower.includes('smoothie')) return 'cold';
  if (category === 'milk-tea') return 'cold';
  if (category === 'coffee') return 'hot';
  return 'neutral';
}
