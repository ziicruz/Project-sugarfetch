import { useMemo, useState } from 'react';
import { X, Minus, Plus, Flame, Snowflake } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MenuItem } from '../../data/mock-data';
import { type CartAddOn, type DrinkSize, useCart } from '../../context/CartContext';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { getItemTemperature } from './AddToCartFeedback';
import { hasAuthToken, useAddOnInventoryQuery, useInventoriesQuery } from '../../../hooks/useInventory';

interface Props {
  product: MenuItem;
  onClose: () => void;
}

const SIZE_PRICE_DELTA: Record<DrinkSize, number> = {
  Medium: 0,
  Large: 20,
};

const ADD_ON_OPTIONS: CartAddOn[] = [
  { name: 'Extra Pearls', price: 15 },
  { name: 'Nata', price: 15 },
  { name: 'Cream Puffs', price: 20 },
  { name: 'Whipped Cream', price: 15 },
];

type AddOnOptionView = CartAddOn & {
  unavailable: boolean;
};

function normalizeName(value: string): string {
  return value.trim().toLowerCase();
}

function ModalSteamAnimation() {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-t-2xl sm:rounded-2xl z-30">
      {[...Array(14)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full"
          style={{
            left: `${10 + Math.random() * 80}%`,
            bottom: '30%',
            width: 8 + Math.random() * 10,
            height: 8 + Math.random() * 10,
            background: `rgba(212, 133, 74, ${0.12 + Math.random() * 0.15})`,
          }}
          initial={{ y: 0, opacity: 0, scale: 0.3 }}
          animate={{
            y: [0, -150 - Math.random() * 120],
            x: [0, (Math.random() - 0.5) * 60],
            opacity: [0, 0.6, 0],
            scale: [0.3, 1.5, 2.5],
          }}
          transition={{
            duration: 1.5 + Math.random() * 0.8,
            delay: i * 0.06,
            ease: 'easeOut',
          }}
        />
      ))}
      <motion.div
        className="absolute bottom-0 left-0 right-0"
        initial={{ height: 0, opacity: 0 }}
        animate={{ height: '80%', opacity: [0, 0.2, 0] }}
        transition={{ duration: 1.4, ease: 'easeOut' }}
        style={{
          background: 'linear-gradient(to top, rgba(212,133,74,0.18), transparent)',
          filter: 'blur(12px)',
        }}
      />
    </div>
  );
}

function ModalIceAnimation() {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-t-2xl sm:rounded-2xl z-30">
      {[...Array(10)].map((_, i) => (
        <motion.div
          key={`cube-${i}`}
          className="absolute"
          style={{
            left: `${10 + Math.random() * 80}%`,
            top: '-5%',
            width: 10 + Math.random() * 12,
            height: 10 + Math.random() * 12,
            borderRadius: 3,
            background: 'linear-gradient(135deg, rgba(186,230,253,0.9), rgba(147,197,253,0.7))',
            border: '1px solid rgba(255,255,255,0.7)',
            boxShadow: '0 0 8px rgba(147,197,253,0.4)',
          }}
          initial={{ y: -20, opacity: 0, rotate: 0, scale: 0.5 }}
          animate={{
            y: [0, 200 + Math.random() * 150],
            opacity: [0, 1, 0.8, 0],
            rotate: [0, (Math.random() - 0.5) * 180],
            scale: [0.5, 1, 0.7],
          }}
          transition={{
            duration: 1.2 + Math.random() * 0.5,
            delay: i * 0.07,
            ease: 'easeIn',
          }}
        />
      ))}
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={`frost-${i}`}
          className="absolute rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 80}%`,
            width: 2 + Math.random() * 4,
            height: 2 + Math.random() * 4,
            background: 'rgba(186,230,253,0.9)',
          }}
          initial={{ opacity: 0, scale: 0 }}
          animate={{
            opacity: [0, 1, 0],
            scale: [0, 1.5, 0],
          }}
          transition={{
            duration: 0.8,
            delay: 0.3 + i * 0.04,
          }}
        />
      ))}
      <motion.div
        className="absolute inset-0"
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 0.12, 0] }}
        transition={{ duration: 1 }}
        style={{
          background: 'radial-gradient(circle at 50% 30%, rgba(147,197,253,0.3), transparent 70%)',
        }}
      />
    </div>
  );
}

export function ProductModal({ product, onClose }: Props) {
  const [qty, setQty] = useState(1);
  const [size, setSize] = useState<DrinkSize>('Medium');
  const [selectedAddOns, setSelectedAddOns] = useState<CartAddOn[]>([]);
  const [notes, setNotes] = useState('');
  const [showFeedback, setShowFeedback] = useState(false);
  const { addToCart } = useCart();
  const hasInventoryToken = hasAuthToken();
  const { data: inventoryItems = [], isLoading: isInventoryLoading } = useInventoriesQuery({
    enabled: hasInventoryToken,
  });
  const { data: addOnInventory = [], isLoading: isAddOnInventoryLoading } = useAddOnInventoryQuery();

  const temp = getItemTemperature(product.name, product.category);
  const supportsCustomization = product.category === 'coffee' || product.category === 'milk-tea';
  const isUnavailable = !product.available;
  const addOnAvailability = useMemo(() => {
    return new Map(addOnInventory.map((item) => [normalizeName(item.itemName), item.stockQuantity > 0]));
  }, [addOnInventory]);
  const cupAvailability = useMemo(() => {
    const cupMap = new Map<DrinkSize, boolean>();
    const cupNameMap: Record<DrinkSize, string[]> = {
      Medium: ['12oz Paper Cup', '12oz Plastic Cup'],
      Large: ['16oz Paper Cup', '16oz Plastic Cup'],
    };

    const cupInventory = hasInventoryToken ? inventoryItems : addOnInventory;
    const isCupInventoryLoading = hasInventoryToken ? isInventoryLoading : isAddOnInventoryLoading;

    const inventoryByName = new Map(
      cupInventory.map((item) => [normalizeName(item.itemName), item])
    );

    for (const [size, cupNames] of Object.entries(cupNameMap)) {
      const cupItems = cupNames
        .map((cupName) => inventoryByName.get(normalizeName(cupName)))
        .filter((item): item is { itemName: string; stockQuantity: number } => Boolean(item));
      const hasCupData = cupItems.length > 0;
      const hasStock = isCupInventoryLoading
        ? true
        : hasCupData
          ? cupItems.some((item) => item.stockQuantity > 0)
          : true;
      cupMap.set(size as DrinkSize, hasStock);
    }

    return cupMap;
  }, [addOnInventory, hasInventoryToken, inventoryItems, isAddOnInventoryLoading, isInventoryLoading]);
  const addOnOptions: AddOnOptionView[] = useMemo(() => {
    return ADD_ON_OPTIONS.map((option) => ({
      ...option,
      unavailable: addOnAvailability.has(normalizeName(option.name))
        ? !addOnAvailability.get(normalizeName(option.name))
        : false,
    }));
  }, [addOnAvailability]);
  const addOnsTotal = selectedAddOns.reduce((sum, addOn) => sum + addOn.price, 0);
  const unitPrice = product.price + (supportsCustomization ? SIZE_PRICE_DELTA[size] : 0) + addOnsTotal;
  const totalPrice = unitPrice * qty;

  const handleAdd = () => {
    if (isUnavailable) {
      return;
    }

    addToCart(product, {
      qty,
      size: supportsCustomization ? size : undefined,
      addOns: supportsCustomization ? selectedAddOns : [],
      notes,
      unitPrice,
    });
    setShowFeedback(true);
    setTimeout(() => {
      setShowFeedback(false);
      onClose();
    }, 1500);
  };

  const toggleAddOn = (addOn: CartAddOn) => {
    const optionAvailability = addOnAvailability.get(addOn.name);
    if (optionAvailability === false) {
      return;
    }

    setSelectedAddOns((prev) => {
      const exists = prev.some((selected) => selected.name === addOn.name);
      if (exists) return prev.filter((selected) => selected.name !== addOn.name);
      return [...prev, addOn];
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-end sm:items-center justify-center" onClick={onClose}>
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        transition={{ type: 'spring', damping: 28, stiffness: 300 }}
        className="relative bg-white w-full max-w-md rounded-t-2xl sm:rounded-2xl overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* Add to cart animation overlay */}
        <AnimatePresence>
          {showFeedback && temp === 'hot' && <ModalSteamAnimation />}
          {showFeedback && temp === 'cold' && <ModalIceAnimation />}
        </AnimatePresence>

        {/* Confirmation overlay */}
        <AnimatePresence>
          {showFeedback && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-40 flex items-center justify-center"
              style={{
                background: temp === 'cold'
                  ? 'rgba(14,165,233,0.12)'
                  : temp === 'hot'
                  ? 'rgba(212,133,74,0.12)'
                  : 'rgba(28,25,23,0.08)',
              }}
            >
              <motion.div
                initial={{ scale: 0, rotate: -20 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: 'spring', damping: 12 }}
                className={`px-6 py-4 rounded-2xl backdrop-blur-md text-center ${
                  temp === 'cold'
                    ? 'bg-sky-500/90 text-white'
                    : temp === 'hot'
                    ? 'bg-[#78553B]/90 text-white'
                    : 'bg-[#1C1917]/90 text-white'
                }`}
              >
                <motion.div
                  animate={{ y: [0, -4, 0] }}
                  transition={{ duration: 0.5, repeat: 2 }}
                  className="text-2xl mb-1"
                >
                  {temp === 'hot' ? '☕' : temp === 'cold' ? '🧊' : '✨'}
                </motion.div>
                <p className="text-sm">Added to cart!</p>
                <p className="text-xs opacity-75 mt-0.5">
                  {qty}x {product.name}
                </p>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="relative aspect-[4/3] overflow-hidden">
          <ImageWithFallback src={product.image} alt={product.name} className="w-full h-full object-cover" />
          {isUnavailable && <div className="absolute inset-0 bg-white/40 backdrop-blur-[1px]" />}
          <button
            onClick={onClose}
            className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm p-2 rounded-lg shadow-sm hover:bg-white transition-colors"
          >
            <X className="w-4 h-4 text-[#1C1917]" />
          </button>
          {isUnavailable && (
            <div className="absolute top-3 left-3 px-2 py-1 rounded-lg text-xs font-semibold bg-[#1C1917]/80 text-white z-10">
              Unavailable
            </div>
          )}
          {/* Temperature badge on image */}
          {(temp === 'hot' || temp === 'cold') && (
            <div className={`absolute ${isUnavailable ? 'top-12' : 'top-3'} left-3 px-2 py-1 rounded-lg text-xs backdrop-blur-sm flex items-center gap-1 ${
              temp === 'hot' ? 'bg-orange-500/80 text-white' : 'bg-sky-500/80 text-white'
            }`}>
              {temp === 'hot' ? <Flame className="w-3 h-3" /> : <Snowflake className="w-3 h-3" />}
              {temp === 'hot' ? 'Served Hot' : 'Served Cold'}
            </div>
          )}
        </div>

        <div className="p-5 space-y-4">
          <div>
            <h2 className="text-[#1C1917] tracking-tight">{product.name}</h2>
            <p className="text-[#7C6E65] mt-1 text-sm">{product.description}</p>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-[#78553B] text-2xl">&#8369;{product.price}</span>
            <div className="flex items-center gap-3 bg-[#F5F0EB] rounded-lg px-3 py-1.5">
              <button onClick={() => setQty(Math.max(1, qty - 1))} className="text-[#78553B] hover:text-[#5F432E] transition-colors">
                <Minus className="w-4 h-4" />
              </button>
              <span className="text-[#1C1917] w-6 text-center text-sm">{qty}</span>
              <button onClick={() => setQty(qty + 1)} className="text-[#78553B] hover:text-[#5F432E] transition-colors">
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          {supportsCustomization && (
            <div className="space-y-3">
              <div>
                <p className="text-[#57534E] text-xs uppercase tracking-wide mb-1.5">Drink Size</p>
                <div className="grid grid-cols-2 gap-2">
                  {(['Medium', 'Large'] as const).map((option) => {
                    const sizeAvailable = cupAvailability.get(option) ?? true;
                    return (
                      <button
                        key={option}
                        onClick={() => setSize(option)}
                        disabled={!sizeAvailable}
                        className={`text-sm rounded-lg py-2 transition-colors ${
                          !sizeAvailable
                            ? 'bg-[#F1ECE6] text-[#B1AAA1] cursor-not-allowed'
                            : size === option
                            ? 'bg-[#1C1917] text-white'
                            : 'bg-[#F5F0EB] text-[#5F432E] hover:bg-[#EDE5DC]'
                        }`}
                      >
                        <span className={!sizeAvailable ? 'line-through' : ''}>{option}</span>
                        {SIZE_PRICE_DELTA[option] > 0 ? ` (+₱${SIZE_PRICE_DELTA[option]})` : ''}
                        {!sizeAvailable && <span className="block text-[11px]">Out of stock</span>}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <p className="text-[#57534E] text-xs uppercase tracking-wide mb-1.5">Add-ons</p>
                <div className="grid grid-cols-2 gap-2">
                  {addOnOptions.map((option) => {
                    const selected = selectedAddOns.some((addOn) => addOn.name === option.name);
                    return (
                      <button
                        key={option.name}
                        onClick={() => toggleAddOn(option)}
                        disabled={option.unavailable}
                        className={`text-xs rounded-lg py-2 px-2 text-left transition-colors ${
                          option.unavailable
                            ? 'bg-[#F1ECE6] text-[#B1AAA1] cursor-not-allowed'
                            : selected
                            ? 'bg-[#78553B] text-white'
                            : 'bg-[#F5F0EB] text-[#5F432E] hover:bg-[#EDE5DC]'
                        }`}
                      >
                        <span className={`block ${option.unavailable ? 'line-through' : ''}`}>{option.name}</span>
                        <span className={`text-[11px] ${option.unavailable ? 'text-[#B1AAA1]' : selected ? 'text-white/80' : 'text-[#8A7768]'}`}>
                          {option.unavailable ? 'Unavailable' : `+₱${option.price}`}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          <div>
            <p className="text-[#57534E] text-xs uppercase tracking-wide mb-1.5">Notes / Request</p>
            <textarea
              value={notes}
              onChange={(event) => setNotes(event.target.value)}
              placeholder="Less sugar, no ice, extra hot..."
              className="w-full min-h-[72px] resize-none bg-[#F8F5F2] border border-[rgba(0,0,0,0.08)] rounded-lg px-3 py-2 text-sm text-[#1C1917] placeholder-[#A8A29E] focus:outline-none focus:ring-2 focus:ring-[#78553B]/20"
            />
          </div>

          <div className="bg-[#F8F5F2] rounded-lg p-3 text-sm space-y-1">
            <div className="flex justify-between text-[#6B645E]">
              <span>Base price</span>
              <span>₱{product.price}</span>
            </div>
            {supportsCustomization && (
              <>
                <div className="flex justify-between text-[#6B645E]">
                  <span>Size ({size})</span>
                  <span>₱{SIZE_PRICE_DELTA[size]}</span>
                </div>
                <div className="flex justify-between text-[#6B645E]">
                  <span>Add-ons</span>
                  <span>₱{addOnsTotal}</span>
                </div>
              </>
            )}
            <div className="h-px bg-[rgba(0,0,0,0.07)] my-1" />
            <div className="flex justify-between text-[#1C1917] font-medium">
              <span>Unit price</span>
              <span>₱{unitPrice}</span>
            </div>
          </div>

          <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={handleAdd}
            disabled={showFeedback || isUnavailable}
            className={`w-full py-3.5 rounded-xl transition-colors flex items-center justify-center gap-2 ${
              isUnavailable
                ? 'bg-[#D6D0C7] text-[#8F887E] cursor-not-allowed'
                : showFeedback
                ? temp === 'cold'
                  ? 'bg-sky-500 text-white'
                  : 'bg-[#78553B] text-white'
                : 'bg-[#1C1917] hover:bg-[#292524] text-white'
            }`}
          >
            {isUnavailable ? (
              'Unavailable'
            ) : showFeedback ? (
              temp === 'hot' ? '☕ Brewing...' : temp === 'cold' ? '🧊 Chilling...' : '✨ Adding...'
            ) : (
              <>
                {temp === 'hot' && <Flame className="w-4 h-4" />}
                {temp === 'cold' && <Snowflake className="w-4 h-4" />}
                Add to Cart &mdash; &#8369;{totalPrice}
              </>
            )}
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
}
