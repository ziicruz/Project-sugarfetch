import { CheckCircle, Clock, ChefHat, Package, CreditCard, ClipboardList, ExternalLink, Loader2, Coffee, Calendar, History, Receipt } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { resolveOrderProofUrl, useOrderManagement } from '../../../hooks/useOrderManagement';

const statusFlow = ['received', 'preparing', 'ready', 'completed'] as const;
const statusConfig: Record<string, { icon: typeof Clock; color: string; bg: string; activeBg: string }> = {
  received: { icon: Clock, color: 'text-blue-600', bg: 'bg-blue-50', activeBg: 'bg-blue-600' },
  preparing: { icon: ChefHat, color: 'text-amber-600', bg: 'bg-amber-50', activeBg: 'bg-amber-600' },
  ready: { icon: Package, color: 'text-emerald-600', bg: 'bg-emerald-50', activeBg: 'bg-emerald-600' },
  completed: { icon: CheckCircle, color: 'text-[#78553B]', bg: 'bg-[#F5F0EB]', activeBg: 'bg-[#78553B]' },
};

function formatTime(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function formatDate(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
}

function timeAgo(value: string): string {
  const diff = Date.now() - new Date(value).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return formatDate(value);
}

export function OrderManagement() {
  const {
    filteredOrders,
    selectedOrder,
    setSelectedOrderId,
    statusFilter,
    setStatusFilter,
    timeFilter,
    setTimeFilter,
    todayStats,
    isLoading,
    error,
    isMutating,
    confirmPaymentMutation,
    updateStatus,
    confirmPayment,
  } = useOrderManagement();

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-[#1C1917] tracking-tight text-lg font-semibold flex items-center gap-2">
            Orders
            <Coffee className="w-4 h-4 text-[#D4854A]" />
          </h2>
          <p className="text-[#A8A29E] text-sm mt-0.5">
            {todayStats.count} orders today &middot; &#8369;{todayStats.revenue.toLocaleString()} revenue
          </p>
        </div>

        {/* Today / History Toggle */}
        <div className="flex bg-white border border-[rgba(0,0,0,0.06)] rounded-xl p-1 shrink-0">
          <button
            onClick={() => setTimeFilter('today')}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-medium transition-all ${
              timeFilter === 'today'
                ? 'bg-[#78553B] text-white shadow-sm'
                : 'text-[#7C6E65] hover:text-[#1C1917]'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            Today
          </button>
          <button
            onClick={() => setTimeFilter('history')}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-medium transition-all ${
              timeFilter === 'history'
                ? 'bg-[#78553B] text-white shadow-sm'
                : 'text-[#7C6E65] hover:text-[#1C1917]'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            All History
          </button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Today's Orders", value: todayStats.count, icon: Receipt, color: 'bg-[#78553B]/10 text-[#78553B]' },
          { label: 'Revenue', value: `₱${todayStats.revenue.toLocaleString()}`, icon: CreditCard, color: 'bg-emerald-50 text-emerald-600' },
          { label: 'In Progress', value: todayStats.pending, icon: ChefHat, color: 'bg-amber-50 text-amber-600' },
          { label: 'Completed', value: todayStats.completed, icon: CheckCircle, color: 'bg-[#F5F0EB] text-[#78553B]' },
        ].map(stat => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-white rounded-xl border border-[rgba(0,0,0,0.04)] p-3.5 flex items-center gap-3">
              <div className={`w-9 h-9 rounded-lg ${stat.color} flex items-center justify-center shrink-0`}>
                <Icon className="w-4 h-4" />
              </div>
              <div>
                <p className="text-lg font-semibold text-[#1C1917] leading-tight">{stat.value}</p>
                <p className="text-[10px] text-[#A8A29E] uppercase tracking-wide">{stat.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Status Filter Chips */}
      <div className="flex gap-1.5 flex-wrap">
        {['all', ...statusFlow].map(s => {
          const config = s !== 'all' ? statusConfig[s] : null;
          const count = filteredOrders.filter(o => s === 'all' || o.status === s).length;
          return (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-3.5 py-2 rounded-xl text-xs font-medium capitalize transition-all flex items-center gap-1.5 ${
                statusFilter === s
                  ? 'bg-[#78553B] text-white shadow-sm'
                  : 'bg-white text-[#57534E] border border-[rgba(0,0,0,0.06)] hover:border-[rgba(0,0,0,0.12)]'
              }`}
            >
              {config && (() => { const Icon = config.icon; return <Icon className="w-3 h-3" />; })()}
              {s}
              <span className={`text-[10px] px-1.5 py-0.5 rounded-md ${
                statusFilter === s ? 'bg-white/20' : 'bg-[#F5F0EB] text-[#A8A29E]'
              }`}>
                {s === 'all' ? filteredOrders.length : count}
              </span>
            </button>
          );
        })}
      </div>

      <div className="grid lg:grid-cols-5 gap-4">
        {/* Order List */}
        <div className="lg:col-span-2 space-y-2 max-h-[calc(100vh-220px)] overflow-y-auto pr-1">
          {isLoading && (
            <div className="bg-white rounded-2xl p-6 text-center border border-[rgba(0,0,0,0.04)]">
              <Loader2 className="w-5 h-5 animate-spin text-[#78553B] mx-auto mb-2" />
              <p className="text-sm text-[#7C6E65]">Loading orders...</p>
            </div>
          )}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-600">
              {error.message}
            </div>
          )}

          <AnimatePresence mode="popLayout">
            {filteredOrders.map((order, i) => {
              const config = statusConfig[order.status];
              const Icon = config.icon;
              const isSelected = selectedOrder?._id === order._id;
              return (
                <motion.div
                  key={order._id}
                  layout
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.15, delay: i * 0.02 }}
                  onClick={() => setSelectedOrderId(order._id)}
                  className={`bg-white rounded-2xl p-4 cursor-pointer border transition-all ${
                    isSelected
                      ? 'border-[#78553B] shadow-[0_0_0_1px_#78553B] bg-[#FDFCFB]'
                      : 'border-[rgba(0,0,0,0.04)] hover:shadow-md'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className={`w-8 h-8 rounded-lg ${config.bg} flex items-center justify-center`}>
                        <Icon className={`w-3.5 h-3.5 ${config.color}`} />
                      </div>
                      <div>
                        <span className="text-[#1C1917] text-sm font-medium block">{order.orderNumber || order._id.slice(-8)}</span>
                        <span className="text-[#A8A29E] text-[11px]">{timeAgo(order.createdAt)}</span>
                      </div>
                    </div>
                    <span className="text-[#78553B] font-semibold text-sm">&#8369;{order.amount}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#57534E] text-xs">{order.customerName}</span>
                    <div className="flex items-center gap-2">
                      {!order.paymentConfirmed && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-amber-50 text-amber-600">Unconfirmed</span>
                      )}
                      <span className="text-[#A8A29E] text-[11px]">{order.cart.length} items &middot; {order.paymentMethod}</span>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>

          {!isLoading && filteredOrders.length === 0 && (
            <div className="bg-white rounded-2xl border border-[rgba(0,0,0,0.04)] p-12 text-center">
              <Coffee className="w-10 h-10 mx-auto mb-3 text-[#D4854A]/30" />
              <p className="text-sm text-[#7C6E65]">No orders {timeFilter === 'today' ? 'today' : ''}</p>
              <p className="text-xs text-[#A8A29E] mt-1">Orders will appear here when placed</p>
            </div>
          )}
        </div>

        {/* Order Detail */}
        <div className="lg:col-span-3">
          {selectedOrder ? (
            <motion.div
              key={selectedOrder._id}
              initial={{ opacity: 0, x: 8 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white rounded-2xl shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)] overflow-hidden"
            >
              {/* Detail Header */}
              <div className="bg-gradient-to-r from-[#78553B] to-[#D4854A] px-5 py-4 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold tracking-tight">{selectedOrder.orderNumber || selectedOrder._id.slice(-8)}</h3>
                    <p className="text-white/70 text-sm">{selectedOrder.customerName} &middot; {selectedOrder.paymentMethod}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold">&#8369;{selectedOrder.amount}</p>
                    <p className="text-white/60 text-xs">{formatTime(selectedOrder.createdAt)} &middot; {formatDate(selectedOrder.createdAt)}</p>
                  </div>
                </div>
              </div>

              <div className="p-5 space-y-5">
                {/* Payment Confirmation */}
                <div className="flex items-center justify-between bg-[#FAFAF8] rounded-xl p-3.5">
                  <div className="flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-[#78553B]" />
                    <span className="text-sm text-[#57534E]">Payment Status</span>
                  </div>
                  {!selectedOrder.paymentConfirmed ? (
                    <button
                      onClick={() => confirmPayment(selectedOrder._id)}
                      disabled={isMutating}
                      className="bg-emerald-500 text-white px-3.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 hover:bg-emerald-600 transition-colors shadow-sm"
                    >
                      {confirmPaymentMutation.isPending ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <CheckCircle className="w-3.5 h-3.5" />
                      )}
                      {confirmPaymentMutation.isPending ? 'Confirming...' : 'Confirm Payment'}
                    </button>
                  ) : (
                    <span className="text-emerald-600 text-xs font-medium flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg">
                      <CheckCircle className="w-3.5 h-3.5" />
                      Confirmed
                    </span>
                  )}
                </div>

                {/* Items */}
                <div>
                  <h4 className="text-[#1C1917] text-sm font-medium mb-2.5">Order Items</h4>
                  <div className="space-y-1.5">
                    {selectedOrder.cart.map((item, index) => (
                      <div key={`${item.itemId ?? item.name}-${index}`} className="text-sm bg-[#FAFAF8] rounded-xl p-3.5">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-3">
                            <span className="w-7 h-7 rounded-lg bg-[#78553B]/10 text-[#78553B] flex items-center justify-center text-xs font-semibold">
                              {item.quantity}x
                            </span>
                            <span className="text-[#1C1917]">{item.name}</span>
                          </div>
                          <span className="text-[#78553B] font-medium">&#8369;{item.price * item.quantity}</span>
                        </div>
                        {(item.size || (item.addOns?.length ?? 0) > 0 || item.notes) && (
                          <div className="ml-10 mt-1 text-[11px] text-[#7C6E65] space-y-0.5">
                            {item.size && <p>Size: {item.size}</p>}
                            {(item.addOns?.length ?? 0) > 0 && (
                              <p>Add-ons: {item.addOns?.map((addOn) => addOn.name).join(', ')}</p>
                            )}
                            {item.notes && <p>Note: {item.notes}</p>}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                  <div className="flex justify-between mt-3 pt-3 border-t border-[rgba(0,0,0,0.04)]">
                    <span className="text-[#57534E] text-sm">Total</span>
                    <span className="text-[#78553B] text-lg font-bold">&#8369;{selectedOrder.amount}</span>
                  </div>
                </div>

                {/* Proof */}
                {selectedOrder.proofImage && (
                  <a
                    href={resolveOrderProofUrl(selectedOrder.proofImage)}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-between bg-[#FAFAF8] rounded-xl p-3.5 hover:bg-[#F5F0EB] transition-colors group"
                  >
                    <span className="text-sm text-[#57534E] flex items-center gap-2">
                      <Receipt className="w-4 h-4 text-[#78553B]" />
                      Payment Proof
                    </span>
                    <span className="text-xs text-[#78553B] flex items-center gap-1 group-hover:underline">
                      View Image
                      <ExternalLink className="w-3 h-3" />
                    </span>
                  </a>
                )}

                {/* Status Pipeline */}
                <div>
                  <h4 className="text-[#1C1917] text-sm font-medium mb-3">Order Status</h4>
                  <div className="flex items-center gap-1">
                    {statusFlow.map((s, i) => {
                      const config = statusConfig[s];
                      const Icon = config.icon;
                      const isActive = selectedOrder.status === s;
                      const isPast = statusFlow.indexOf(selectedOrder.status as typeof statusFlow[number]) >= i;
                      return (
                        <button
                          key={s}
                          onClick={() => updateStatus(selectedOrder._id, s)}
                          disabled={isMutating}
                          className={`flex-1 py-3 rounded-xl text-xs font-medium capitalize flex flex-col items-center gap-1.5 transition-all ${
                            isActive
                              ? `${config.activeBg} text-white shadow-md`
                              : isPast
                                ? `${config.bg} ${config.color}`
                                : 'bg-[#FAFAF8] text-[#A8A29E] border border-[rgba(0,0,0,0.04)] hover:bg-[#F5F0EB]'
                          }`}
                        >
                          <Icon className="w-4 h-4" />
                          {s}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </motion.div>
          ) : (
            <div className="bg-white rounded-2xl p-16 text-center border border-[rgba(0,0,0,0.04)]">
              <div className="w-16 h-16 rounded-2xl bg-[#F5F0EB] flex items-center justify-center mx-auto mb-4">
                <ClipboardList className="w-7 h-7 text-[#D4854A]" />
              </div>
              <p className="text-sm text-[#7C6E65]">Select an order to view details</p>
              <p className="text-xs text-[#A8A29E] mt-1">Click any order from the list</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
