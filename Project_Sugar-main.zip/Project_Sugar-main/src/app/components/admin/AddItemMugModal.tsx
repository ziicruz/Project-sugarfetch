import { useState, useMemo, useEffect, type ChangeEvent, type FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Upload, Coffee, Sparkles } from 'lucide-react';
import type { CreateMenuInput, MenuCategory } from '../../../hooks/useMenu';

interface AddItemMugModalProps {
  onClose: () => void;
  onAdd: (form: CreateMenuInput) => Promise<void> | void;
}

const steamVariants = {
  animate: (i: number) => ({
    y: [-2, -22, -38],
    x: [0, i % 2 === 0 ? 5 : -5, i % 2 === 0 ? -3 : 3],
    opacity: [0, 0.6, 0],
    scale: [0.6, 1, 1.4],
    transition: {
      duration: 1.8,
      repeat: Infinity,
      delay: i * 0.4,
      ease: 'easeOut' as const,
    },
  }),
};

export function AddItemMugModal({ onClose, onAdd }: AddItemMugModalProps) {
  const [form, setForm] = useState({
    name: '',
    description: '',
    price: 0,
    category: 'coffee' as MenuCategory,
    image: '',
    availabilityMode: 'anytime' as 'anytime' | 'period',
    startTime: '08:00',
    endTime: '22:00',
  });
  const [submitError, setSubmitError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [justCompleted, setJustCompleted] = useState(false);

  const categories = [
    { id: 'coffee', label: 'Coffee' },
    { id: 'milk-tea', label: 'Milk Tea' },
    { id: 'desserts', label: 'Desserts' },
    { id: 'snacks', label: 'Snacks' },
  ] as const;

  // Calculate fill progress based on fields filled
  const fillProgress = useMemo(() => {
    let filled = 0;
    const total = 5;
    if (form.name && form.name.trim().length > 0) filled++;
    if (form.description && form.description.trim().length > 0) filled++;
    if (form.price && form.price > 0) filled++;
    if (form.category) filled++;
    if (form.image.trim().length > 0) filled++;
    return filled / total;
  }, [form.name, form.description, form.price, form.category, form.image]);

  const hasValidPeriod =
    form.availabilityMode === 'anytime' ||
    (form.startTime.trim().length > 0 &&
      form.endTime.trim().length > 0 &&
      form.startTime !== form.endTime);

  const isComplete = fillProgress >= 1;
  const canSubmit = isComplete && hasValidPeriod && !isSubmitting;

  useEffect(() => {
    if (isComplete && !justCompleted) {
      setJustCompleted(true);
    }
  }, [isComplete, justCompleted]);

  // Coffee color transitions from light to dark as it fills
  const coffeeColor = useMemo(() => {
    if (fillProgress < 0.3) return '#D4A574';
    if (fillProgress < 0.6) return '#B8845A';
    if (fillProgress < 0.9) return '#8B5E3C';
    return '#6B4226';
  }, [fillProgress]);

  const foamOpacity = fillProgress > 0.2 ? 1 : 0;

  const inputClass =
    'w-full bg-white/80 backdrop-blur-sm border border-[rgba(120,85,59,0.15)] rounded-xl py-2.5 px-3.5 text-sm text-[#1C1917] placeholder-[#A8A29E] focus:outline-none focus:ring-2 focus:ring-[#78553B]/25 focus:border-[#78553B]/40 transition-all';

  const handleImageFileSelect = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setSubmitError('Please select a valid image file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      setForm((prev) => ({ ...prev, image: result }));
      setSubmitError('');
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitError('');

    if (!canSubmit) return;

    setIsSubmitting(true);
    try {
      await onAdd({
        name: form.name.trim(),
        description: form.description.trim(),
        price: Number(form.price),
        category: form.category,
        image: form.image.trim(),
        available: true,
        availabilityTime:
          form.availabilityMode === 'period'
            ? {
                mode: 'period',
                startTime: form.startTime,
                endTime: form.endTime,
              }
            : { mode: 'anytime' },
      });
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : typeof error === 'object' && error !== null && 'message' in error
            ? String((error as { message?: unknown }).message ?? 'Failed to add menu item.')
            : 'Failed to add menu item.';
      setSubmitError(message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.85, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="relative w-full max-w-[400px]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Steam - only shows when filling */}
        <AnimatePresence>
          {fillProgress > 0.4 && (
            <div className="absolute -top-10 left-1/2 -translate-x-1/2 flex gap-3 z-20 pointer-events-none">
              {[0, 1, 2].map((i) => (
                <motion.div
                  key={i}
                  custom={i}
                  variants={steamVariants}
                  initial={{ opacity: 0 }}
                  animate="animate"
                  exit={{ opacity: 0 }}
                  className="w-2 rounded-full bg-[#D4854A]/30"
                  style={{ height: 12 }}
                />
              ))}
            </div>
          )}
        </AnimatePresence>

        {/* Mug Body */}
        <div
          className="relative overflow-hidden z-10"
          style={{
            borderRadius: '16px 16px 40px 40px',
            border: '4px solid #E7E0D8',
            background: '#FBF9F7',
            boxShadow:
              '0 12px 48px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.06), inset 0 1px 0 rgba(255,255,255,0.8)',
          }}
        >
          {/* Coffee Fill Animation - behind the content */}
          <motion.div
            className="absolute bottom-0 left-0 right-0 z-0 pointer-events-none"
            initial={{ height: '0%' }}
            animate={{ height: `${fillProgress * 82}%` }}
            transition={{ type: 'spring', damping: 20, stiffness: 80 }}
            style={{ background: coffeeColor }}
          >
            {/* Coffee wave surface */}
            <div className="absolute top-0 left-0 right-0 -translate-y-1/2 overflow-hidden h-5">
              <motion.svg
                viewBox="0 0 400 20"
                className="w-[200%] h-5"
                animate={{ x: [0, '-50%'] }}
                transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
                preserveAspectRatio="none"
              >
                <path
                  d="M0 10 Q25 4 50 10 Q75 16 100 10 Q125 4 150 10 Q175 16 200 10 Q225 4 250 10 Q275 16 300 10 Q325 4 350 10 Q375 16 400 10 V20 H0Z"
                  fill={coffeeColor}
                  opacity="0.9"
                />
              </motion.svg>
            </div>

            {/* Bubbles */}
            {fillProgress > 0.3 &&
              [
                { left: '20%', size: 4, delay: 0, dur: 2.2 },
                { left: '55%', size: 3, delay: 0.8, dur: 1.8 },
                { left: '75%', size: 5, delay: 1.4, dur: 2.5 },
                { left: '35%', size: 3, delay: 0.4, dur: 2 },
              ].map((b, i) => (
                <motion.div
                  key={i}
                  className="absolute rounded-full bg-white/15"
                  style={{
                    left: b.left,
                    width: b.size,
                    height: b.size,
                    bottom: '10%',
                  }}
                  animate={{
                    y: [0, -30, -60],
                    opacity: [0.4, 0.6, 0],
                    scale: [1, 1.2, 0.8],
                  }}
                  transition={{
                    duration: b.dur,
                    repeat: Infinity,
                    delay: b.delay,
                  }}
                />
              ))}
          </motion.div>

          {/* Foam layer at the top of coffee */}
          <AnimatePresence>
            {fillProgress > 0.2 && (
              <motion.div
                className="absolute left-2 right-2 z-[1] pointer-events-none"
                initial={{ opacity: 0 }}
                animate={{
                  opacity: foamOpacity * 0.7,
                  bottom: `${fillProgress * 82 - 1}%`,
                }}
                transition={{ type: 'spring', damping: 20, stiffness: 80 }}
              >
                <div
                  className="h-3 rounded-full mx-2"
                  style={{
                    background:
                      'linear-gradient(180deg, #F5E6D3 0%, transparent 100%)',
                  }}
                />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Content */}
          <form className="relative z-10 p-6" onSubmit={handleSubmit}>
            {/* Header */}
            <div className="flex justify-between items-center mb-5">
              <div className="flex items-center gap-2">
                <motion.div
                  animate={{ rotate: isComplete ? [0, -15, 15, -10, 10, 0] : 0 }}
                  transition={{ duration: 0.6 }}
                >
                  <Coffee className="w-5 h-5 text-[#78553B]" />
                </motion.div>
                <h3
                  className="tracking-tight"
                  style={{
                    color: fillProgress > 0.6 ? '#FBF9F7' : '#1C1917',
                    transition: 'color 0.5s ease',
                  }}
                >
                  Brew New Item
                </h3>
              </div>
              <button
                onClick={onClose}
                className="p-1 rounded-lg hover:bg-black/5 transition-colors"
                style={{ color: fillProgress > 0.7 ? '#FBF9F7' : '#A8A29E' }}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Fill Progress Indicator */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-1.5">
                <span
                  className="text-xs transition-colors duration-500"
                  style={{
                    color: fillProgress > 0.55 ? 'rgba(251,249,247,0.8)' : '#A8A29E',
                  }}
                >
                  Brewing progress
                </span>
                <span
                  className="text-xs transition-colors duration-500"
                  style={{
                    color: fillProgress > 0.55 ? 'rgba(251,249,247,0.9)' : '#78553B',
                  }}
                >
                  {Math.round(fillProgress * 100)}%
                </span>
              </div>
              <div className="h-1.5 bg-black/5 rounded-full overflow-hidden backdrop-blur-sm">
                <motion.div
                  className="h-full rounded-full"
                  initial={{ width: '0%' }}
                  animate={{ width: `${fillProgress * 100}%` }}
                  transition={{ type: 'spring', damping: 20, stiffness: 100 }}
                  style={{
                    background: `linear-gradient(90deg, #D4A574, ${coffeeColor})`,
                  }}
                />
              </div>
            </div>

            {/* Form Fields */}
            <div className="space-y-3">
              {/* Name */}
              <div>
                <label
                  className="block text-xs mb-1 transition-colors duration-500"
                  style={{
                    color: fillProgress > 0.5 ? 'rgba(251,249,247,0.75)' : '#7C6E65',
                  }}
                >
                  Product Name
                </label>
                <motion.div
                  animate={
                    form.name && form.name.length === 1
                      ? { scale: [1, 1.02, 1] }
                      : {}
                  }
                >
                  <input
                    placeholder="e.g. Caramel Macchiato"
                    value={form.name || ''}
                    onChange={(e) =>
                      setForm((p) => ({ ...p, name: e.target.value }))
                    }
                    className={inputClass}
                  />
                </motion.div>
              </div>

              {/* Description */}
              <div>
                <label
                  className="block text-xs mb-1 transition-colors duration-500"
                  style={{
                    color: fillProgress > 0.5 ? 'rgba(251,249,247,0.75)' : '#7C6E65',
                  }}
                >
                  Description
                </label>
                <textarea
                  placeholder="A rich, creamy blend of..."
                  value={form.description || ''}
                  onChange={(e) =>
                    setForm((p) => ({ ...p, description: e.target.value }))
                  }
                  className={`${inputClass} resize-none h-[68px]`}
                />
              </div>

              {/* Price + Category Row */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label
                    className="block text-xs mb-1 transition-colors duration-500"
                    style={{
                      color:
                        fillProgress > 0.5
                          ? 'rgba(251,249,247,0.75)'
                          : '#7C6E65',
                    }}
                  >
                    Price (₱)
                  </label>
                  <input
                    type="number"
                    placeholder="0.00"
                    value={form.price || ''}
                    onChange={(e) =>
                      setForm((p) => ({
                        ...p,
                        price: Number(e.target.value),
                      }))
                    }
                    className={inputClass}
                  />
                </div>
                <div>
                  <label
                    className="block text-xs mb-1 transition-colors duration-500"
                    style={{
                      color:
                        fillProgress > 0.5
                          ? 'rgba(251,249,247,0.75)'
                          : '#7C6E65',
                    }}
                  >
                    Category
                  </label>
                  <select
                    value={form.category || 'coffee'}
                    onChange={(e) =>
                      setForm((p) => ({
                        ...p,
                        category: e.target.value as MenuCategory,
                      }))
                    }
                    className={inputClass}
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label
                  className="block text-xs transition-colors duration-500"
                  style={{
                    color: fillProgress > 0.5 ? 'rgba(251,249,247,0.75)' : '#7C6E65',
                  }}
                >
                  Availability Time
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setForm((p) => ({ ...p, availabilityMode: 'anytime' }))}
                    className={`rounded-lg py-2 text-xs border transition-colors ${
                      form.availabilityMode === 'anytime'
                        ? 'bg-[#78553B] text-white border-[#78553B]'
                        : 'bg-white/80 text-[#7C6E65] border-[rgba(120,85,59,0.2)]'
                    }`}
                  >
                    Anytime
                  </button>
                  <button
                    type="button"
                    onClick={() => setForm((p) => ({ ...p, availabilityMode: 'period' }))}
                    className={`rounded-lg py-2 text-xs border transition-colors ${
                      form.availabilityMode === 'period'
                        ? 'bg-[#78553B] text-white border-[#78553B]'
                        : 'bg-white/80 text-[#7C6E65] border-[rgba(120,85,59,0.2)]'
                    }`}
                  >
                    Scheduled
                  </button>
                </div>
                {form.availabilityMode === 'period' && (
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs mb-1 text-[#7C6E65]">Start</label>
                      <input
                        type="time"
                        value={form.startTime}
                        onChange={(e) => setForm((p) => ({ ...p, startTime: e.target.value }))}
                        className={inputClass}
                      />
                    </div>
                    <div>
                      <label className="block text-xs mb-1 text-[#7C6E65]">End</label>
                      <input
                        type="time"
                        value={form.endTime}
                        onChange={(e) => setForm((p) => ({ ...p, endTime: e.target.value }))}
                        className={inputClass}
                      />
                    </div>
                  </div>
                )}
                {form.availabilityMode === 'period' && !hasValidPeriod ? (
                  <p className="text-[11px] text-red-500">Start and end time must be different.</p>
                ) : null}
              </div>

              {/* Image Upload */}
              <div className="space-y-2">
                <input
                  type="url"
                  placeholder="Image URL (optional if file uploaded)"
                  value={form.image.startsWith('data:image') ? '' : form.image}
                  onChange={(e) => setForm((p) => ({ ...p, image: e.target.value }))}
                  className={inputClass}
                />
                <label
                  className={`w-full border-2 border-dashed rounded-xl py-3.5 text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    form.image.trim()
                      ? 'border-emerald-400/40 bg-emerald-50/80 text-emerald-600 backdrop-blur-sm'
                      : 'border-[rgba(120,85,59,0.2)] bg-white/60 text-[#A8A29E] hover:border-[#78553B]/40 hover:text-[#78553B] backdrop-blur-sm'
                  }`}
                >
                  <input type="file" accept="image/*" className="hidden" onChange={handleImageFileSelect} />
                  {form.image.trim() ? (
                    <>
                      <Sparkles className="w-4 h-4" />
                      Image Ready
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4" />
                      Upload Product Image
                    </>
                  )}
                </label>
              </div>

              {submitError ? (
                <p className="text-[11px] text-red-500">{submitError}</p>
              ) : null}
            </div>

            {/* Submit Button */}
            <motion.button
              type="submit"
              whileTap={{ scale: 0.97 }}
              disabled={!canSubmit}
              animate={
                canSubmit
                  ? {
                      boxShadow: [
                        '0 0 0 0 rgba(212,133,74,0)',
                        '0 0 0 8px rgba(212,133,74,0.15)',
                        '0 0 0 0 rgba(212,133,74,0)',
                      ],
                    }
                  : {}
              }
              transition={
                canSubmit
                  ? { duration: 1.8, repeat: Infinity }
                  : {}
              }
              className={`w-full mt-4 py-3 rounded-xl text-sm transition-all duration-300 ${
                canSubmit
                  ? 'bg-gradient-to-r from-[#78553B] to-[#D4854A] text-white shadow-lg cursor-pointer'
                  : 'bg-[#E7E0D8] text-[#A8A29E] cursor-not-allowed'
              }`}
            >
              {isSubmitting ? (
                'Adding item...'
              ) : canSubmit ? (
                <span className="flex items-center justify-center gap-2">
                  <Coffee className="w-4 h-4" />
                  Serve to Menu
                </span>
              ) : (
                'Fill all fields correctly...'
              )}
            </motion.button>
          </form>
        </div>

        {/* Saucer */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.15 }}
          className="relative z-0 mx-auto -mt-1"
          style={{ width: '110%', marginLeft: '-5%' }}
        >
          <svg
            viewBox="0 0 440 32"
            fill="none"
            className="w-full"
            preserveAspectRatio="none"
          >
            <ellipse
              cx="220"
              cy="16"
              rx="220"
              ry="16"
              fill="#E7E0D8"
            />
            <ellipse
              cx="220"
              cy="12"
              rx="200"
              ry="10"
              fill="#F0EBE6"
            />
          </svg>
        </motion.div>
      </motion.div>
    </div>
  );
}