import { NavLink, Outlet, useNavigate } from 'react-router';
import { LayoutDashboard, ClipboardList, UtensilsCrossed, BarChart3, Package, LogOut, Menu, X, Coffee } from 'lucide-react';
import { useState } from 'react';


const navItems = [
  { to: '/admin/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/admin/orders', icon: ClipboardList, label: 'Orders' },
  { to: '/admin/menu-management', icon: UtensilsCrossed, label: 'Menu' },
  { to: '/admin/analytics', icon: BarChart3, label: 'Analytics' },
  { to: '/admin/inventory', icon: Package, label: 'Inventory' },
];

type AuthTokenPayload = {
  role?: string;
};

function readCookie(name: string): string | null {
  const value = document.cookie
    .split('; ')
    .find((cookie) => cookie.startsWith(`${name}=`))
    ?.split('=')[1];
  return value ? decodeURIComponent(value) : null;
}

function decodeJwtPayload(token: string): AuthTokenPayload | null {
  try {
    const parts = token.split('.');
    if (parts.length < 2) return null;
    const payload = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const normalized = payload.padEnd(Math.ceil(payload.length / 4) * 4, '=');
    return JSON.parse(atob(normalized)) as AuthTokenPayload;
  } catch {
    return null;
  }
}

type StoredProfile = {
  f_name?: string;
  m_name?: string;
  l_name?: string;
};

function readProfileCookie(name: string): StoredProfile | null {
  const raw = readCookie(name);
  if (!raw) return null;

  try {
    return JSON.parse(raw) as StoredProfile;
  } catch {
    return null;
  }
}

function getFullName(profile: StoredProfile | null): string {
  if (!profile) return '';
  return [profile.f_name, profile.m_name, profile.l_name]
    .map((value) => value?.trim() ?? '')
    .filter(Boolean)
    .join(' ');
}

function getUserIdentityLabel(): string {
  const adminToken = readCookie('admin_token');
  const superAdminToken = readCookie('super_admin_token');
  const token = adminToken ?? superAdminToken;
  if (!token) return 'Cashier';

  const payload = decodeJwtPayload(token);
  const roleLabel = payload?.role === 'super_admin' ? 'Admin' : 'Cashier';
  const profile = adminToken
    ? readProfileCookie('admin_profile')
    : readProfileCookie('super_admin_profile');
  const name = getFullName(profile);

  return name ? `${name} (${roleLabel})` : roleLabel;
}

export function AdminLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const navigate = useNavigate();
  const userIdentity = getUserIdentityLabel();

  const SidebarContent = () => (
    <>
      <div className="flex items-center gap-3 px-5 py-5 border-b border-white/6">
        <img src='/Sugar.jpg' alt="Sugar Cafe" className="w-9 h-9 object-contain bg-white rounded-lg p-0.5" />
        <div>
          <h3 className="text-white text-sm tracking-tight flex items-center gap-1.5">
            SugarFETCH
            <Coffee className="w-3 h-3 text-[#D4854A]" />
          </h3>
          <p className="text-white/50 text-xs">{userIdentity}</p>
        </div>
      </div>
      <nav className="flex-1 py-3 space-y-0.5 px-3">
        {navItems.map(item => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={() => setSidebarOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${
                  isActive
                    ? 'bg-white/10 text-white'
                    : 'text-white/50 hover:bg-white/5 hover:text-white/80'
                }`
              }
            >
              <Icon className="w-[18px] h-[18px]" />
              {item.label}
            </NavLink>
          );
        })}
      </nav>
      <div className="px-3 pb-4">
        <button
          onClick={() => navigate('/admin')}
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-white/40 hover:text-white/80 hover:bg-white/5 w-full transition-all"
        >
          <LogOut className="w-[18px] h-[18px]" />
          Logout
        </button>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-[#F5F3F0] flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-56 bg-[#1C1917] flex-col shrink-0 fixed inset-y-0 left-0 z-30">
        <SidebarContent />
      </aside>

      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <aside className="absolute left-0 top-0 bottom-0 w-56 bg-[#1C1917] flex flex-col z-50">
            <button onClick={() => setSidebarOpen(false)} className="absolute top-4 right-4 text-white/40 hover:text-white/80 transition-colors">
              <X className="w-4 h-4" />
            </button>
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 lg:ml-56 min-h-screen">
        {/* Mobile Header */}
        <div className="lg:hidden sticky top-0 z-20 bg-[#F5F3F0]/80 backdrop-blur-xl px-4 py-3 flex items-center gap-3 border-b border-[rgba(0,0,0,0.04)]">
          <button onClick={() => setSidebarOpen(true)} className="p-2 rounded-lg bg-white border border-[rgba(0,0,0,0.06)]">
            <Menu className="w-4 h-4 text-[#1C1917]" />
          </button>
          <h3 className="text-[#1C1917] tracking-tight text-sm">SugarFETCH</h3>
        </div>
        <div className="p-4 lg:p-6">
          <Outlet />
        </div>
      </main>
    </div>
  );
}