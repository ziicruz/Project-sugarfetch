import { useMemo, useRef, useState } from 'react';
import { Download, TrendingUp, DollarSign, ShoppingBag, ArrowUpRight, Crown, Medal, Loader2, ChevronDown, Calendar, X, FileText, FileSpreadsheet } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell,
} from 'recharts';
import { useSalesAnalyticsQuery, exportAnalyticsReport, type AnalyticsPeriod, type ExportPeriod, type ExportFormat } from '../../../hooks/useAnalytics';

const DONUT_COLORS = ['#D4854A', '#78553B', '#1C1917', '#D6D3D1'];

const tabs = [
  { id: 'daily', label: 'Today' },
  { id: 'weekly', label: 'This Week' },
  { id: 'monthly', label: 'This Month' },
] as const;

const exportOptions: { id: ExportPeriod; label: string }[] = [
  { id: 'weekly', label: 'This Week' },
  { id: 'monthly', label: 'This Month' },
  { id: 'yearly', label: 'This Year' },
  { id: 'range', label: 'Custom Range' },
];

export function Analytics() {
  const [activeTab, setActiveTab] = useState<AnalyticsPeriod>('daily');
  const { data, isLoading, error } = useSalesAnalyticsQuery(activeTab);

  const [showExportMenu, setShowExportMenu] = useState(false);
  const [showRangePicker, setShowRangePicker] = useState(false);
  const [rangeFrom, setRangeFrom] = useState('');
  const [rangeTo, setRangeTo] = useState('');
  const [exportFormat, setExportFormat] = useState<ExportFormat>('csv');
  const [pendingPeriod, setPendingPeriod] = useState<ExportPeriod | null>(null);
  const [exporting, setExporting] = useState(false);
  const [exportError, setExportError] = useState<string | null>(null);
  const exportRef = useRef<HTMLDivElement>(null);

  const xKey = activeTab === 'daily' ? 'time' : activeTab === 'weekly' ? 'day' : 'week';

  const paymentTotal = useMemo(
    () => (data?.paymentMethods ?? []).reduce((a, b) => a + b.count, 0),
    [data?.paymentMethods],
  );

  const doExport = async (period: ExportPeriod, format: ExportFormat, range?: { from: string; to: string }) => {
    setExporting(true);
    setExportError(null);
    try {
      await exportAnalyticsReport(period, { format, range });
    } catch (err: any) {
      setExportError(err?.message ?? 'Export failed');
    } finally {
      setExporting(false);
    }
  };

  const handleExport = (period: ExportPeriod) => {
    setShowExportMenu(false);
    if (period === 'range') {
      setPendingPeriod('range');
      setShowRangePicker(true);
      return;
    }
    setPendingPeriod(period);
    setShowFormatPicker(true);
  };

  const [showFormatPicker, setShowFormatPicker] = useState(false);

  const handleFormatSelect = (format: ExportFormat) => {
    setShowFormatPicker(false);
    if (pendingPeriod && pendingPeriod !== 'range') {
      doExport(pendingPeriod, format);
    }
    setPendingPeriod(null);
  };

  const handleRangeExport = async () => {
    if (!rangeFrom || !rangeTo) return;
    setShowRangePicker(false);
    doExport('range', exportFormat, { from: rangeFrom, to: rangeTo });
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-2xl p-10 border border-[rgba(0,0,0,0.04)] text-center">
        <Loader2 className="w-6 h-6 animate-spin text-[#78553B] mx-auto mb-3" />
        <p className="text-sm text-[#7C6E65]">Loading analytics...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-600">
        {error.message}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between flex-wrap gap-3"
      >
        <div>
          <h2 className="text-[#1C1917] text-xl tracking-tight font-semibold">Analytics</h2>
          <p className="text-[#A8A29E] text-sm mt-0.5">Track performance and insights</p>
        </div>
        <div className="relative" ref={exportRef}>
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => setShowExportMenu(!showExportMenu)}
            disabled={exporting}
            className="bg-[#1C1917] text-white px-4 py-2.5 rounded-xl text-sm flex items-center gap-2 hover:bg-[#292524] transition-colors shadow-sm"
          >
            {exporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
            {exporting ? 'Exporting...' : 'Export Report'}
            <ChevronDown className={`w-3 h-3 transition-transform ${showExportMenu ? 'rotate-180' : ''}`} />
          </motion.button>

          <AnimatePresence>
            {showExportMenu && (
              <motion.div
                initial={{ opacity: 0, y: -4, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -4, scale: 0.95 }}
                transition={{ duration: 0.12 }}
                className="absolute right-0 top-full mt-1.5 bg-white rounded-xl border border-[rgba(0,0,0,0.08)] shadow-xl shadow-black/[0.08] overflow-hidden z-30 min-w-[180px]"
              >
                {exportOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => handleExport(opt.id)}
                    className="w-full text-left px-4 py-2.5 text-sm text-[#1C1917] hover:bg-[#F5F0EB] transition-colors flex items-center gap-2.5"
                  >
                    {opt.id === 'range' ? <Calendar className="w-3.5 h-3.5 text-[#78553B]" /> : <Download className="w-3.5 h-3.5 text-[#A8A29E]" />}
                    {opt.label}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>

          <AnimatePresence>
            {showFormatPicker && (
              <motion.div
                initial={{ opacity: 0, y: -4, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -4, scale: 0.95 }}
                transition={{ duration: 0.12 }}
                className="absolute right-0 top-full mt-1.5 bg-white rounded-xl border border-[rgba(0,0,0,0.08)] shadow-xl shadow-black/[0.08] z-30 overflow-hidden min-w-[180px]"
              >
                <div className="px-4 py-2 border-b border-[rgba(0,0,0,0.06)]">
                  <p className="text-[10px] text-[#A8A29E] uppercase tracking-wide font-medium">Choose format</p>
                </div>
                <button
                  onClick={() => handleFormatSelect('csv')}
                  className="w-full text-left px-4 py-2.5 text-sm text-[#1C1917] hover:bg-[#F5F0EB] transition-colors flex items-center gap-2.5"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-green-600" />
                  CSV Spreadsheet
                </button>
                <button
                  onClick={() => handleFormatSelect('pdf')}
                  className="w-full text-left px-4 py-2.5 text-sm text-[#1C1917] hover:bg-[#F5F0EB] transition-colors flex items-center gap-2.5"
                >
                  <FileText className="w-3.5 h-3.5 text-red-500" />
                  PDF Document
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          <AnimatePresence>
            {showRangePicker && (
              <motion.div
                initial={{ opacity: 0, y: -4, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -4, scale: 0.95 }}
                transition={{ duration: 0.12 }}
                className="absolute right-0 top-full mt-1.5 bg-white rounded-xl border border-[rgba(0,0,0,0.08)] shadow-xl shadow-black/[0.08] z-30 p-4 min-w-[260px]"
              >
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-medium text-[#1C1917]">Custom Range</h4>
                  <button onClick={() => setShowRangePicker(false)} className="p-1 rounded-lg hover:bg-[#F5F0EB] text-[#A8A29E]">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="space-y-2.5">
                  <div>
                    <label className="text-[10px] text-[#A8A29E] uppercase tracking-wide">From</label>
                    <input
                      type="date"
                      value={rangeFrom}
                      onChange={(e) => setRangeFrom(e.target.value)}
                      className="w-full mt-0.5 px-3 py-2 border border-[rgba(0,0,0,0.08)] rounded-lg text-sm text-[#1C1917] focus:outline-none focus:ring-2 focus:ring-[#78553B]/20"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-[#A8A29E] uppercase tracking-wide">To</label>
                    <input
                      type="date"
                      value={rangeTo}
                      onChange={(e) => setRangeTo(e.target.value)}
                      className="w-full mt-0.5 px-3 py-2 border border-[rgba(0,0,0,0.08)] rounded-lg text-sm text-[#1C1917] focus:outline-none focus:ring-2 focus:ring-[#78553B]/20"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-[#A8A29E] uppercase tracking-wide">Format</label>
                    <div className="flex gap-2 mt-1">
                      <button
                        onClick={() => setExportFormat('csv')}
                        className={`flex-1 py-2 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-colors ${exportFormat === 'csv' ? 'bg-[#1C1917] text-white' : 'bg-[#F5F0EB] text-[#78553B] hover:bg-[#EDE7E0]'}`}
                      >
                        <FileSpreadsheet className="w-3 h-3" /> CSV
                      </button>
                      <button
                        onClick={() => setExportFormat('pdf')}
                        className={`flex-1 py-2 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-colors ${exportFormat === 'pdf' ? 'bg-[#1C1917] text-white' : 'bg-[#F5F0EB] text-[#78553B] hover:bg-[#EDE7E0]'}`}
                      >
                        <FileText className="w-3 h-3" /> PDF
                      </button>
                    </div>
                  </div>
                  <button
                    onClick={handleRangeExport}
                    disabled={!rangeFrom || !rangeTo || exporting}
                    className="w-full py-2.5 rounded-xl text-sm font-medium bg-[#78553B] text-white hover:bg-[#5F432E] disabled:opacity-40 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Export Range
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>

      {exportError && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-sm text-red-600 flex items-center justify-between">
          {exportError}
          <button onClick={() => setExportError(null)} className="text-red-400 hover:text-red-600">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Period Tabs */}
      <div className="bg-white rounded-xl p-1 inline-flex gap-0.5 border border-[rgba(0,0,0,0.05)]">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as AnalyticsPeriod)}
            className={`relative px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
              activeTab === tab.id
                ? 'text-white'
                : 'text-[#78756F] hover:text-[#1C1917]'
            }`}
          >
            {activeTab === tab.id && (
              <motion.div
                layoutId="activeTab"
                className="absolute inset-0 bg-[#1C1917] rounded-lg"
                transition={{ type: 'spring', stiffness: 380, damping: 30 }}
              />
            )}
            <span className="relative z-10">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Total Revenue', value: `₱${(data?.summary.revenue ?? 0).toLocaleString()}`, change: data?.summary.revenueChange ?? '0%', icon: DollarSign, gradient: 'from-[#D4854A] to-[#78553B]' },
          { label: 'Total Orders', value: String(data?.summary.orders ?? 0), change: data?.summary.orderChange ?? '0', icon: ShoppingBag, gradient: 'from-blue-500 to-indigo-600' },
          { label: 'Avg per Order', value: `₱${(data?.summary.averagePerOrder ?? 0).toLocaleString()}`, change: '', icon: TrendingUp, gradient: 'from-emerald-500 to-teal-600' },
        ].map((card, idx) => {
          const Icon = card.icon;
          return (
            <motion.div
              key={card.label}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="bg-white rounded-2xl p-4 border border-[rgba(0,0,0,0.04)] hover:shadow-lg hover:shadow-black/[0.03] transition-all duration-300"
            >
              <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${card.gradient} flex items-center justify-center mb-3 shadow-sm`}>
                <Icon className="w-4 h-4 text-white" />
              </div>
              <p className="text-[#A8A29E] text-xs">{card.label}</p>
              <p className="text-[#1C1917] text-xl font-semibold tracking-tight mt-0.5">{card.value}</p>
              {card.change && (
                <span className="inline-flex items-center gap-0.5 text-[11px] text-emerald-600 font-medium mt-1">
                  <ArrowUpRight className="w-3 h-3" />
                  {card.change}
                </span>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* Main Charts */}
      <div className="grid lg:grid-cols-5 gap-4">
        {/* Revenue Chart - spans 3 cols */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="lg:col-span-3 bg-white rounded-2xl p-5 border border-[rgba(0,0,0,0.04)]"
        >
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="text-[#1C1917] text-sm font-medium">Revenue Overview</h3>
              <p className="text-[#A8A29E] text-xs mt-0.5">{activeTab === 'daily' ? 'By hour' : activeTab === 'weekly' ? 'By day' : 'By week'}</p>
            </div>
          </div>
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="h-72"
            >
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data?.revenueSeries ?? []}>
                  <defs>
                    <linearGradient id="analyticsGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#D4854A" stopOpacity={0.2} />
                      <stop offset="100%" stopColor="#D4854A" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.04)" vertical={false} />
                  <XAxis
                    dataKey={xKey}
                    tick={{ fill: '#A8A29E', fontSize: 11 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fill: '#A8A29E', fontSize: 11 }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v: number) =>
                      v >= 1000 ? `₱${(v / 1000).toFixed(0)}k` : `₱${v}`
                    }
                  />
                  <Tooltip
                    contentStyle={{
                      borderRadius: '12px',
                      border: '1px solid rgba(0,0,0,0.06)',
                      boxShadow: '0 8px 24px rgba(0,0,0,0.08)',
                      fontSize: '12px',
                      padding: '8px 12px',
                    }}
                    formatter={(value: number) => [`₱${value.toLocaleString()}`, 'Sales']}
                  />
                  <Area
                    type="monotone"
                    dataKey="sales"
                    stroke="#D4854A"
                    strokeWidth={2.5}
                    fill="url(#analyticsGrad)"
                    dot={false}
                    activeDot={{ r: 5, fill: '#D4854A', strokeWidth: 2, stroke: '#fff' }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </motion.div>
          </AnimatePresence>
        </motion.div>

        {/* Payment Donut - spans 2 cols */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-2 bg-white rounded-2xl p-5 border border-[rgba(0,0,0,0.04)]"
        >
          <h3 className="text-[#1C1917] text-sm font-medium mb-1">Payment Methods</h3>
          <p className="text-[#A8A29E] text-xs mb-4">Distribution by volume</p>

          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data?.paymentMethods ?? []}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={78}
                  paddingAngle={4}
                  dataKey="value"
                  nameKey="name"
                  cornerRadius={6}
                  strokeWidth={0}
                >
                  {(data?.paymentMethods ?? []).map((_, idx) => (
                    <Cell key={idx} fill={DONUT_COLORS[idx % DONUT_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    borderRadius: '10px',
                    border: '1px solid rgba(0,0,0,0.06)',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                    fontSize: '12px',
                    padding: '6px 10px',
                  }}
                  formatter={(value: number) => [`${value}%`, 'Share']}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-2 mt-2">
            {(data?.paymentMethods ?? []).map((pm, idx) => (
              <div key={pm.name} className="flex items-center gap-2.5">
                <span
                  className="w-2.5 h-2.5 rounded-full shrink-0"
                  style={{ backgroundColor: DONUT_COLORS[idx % DONUT_COLORS.length] }}
                />
                <span className="text-[#57534E] text-xs flex-1">{pm.name}</span>
                <span className="text-[#1C1917] text-xs font-medium tabular-nums">{pm.value}%</span>
                <div className="w-16 h-1.5 bg-[#F5F3F0] rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${((pm.count || 0) / (paymentTotal || 1)) * 100}%`,
                      backgroundColor: DONUT_COLORS[idx % DONUT_COLORS.length],
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Best Selling Items */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25 }}
        className="bg-white rounded-2xl p-5 border border-[rgba(0,0,0,0.04)]"
      >
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="text-[#1C1917] text-sm font-medium">Top Sellers</h3>
            <p className="text-[#A8A29E] text-xs mt-0.5">Best performing menu items</p>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {(data?.bestSelling ?? []).map((item, idx) => {
            const maxSold = data?.bestSelling?.[0]?.sold || 1;
            const pct = Math.round((item.sold / maxSold) * 100);

            return (
              <motion.div
                key={item.name}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + idx * 0.04 }}
                className={`relative rounded-xl p-4 border overflow-hidden transition-all duration-300 ${
                  idx === 0
                    ? 'bg-gradient-to-br from-[#1C1917] to-[#292524] border-transparent text-white'
                    : 'bg-[#FAFAF8] border-[rgba(0,0,0,0.04)] hover:shadow-md hover:shadow-black/[0.03]'
                }`}
              >
                <div className="flex items-center gap-2 mb-3">
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${
                    idx === 0
                      ? 'bg-[#D4854A] text-white'
                      : idx === 1
                        ? 'bg-amber-100 text-amber-700'
                        : idx === 2
                          ? 'bg-orange-50 text-orange-600'
                          : 'bg-[#F0EBE6] text-[#7C6E65]'
                  }`}>
                    {idx === 0 ? <Crown className="w-3.5 h-3.5" /> : idx < 3 ? <Medal className="w-3.5 h-3.5" /> : `#${idx + 1}`}
                  </div>
                  <span className={`text-[11px] font-medium ${idx === 0 ? 'text-[#D4854A]' : 'text-[#A8A29E]'}`}>
                    {pct}% of top
                  </span>
                </div>

                <p className={`text-sm font-medium truncate mb-0.5 ${idx === 0 ? 'text-white' : 'text-[#1C1917]'}`}>
                  {item.name}
                </p>
                <p className={`text-lg font-semibold tabular-nums ${idx === 0 ? 'text-white' : 'text-[#1C1917]'}`}>
                  {item.sold}
                  <span className={`text-xs font-normal ml-1 ${idx === 0 ? 'text-white/50' : 'text-[#A8A29E]'}`}>sold</span>
                </p>

                <div className={`mt-3 h-1.5 rounded-full overflow-hidden ${idx === 0 ? 'bg-white/15' : 'bg-[#F0EBE6]'}`}>
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${pct}%` }}
                    transition={{ duration: 0.8, delay: 0.4 + idx * 0.06 }}
                    className={`h-full rounded-full ${idx === 0 ? 'bg-[#D4854A]' : 'bg-[#78553B]'}`}
                  />
                </div>
              </motion.div>
            );
          })}
        </div>
      </motion.div>
    </div>
  );
}
