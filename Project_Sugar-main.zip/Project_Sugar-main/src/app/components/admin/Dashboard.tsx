import { useEffect, useState } from 'react';
import { DollarSign, ShoppingBag, Coffee, ArrowUpRight, ArrowDownRight, Clock, Flame, Loader2, Bell, BellRing, AlertTriangle } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { motion } from 'motion/react';
import { useDashboardAnalyticsQuery } from '../../../hooks/useAnalytics';
import { useOrdersQuery } from '../../../hooks/useOrderManagement';

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

function formatDate(): string {
  return new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });
}

export function Dashboard() {
  const { data, isLoading, error } = useDashboardAnalyticsQuery();
  const { data: orders = [] } = useOrdersQuery();
  const [showNotifications, setShowNotifications] = useState(false);
  const [hasNewOrder, setHasNewOrder] = useState(false);
  const [latestOrderId, setLatestOrderId] = useState<string | null>(null);
  const summary = data?.summary;
  const recentOrders = data?.recentOrders ?? [];
  const alerts = data?.alerts ?? [];
  const latestOrder = orders[0];
  const latestOrderLabel = latestOrder?.orderNumber || latestOrder?._id.slice(-8) || 'New order';
  const latestOrderName = latestOrder?.customerName || 'Customer';
  const latestOrderItems = latestOrder?.cart.length ?? 0;
  const latestOrderAmount = latestOrder?.amount ?? 0;
  const orderNoticeStorageKey = 'sugar_admin_last_seen_order_id';
  const statCards = [
    {
      label: "Today's Revenue",
      value: `₱${(summary?.revenueToday ?? 0).toLocaleString()}`,
      change: '+Live',
      trend: 'up' as const,
      icon: DollarSign,
      gradient: 'from-emerald-500 to-teal-600',
      bgGlow: 'bg-emerald-500/10',
    },
    {
      label: 'Orders Today',
      value: String(summary?.ordersToday ?? 0),
      change: `${summary?.inProgressToday ?? 0} active`,
      trend: 'up' as const,
      icon: ShoppingBag,
      gradient: 'from-blue-500 to-indigo-600',
      bgGlow: 'bg-blue-500/10',
    },
    {
      label: 'Best Seller',
      value: summary?.bestSeller ?? 'No sales yet',
      change: `${summary?.topItems?.[0]?.sold ?? 0} sold`,
      trend: 'up' as const,
      icon: Flame,
      gradient: 'from-amber-500 to-orange-600',
      bgGlow: 'bg-amber-500/10',
    },
    {
      label: 'Completed Today',
      value: `${summary?.completedToday ?? 0} orders`,
      change: `${summary?.inProgressToday ?? 0} in progress`,
      trend: 'down' as const,
      icon: Clock,
      gradient: 'from-[#78553B] to-[#5F432E]',
      bgGlow: 'bg-[#78553B]/10',
    },
  ];

  useEffect(() => {
    if (!latestOrder || typeof window === 'undefined') {
      setHasNewOrder(false);
      setShowNotifications(false);
      return;
    }

    const lastSeen = window.localStorage.getItem(orderNoticeStorageKey);
    const isNew = lastSeen !== latestOrder._id;
    setHasNewOrder(isNew);
    if (isNew) {
      setLatestOrderId(latestOrder._id);
      setShowNotifications(true);
    }
  }, [latestOrder, orderNoticeStorageKey]);

  if (isLoading) {
    return (
      <div className="bg-white rounded-2xl p-10 border border-[rgba(0,0,0,0.04)] text-center">
        <Loader2 className="w-6 h-6 animate-spin text-[#78553B] mx-auto mb-3" />
        <p className="text-sm text-[#7C6E65]">Loading dashboard analytics...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-600">
        {error.message}
      </div>
    );
  }

  const markOrderAsRead = () => {
    if (!latestOrderId || typeof window === 'undefined') return;
    window.localStorage.setItem(orderNoticeStorageKey, latestOrderId);
    setHasNewOrder(false);
    setShowNotifications(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-start justify-between"
      >
        <div>
          <div className="flex items-center gap-2.5 mb-1">
            <h2 className="text-[#1C1917] text-xl tracking-tight font-semibold">
              {getGreeting()}, Admin
            </h2>
            <motion.div
              animate={{ rotate: [0, -8, 8, -4, 0] }}
              transition={{ duration: 2, repeat: Infinity, repeatDelay: 5 }}
            >
              <Coffee className="w-5 h-5 text-[#D4854A]" />
            </motion.div>
          </div>
          <p className="text-[#A8A29E] text-sm">{formatDate()}</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowNotifications((prev) => !prev)}
            className="relative p-2.5 rounded-xl bg-white border border-[rgba(0,0,0,0.06)] transition-colors hover:bg-[#F5F0EB]"
          >
            <Bell className="w-[18px] h-[18px] text-[#78553B]" />
            {hasNewOrder && (
              <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-amber-400 border-2 border-white" />
            )}
          </button>
          <div className="flex items-center gap-2 text-xs text-[#A8A29E] bg-white rounded-lg px-3 py-2 border border-[rgba(0,0,0,0.05)]">
            <Clock className="w-3.5 h-3.5" />
            Live
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          </div>
        </div>
      </motion.div>

      {hasNewOrder && showNotifications && (
        <motion.div
          initial={{ opacity: 0, y: -6 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 text-sm text-amber-800 flex items-center justify-between"
        >
          <div>
            <p className="font-medium">New order received</p>
            <p className="text-xs text-amber-700 mt-0.5">
              Order {latestOrderLabel} · {latestOrderName} · {latestOrderItems} item{latestOrderItems !== 1 ? 's' : ''}
            </p>
            <p className="text-xs text-amber-700 mt-0.5">Total ₱{latestOrderAmount.toLocaleString()}</p>
          </div>
          <button
            onClick={markOrderAsRead}
            className="text-xs font-medium text-amber-700 hover:text-amber-900"
          >
            Mark as read
          </button>
        </motion.div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {statCards.map((card, idx) => {
          const Icon = card.icon;
          return (
            <motion.div
              key={card.label}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.06 }}
              className="group relative bg-white rounded-2xl p-4 border border-[rgba(0,0,0,0.04)] overflow-hidden hover:shadow-lg hover:shadow-black/[0.03] transition-all duration-300"
            >
              <div className={`absolute -top-8 -right-8 w-24 h-24 rounded-full ${card.bgGlow} blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />

              <div className="relative">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${card.gradient} flex items-center justify-center mb-3 shadow-lg shadow-black/[0.08]`}>
                  <Icon className="w-[18px] h-[18px] text-white" />
                </div>
                <p className="text-[#A8A29E] text-xs mb-0.5">{card.label}</p>
                <p className="text-[#1C1917] text-xl font-semibold tracking-tight">{card.value}</p>
                <div className="flex items-center gap-1 mt-1.5">
                  {card.trend === 'up' ? (
                    <ArrowUpRight className="w-3 h-3 text-emerald-500" />
                  ) : (
                    <ArrowDownRight className="w-3 h-3 text-red-500" />
                  )}
                  <span className={`text-[11px] font-medium ${card.trend === 'up' ? 'text-emerald-600' : 'text-red-500'}`}>
                    {card.change}
                  </span>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Alerts / Notifications */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-2xl p-5 border border-[rgba(0,0,0,0.04)]"
      >
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-[#1C1917] text-sm font-medium flex items-center gap-2">
              <BellRing className="w-4 h-4 text-[#78553B]" />
              Alerts & Notifications
            </h3>
            <p className="text-[#A8A29E] text-xs mt-0.5">
              {alerts.length} notification{alerts.length !== 1 ? 's' : ''} for today
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-2.5">
          {alerts.map((alert, idx) => (
            <motion.div
              key={`${alert.title}-${idx}`}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.22 + idx * 0.05 }}
              className={`rounded-xl border px-3.5 py-3 ${
                alert.level === 'warning'
                  ? 'bg-amber-50 border-amber-200'
                  : 'bg-[#F8F6F3] border-[#EAE4DD]'
              }`}
            >
              <div className="flex items-start gap-2.5">
                {alert.level === 'warning' ? (
                  <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
                ) : (
                  <BellRing className="w-4 h-4 text-[#78553B] mt-0.5 shrink-0" />
                )}
                <div>
                  <p
                    className={`text-xs font-semibold ${
                      alert.level === 'warning' ? 'text-amber-800' : 'text-[#1C1917]'
                    }`}
                  >
                    {alert.title}
                  </p>
                  <p className="text-xs text-[#6B645E] mt-0.5">{alert.message}</p>
                </div>
              </div>
            </motion.div>
          ))}
          {alerts.length === 0 && (
            <div className="rounded-xl border border-[#EAE4DD] bg-[#F8F6F3] px-3.5 py-4 text-xs text-[#7C6E65]">
              No alerts right now.
            </div>
          )}
        </div>
      </motion.div>

      {/* Sales Chart */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25 }}
        className="bg-white rounded-2xl p-5 border border-[rgba(0,0,0,0.04)] overflow-hidden"
      >
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="text-[#1C1917] text-sm font-medium">Today's Sales</h3>
            <p className="text-[#A8A29E] text-xs mt-0.5">Hourly revenue breakdown</p>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-semibold text-[#1C1917] tracking-tight">
              ₱{(summary?.revenueToday ?? 0).toLocaleString()}
            </span>
            <span className="flex items-center gap-0.5 text-xs text-emerald-600 font-medium">
              <ArrowUpRight className="w-3 h-3" />
              live
            </span>
          </div>
        </div>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data?.hourlySales ?? []}>
              <defs>
                <linearGradient id="salesGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#D4854A" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#D4854A" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.04)" vertical={false} />
              <XAxis
                dataKey="time"
                tick={{ fill: '#A8A29E', fontSize: 11 }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tick={{ fill: '#A8A29E', fontSize: 11 }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(v: number) => `₱${(v / 1000).toFixed(0)}k`}
              />
              <Tooltip
                contentStyle={{
                  borderRadius: '12px',
                  border: '1px solid rgba(0,0,0,0.06)',
                  boxShadow: '0 8px 24px rgba(0,0,0,0.08)',
                  fontSize: '12px',
                  padding: '8px 12px',
                }}
                formatter={(value: number) => [`₱${value.toLocaleString()}`, 'Revenue']}
              />
              <Area
                type="monotone"
                dataKey="sales"
                stroke="#D4854A"
                strokeWidth={2.5}
                fill="url(#salesGradient)"
                dot={false}
                activeDot={{ r: 5, fill: '#D4854A', strokeWidth: 2, stroke: '#fff' }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Recent Orders */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-white rounded-2xl border border-[rgba(0,0,0,0.04)] overflow-hidden"
      >
        <div className="flex items-center justify-between p-5 pb-0">
          <div>
            <h3 className="text-[#1C1917] text-sm font-medium">Recent Orders</h3>
            <p className="text-[#A8A29E] text-xs mt-0.5">{recentOrders.length} recent orders</p>
          </div>
          <button className="text-xs text-[#D4854A] hover:text-[#78553B] font-medium transition-colors">
            View all
          </button>
        </div>
        <div className="overflow-x-auto px-5 pb-5 pt-4">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[#A8A29E]">
                <th className="text-left py-2.5 pr-4 text-[11px] uppercase tracking-wider font-medium">Order</th>
                <th className="text-left py-2.5 pr-4 text-[11px] uppercase tracking-wider font-medium">Customer</th>
                <th className="text-left py-2.5 pr-4 text-[11px] uppercase tracking-wider font-medium">Items</th>
                <th className="text-left py-2.5 pr-4 text-[11px] uppercase tracking-wider font-medium">Total</th>
                <th className="text-left py-2.5 pr-4 text-[11px] uppercase tracking-wider font-medium">Payment</th>
                <th className="text-left py-2.5 text-[11px] uppercase tracking-wider font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {recentOrders.map((order, idx) => (
                <motion.tr
                  key={order._id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.35 + idx * 0.04 }}
                  className="border-t border-[rgba(0,0,0,0.04)] group hover:bg-[#FAFAF8] transition-colors"
                >
                  <td className="py-3.5 pr-4">
                    <span className="text-[#1C1917] font-medium">{order.orderNumber || order._id.slice(-8)}</span>
                  </td>
                  <td className="py-3.5 pr-4">
                    <span className="bg-[#F5F0EB] text-[#78553B] text-xs px-2 py-0.5 rounded-md font-medium">
                      {order.customerName}
                    </span>
                  </td>
                  <td className="py-3.5 pr-4 text-[#57534E]">
                    {order.cart.length} item{order.cart.length !== 1 ? 's' : ''}
                  </td>
                  <td className="py-3.5 pr-4">
                    <span className="text-[#1C1917] font-medium tabular-nums">₱{order.amount.toLocaleString()}</span>
                  </td>
                  <td className="py-3.5 pr-4">
                    <span className="text-[#57534E] text-xs">{order.paymentMethod}</span>
                  </td>
                  <td className="py-3.5">
                    <StatusBadge status={order.status} />
                  </td>
                </motion.tr>
              ))}
              {recentOrders.length === 0 && (
                <tr className="border-t border-[rgba(0,0,0,0.04)]">
                  <td colSpan={6} className="py-8 text-center text-sm text-[#A8A29E]">
                    No orders yet today
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { bg: string; text: string; dot: string }> = {
    received: { bg: 'bg-blue-50', text: 'text-blue-700', dot: 'bg-blue-500' },
    preparing: { bg: 'bg-amber-50', text: 'text-amber-700', dot: 'bg-amber-500' },
    ready: { bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500' },
    completed: { bg: 'bg-[#F5F3F0]', text: 'text-[#A8A29E]', dot: 'bg-[#D6D3D1]' },
  };
  const c = config[status] ?? config.completed;
  return (
    <span className={`inline-flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full font-medium capitalize ${c.bg} ${c.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${c.dot} ${status === 'preparing' ? 'animate-pulse' : ''}`} />
      {status}
    </span>
  );
}
