import { useMemo, useState } from 'react';
import { Package, Search, Plus, Pencil, AlertTriangle, X, Loader2, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import {
  useInventoriesQuery,
  useCreateInventoryMutation,
  useUpdateInventoryMutation,
  useDeleteInventoryMutation,
  type InventoryItemApi,
} from '../../../hooks/useInventory';
import type { CreateInventoryInput } from '../../../schema/inventorySchema';

const CATEGORIES = ['All', 'Cups', 'Accessories', 'Packaging', 'Coffee', 'Dairy', 'Sweetener', 'Powder', 'Toppings', 'Ice', 'Water'];

const categoryColors: Record<string, string> = {
  Cups: 'bg-sky-50 text-sky-700',
  Accessories: 'bg-violet-50 text-violet-700',
  Packaging: 'bg-amber-50 text-amber-700',
  Coffee: 'bg-[#78553B]/10 text-[#78553B]',
  Dairy: 'bg-blue-50 text-blue-700',
  Sweetener: 'bg-rose-50 text-rose-700',
  Powder: 'bg-purple-50 text-purple-700',
  Toppings: 'bg-emerald-50 text-emerald-700',
  Ice: 'bg-cyan-50 text-cyan-700',
  Water: 'bg-teal-50 text-teal-700',
};

const emptyForm: CreateInventoryInput = {
  skuCode: '',
  itemName: '',
  category: '',
  unit: '',
  stockQuantity: 0,
  reorderLevel: 0,
  unitCost: 0,
};

export function InventoryManagement() {
  const { data: items = [], isLoading, error } = useInventoriesQuery();
  const createInventoryMutation = useCreateInventoryMutation();
  const updateInventoryMutation = useUpdateInventoryMutation();
  const deleteInventoryMutation = useDeleteInventoryMutation();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItemApi | null>(null);
  const [form, setForm] = useState<CreateInventoryInput>(emptyForm);

  const isMutating =
    createInventoryMutation.isPending ||
    updateInventoryMutation.isPending ||
    deleteInventoryMutation.isPending;
  const mutationError =
    createInventoryMutation.error ?? updateInventoryMutation.error ?? deleteInventoryMutation.error;

  const filtered = useMemo(() => {
    return items
      .filter((item) => {
        const matchCat = activeCategory === 'All' || item.category === activeCategory;
        const matchSearch =
          item.itemName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.skuCode.toLowerCase().includes(searchQuery.toLowerCase());
        return matchCat && matchSearch;
      })
      .sort((a, b) => a.category.localeCompare(b.category) || a.itemName.localeCompare(b.itemName));
  }, [items, activeCategory, searchQuery]);

  const stats = useMemo(() => {
    const total = items.length;
    const lowStock = items.filter((i) => i.stockQuantity <= i.reorderLevel && i.stockQuantity > 0).length;
    const outOfStock = items.filter((i) => i.stockQuantity === 0).length;
    const totalValue = items.reduce((sum, i) => sum + i.stockQuantity * i.unitCost, 0);
    return { total, lowStock, outOfStock, totalValue };
  }, [items]);

  const openAdd = () => {
    setForm(emptyForm);
    setEditingItem(null);
    setShowAddModal(true);
  };

  const openEdit = (item: InventoryItemApi) => {
    setShowAddModal(false);
    setForm({
      skuCode: item.skuCode,
      itemName: item.itemName,
      category: item.category,
      unit: item.unit,
      stockQuantity: item.stockQuantity,
      reorderLevel: item.reorderLevel,
      unitCost: item.unitCost,
    });
    setEditingItem(item);
  };

  const closeModal = () => {
    setShowAddModal(false);
    setEditingItem(null);
    setForm(emptyForm);
  };

  const updateField = (field: keyof CreateInventoryInput, value: string | number) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const isModalOpen = showAddModal || editingItem !== null;

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    try {
      if (editingItem) {
        await updateInventoryMutation.mutateAsync({
          id: editingItem._id,
          payload: form,
        });
        closeModal();
        return;
      }

      await createInventoryMutation.mutateAsync(form);
      closeModal();
    } catch {
      // Errors are surfaced via mutationError UI block.
    }
  };

  const handleDelete = async (item: InventoryItemApi) => {
    const confirmed = window.confirm(`Delete ${item.itemName}? This action cannot be undone.`);
    if (!confirmed) return;

    try {
      await deleteInventoryMutation.mutateAsync({ id: item._id });
      if (editingItem?._id === item._id) {
        closeModal();
      }
    } catch {
      // Errors are surfaced via mutationError UI block.
    }
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-[#1C1917] tracking-tight text-lg font-semibold flex items-center gap-2">
            Inventory
            <Package className="w-4 h-4 text-[#D4854A]" />
          </h2>
          <p className="text-[#A8A29E] text-sm mt-0.5">
            {stats.total} items &middot; ₱{stats.totalValue.toLocaleString(undefined, { minimumFractionDigits: 2 })} total value
          </p>
        </div>
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={openAdd}
          disabled={isMutating}
          className="bg-gradient-to-r from-[#78553B] to-[#D4854A] text-white px-5 py-2.5 rounded-xl flex items-center gap-2 hover:shadow-lg hover:shadow-[#D4854A]/20 transition-all text-sm font-medium shrink-0"
        >
          {createInventoryMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
          {createInventoryMutation.isPending ? 'Adding...' : 'Add Item'}
        </motion.button>
      </div>

      {mutationError && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-600">
          {mutationError.message}
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Total Items', value: stats.total, color: 'bg-[#78553B]/10 text-[#78553B]', icon: Package },
          { label: 'Low Stock', value: stats.lowStock, color: 'bg-amber-50 text-amber-600', icon: AlertTriangle },
          { label: 'Out of Stock', value: stats.outOfStock, color: 'bg-red-50 text-red-500', icon: AlertTriangle },
          { label: 'Total Value', value: `₱${stats.totalValue.toLocaleString()}`, color: 'bg-emerald-50 text-emerald-600', icon: Package },
        ].map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-white rounded-xl border border-[rgba(0,0,0,0.04)] p-3.5 flex items-center gap-3">
              <div className={`w-9 h-9 rounded-lg ${stat.color} flex items-center justify-center shrink-0`}>
                <Icon className="w-4 h-4" />
              </div>
              <div>
                <p className="text-lg font-semibold text-[#1C1917] leading-tight">{stat.value}</p>
                <p className="text-[10px] text-[#A8A29E] uppercase tracking-wide">{stat.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Search & Category Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A8A29E]" />
          <input
            type="text"
            placeholder="Search by name or SKU..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white border border-[rgba(0,0,0,0.06)] rounded-xl py-2.5 pl-10 pr-4 text-sm text-[#1C1917] placeholder-[#C7BBB1] focus:outline-none focus:ring-2 focus:ring-[#78553B]/20 focus:border-[#78553B]/30 transition-shadow"
          />
        </div>
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`shrink-0 px-3.5 py-2 rounded-lg text-xs font-medium transition-all ${
                activeCategory === cat
                  ? 'bg-[#78553B] text-white shadow-sm'
                  : 'bg-white text-[#7C6E65] border border-[rgba(0,0,0,0.06)] hover:border-[rgba(0,0,0,0.12)]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-[rgba(0,0,0,0.04)] overflow-hidden">
        {isLoading && (
          <div className="py-12 text-center border-b border-[rgba(0,0,0,0.04)]">
            <Loader2 className="w-6 h-6 animate-spin text-[#78553B] mx-auto mb-2" />
            <p className="text-sm text-[#7C6E65]">Loading inventory items...</p>
          </div>
        )}
        {error && (
          <div className="mx-4 mt-4 bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-600">
            {error.message}
          </div>
        )}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-[#FAFAF8] text-[#A8A29E]">
                <th className="text-left py-3 px-4 text-[11px] uppercase tracking-wider font-medium">SKU</th>
                <th className="text-left py-3 px-4 text-[11px] uppercase tracking-wider font-medium">Item Name</th>
                <th className="text-left py-3 px-4 text-[11px] uppercase tracking-wider font-medium">Category</th>
                <th className="text-left py-3 px-4 text-[11px] uppercase tracking-wider font-medium">Unit</th>
                <th className="text-right py-3 px-4 text-[11px] uppercase tracking-wider font-medium">Stock</th>
                <th className="text-right py-3 px-4 text-[11px] uppercase tracking-wider font-medium">Reorder</th>
                <th className="text-right py-3 px-4 text-[11px] uppercase tracking-wider font-medium">Unit Cost</th>
                <th className="text-center py-3 px-4 text-[11px] uppercase tracking-wider font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((item, idx) => {
                const isLow = item.stockQuantity > 0 && item.stockQuantity <= item.reorderLevel;
                const isOut = item.stockQuantity === 0;
                const catColor = categoryColors[item.category] ?? 'bg-gray-50 text-gray-600';

                return (
                  <motion.tr
                    key={item._id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: idx * 0.015 }}
                    className="border-t border-[rgba(0,0,0,0.04)] hover:bg-[#FAFAF8] transition-colors"
                  >
                    <td className="py-3 px-4 font-mono text-xs text-[#57534E]">{item.skuCode}</td>
                    <td className="py-3 px-4 text-[#1C1917] font-medium">{item.itemName}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-medium ${catColor}`}>
                        {item.category}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-[#57534E]">{item.unit}</td>
                    <td className="py-3 px-4 text-right">
                      <span
                        className={`inline-flex items-center gap-1 font-semibold tabular-nums ${
                          isOut
                            ? 'text-red-500'
                            : isLow
                              ? 'text-amber-600'
                              : 'text-[#1C1917]'
                        }`}
                      >
                        {isOut && <AlertTriangle className="w-3 h-3" />}
                        {isLow && !isOut && <AlertTriangle className="w-3 h-3" />}
                        {item.stockQuantity}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right text-[#A8A29E] tabular-nums">{item.reorderLevel}</td>
                    <td className="py-3 px-4 text-right text-[#78553B] tabular-nums">₱{item.unitCost.toFixed(2)}</td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <motion.button
                          whileTap={{ scale: 0.9 }}
                          onClick={() => openEdit(item)}
                          className="p-1.5 rounded-lg bg-[#F5F0EB] text-[#78553B] hover:bg-[#EDE5DB] transition-colors"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </motion.button>
                        <motion.button
                          whileTap={{ scale: 0.9 }}
                          onClick={() => handleDelete(item)}
                          disabled={deleteInventoryMutation.isPending}
                          className="p-1.5 rounded-lg bg-red-50 text-red-400 hover:bg-red-100 hover:text-red-500 transition-colors"
                        >
                          {deleteInventoryMutation.isPending ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Trash2 className="w-3.5 h-3.5" />
                          )}
                        </motion.button>
                      </div>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {!isLoading && !error && filtered.length === 0 && (
          <div className="py-12 text-center">
            <Package className="w-8 h-8 mx-auto text-[#A8A29E]/40 mb-2" />
            <p className="text-sm text-[#7C6E65]">No inventory items found</p>
            <p className="text-xs text-[#A8A29E] mt-1">Try a different search or category</p>
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center px-4"
          >
            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={closeModal} />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white rounded-2xl p-6 w-full max-w-lg shadow-[0_8px_40px_rgba(0,0,0,0.15)] z-10"
              onClick={(e) => e.stopPropagation()}
            >
              <button onClick={closeModal} className="absolute top-4 right-4 text-[#A8A29E] hover:text-[#57534E] transition-colors">
                <X className="w-4 h-4" />
              </button>
              <div className="flex items-center gap-2 mb-5">
                <Package className="w-5 h-5 text-[#D4854A]" />
                <h3 className="text-[#1C1917] text-lg tracking-tight">
                  {editingItem ? 'Edit Item' : 'Add Inventory Item'}
                </h3>
              </div>

              <form
                className="space-y-3"
                onSubmit={handleSubmit}
              >
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[#57534E] text-xs mb-1 block">SKU Code</label>
                    <input
                      type="text"
                      value={form.skuCode}
                      onChange={(e) => updateField('skuCode', e.target.value)}
                      className="w-full bg-[#F7F4F1] border border-[rgba(0,0,0,0.06)] rounded-lg py-2 px-3 text-sm text-[#1C1917] placeholder-[#A8A29E] focus:outline-none focus:ring-2 focus:ring-[#78553B]/20"
                      placeholder="SC-CC-001"
                    />
                  </div>
                  <div>
                    <label className="text-[#57534E] text-xs mb-1 block">Item Name</label>
                    <input
                      type="text"
                      value={form.itemName}
                      onChange={(e) => updateField('itemName', e.target.value)}
                      className="w-full bg-[#F7F4F1] border border-[rgba(0,0,0,0.06)] rounded-lg py-2 px-3 text-sm text-[#1C1917] placeholder-[#A8A29E] focus:outline-none focus:ring-2 focus:ring-[#78553B]/20"
                      placeholder="8oz Paper Cup"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[#57534E] text-xs mb-1 block">Category</label>
                    <select
                      value={form.category}
                      onChange={(e) => updateField('category', e.target.value)}
                      className="w-full bg-[#F7F4F1] border border-[rgba(0,0,0,0.06)] rounded-lg py-2 px-3 text-sm text-[#1C1917] focus:outline-none focus:ring-2 focus:ring-[#78553B]/20"
                    >
                      <option value="">Select category</option>
                      {CATEGORIES.filter((c) => c !== 'All').map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-[#57534E] text-xs mb-1 block">Unit</label>
                    <input
                      type="text"
                      value={form.unit}
                      onChange={(e) => updateField('unit', e.target.value)}
                      className="w-full bg-[#F7F4F1] border border-[rgba(0,0,0,0.06)] rounded-lg py-2 px-3 text-sm text-[#1C1917] placeholder-[#A8A29E] focus:outline-none focus:ring-2 focus:ring-[#78553B]/20"
                      placeholder="pcs, kg, liters..."
                    />
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="text-[#57534E] text-xs mb-1 block">Stock Qty</label>
                    <input
                      type="number"
                      min={0}
                      value={form.stockQuantity}
                      onChange={(e) => updateField('stockQuantity', Number(e.target.value))}
                      className="w-full bg-[#F7F4F1] border border-[rgba(0,0,0,0.06)] rounded-lg py-2 px-3 text-sm text-[#1C1917] focus:outline-none focus:ring-2 focus:ring-[#78553B]/20"
                    />
                  </div>
                  <div>
                    <label className="text-[#57534E] text-xs mb-1 block">Reorder Level</label>
                    <input
                      type="number"
                      min={0}
                      value={form.reorderLevel}
                      onChange={(e) => updateField('reorderLevel', Number(e.target.value))}
                      className="w-full bg-[#F7F4F1] border border-[rgba(0,0,0,0.06)] rounded-lg py-2 px-3 text-sm text-[#1C1917] focus:outline-none focus:ring-2 focus:ring-[#78553B]/20"
                    />
                  </div>
                  <div>
                    <label className="text-[#57534E] text-xs mb-1 block">Unit Cost (₱)</label>
                    <input
                      type="number"
                      min={0}
                      step={0.01}
                      value={form.unitCost}
                      onChange={(e) => updateField('unitCost', Number(e.target.value))}
                      className="w-full bg-[#F7F4F1] border border-[rgba(0,0,0,0.06)] rounded-lg py-2 px-3 text-sm text-[#1C1917] focus:outline-none focus:ring-2 focus:ring-[#78553B]/20"
                    />
                  </div>
                </div>

                <motion.button
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  disabled={isMutating}
                  className="w-full bg-[#78553B] hover:bg-[#5F432E] text-white py-2.5 rounded-xl text-sm flex items-center justify-center gap-2 transition-colors mt-2"
                >
                  {isMutating ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : editingItem ? (
                    <Pencil className="w-4 h-4" />
                  ) : (
                    <Plus className="w-4 h-4" />
                  )}
                  {isMutating ? 'Saving...' : editingItem ? 'Save Changes' : 'Add Item'}
                </motion.button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
