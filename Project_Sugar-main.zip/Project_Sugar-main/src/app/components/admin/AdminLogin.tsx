import { useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router';
import { Eye, EyeOff, LogIn, Coffee } from 'lucide-react';
import { motion } from 'motion/react';
import { useAdminLogin } from '../../../hooks/useAuth';

export function AdminLogin() {
  const [showPass, setShowPass] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const navigate = useNavigate();
  const loginMutation = useAdminLogin();

  const handleLogin = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormError(null);
    try {
      await loginMutation.mutateAsync({
        email,
        password,
      });
      navigate('/admin/dashboard');
    } catch (error) {
      const apiError = error as { message?: string; errors?: Record<string, string[] | undefined> };
      const firstFieldError = apiError.errors
        ? Object.values(apiError.errors).find((messages) => messages?.length)?.[0]
        : null;
      setFormError(firstFieldError ?? apiError.message ?? 'Unable to login');
    }
  };

  return (
    <div className="min-h-screen bg-[#1C1917] flex items-center justify-center px-4 relative overflow-hidden">
      {/* Background coffee atmosphere */}
      {/* Floating coffee beans */}
      {[
        { x: '8%', y: '20%', size: 6, delay: 0, rotate: 30 },
        { x: '85%', y: '15%', size: 5, delay: 0.8, rotate: -25 },
        { x: '12%', y: '80%', size: 7, delay: 1.5, rotate: 50 },
        { x: '78%', y: '75%', size: 4, delay: 0.4, rotate: -40 },
        { x: '50%', y: '8%', size: 5, delay: 1, rotate: 20 },
        { x: '92%', y: '45%', size: 3, delay: 1.8, rotate: -15 },
        { x: '5%', y: '50%', size: 4, delay: 0.6, rotate: 35 },
        { x: '65%', y: '88%', size: 5, delay: 1.2, rotate: -55 },
      ].map((bean, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full bg-[#78553B]"
          style={{
            left: bean.x,
            top: bean.y,
            width: bean.size,
            height: bean.size,
            rotate: bean.rotate,
          }}
          animate={{
            y: [0, -8, 0],
            opacity: [0.05, 0.12, 0.05],
            rotate: [bean.rotate, bean.rotate + 20, bean.rotate],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            delay: bean.delay,
            ease: 'easeInOut',
          }}
        />
      ))}

      {/* Subtle circular glow */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] rounded-full pointer-events-none"
        style={{
          background: 'radial-gradient(circle, rgba(120,85,59,0.06) 0%, transparent 70%)',
        }}
      />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="bg-white rounded-2xl p-7 w-full max-w-sm shadow-[0_8px_40px_rgba(0,0,0,0.2)] space-y-6 relative z-10"
      >
        <div className="text-center space-y-2 relative">
          {/* Steam above logo */}
          <div className="absolute -top-2 left-1/2 -translate-x-1/2 flex gap-2">
            {[0, 1, 2].map(i => (
              <motion.div
                key={i}
                custom={i}
                // variants={steamVariants}
                animate="animate"
                className="w-1 rounded-full bg-[#D4854A]/30"
                style={{ height: 8 }}
              />
            ))}
          </div>
          <img src='Sugar.jpg' alt="Sugar Cafe" className="w-16 h-16 mx-auto object-contain" />
          <h2 className="text-[#1C1917] tracking-tight flex items-center justify-center gap-2">
            Staff Login
            <Coffee className="w-4 h-4 text-[#D4854A]" />
          </h2>
          <p className="text-[#A8A29E] text-sm">SugarFETCH POS Dashboard</p>
        </div>

        <form className="space-y-3" onSubmit={handleLogin}>
          <div>
            <label className="text-[#57534E] text-sm mb-1.5 block">Email or Username</label>
            <input
              type="text"
              placeholder="admin@sugarcafe.com"
              value={email}
              onChange={(event) => {
                if (formError) setFormError(null);
                setEmail(event.target.value);
              }}
              className="w-full bg-[#F7F4F1] border border-[rgba(0,0,0,0.06)] rounded-lg py-2.5 px-3.5 text-sm text-[#1C1917] placeholder-[#A8A29E] focus:outline-none focus:ring-2 focus:ring-[#78553B]/20 focus:border-[#78553B]/30 transition-shadow"
            />
          </div>
          <div>
            <label className="text-[#57534E] text-sm mb-1.5 block">Password</label>
            <div className="relative">
              <input
                type={showPass ? 'text' : 'password'}
                placeholder="Enter password"
                value={password}
                onChange={(event) => {
                  if (formError) setFormError(null);
                  setPassword(event.target.value);
                }}
                className="w-full bg-[#F7F4F1] border border-[rgba(0,0,0,0.06)] rounded-lg py-2.5 px-3.5 pr-10 text-sm text-[#1C1917] placeholder-[#A8A29E] focus:outline-none focus:ring-2 focus:ring-[#78553B]/20 focus:border-[#78553B]/30 transition-shadow"
              />
              <button
                type="button"
                onClick={() => setShowPass(!showPass)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#A8A29E] hover:text-[#7C6E65] transition-colors"
              >
                {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
        

          {formError ? (
            <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
              {formError}
            </p>
          ) : null}

          <motion.button
            whileTap={{ scale: 0.98 }}
            type="submit"
            disabled={loginMutation.isPending}
            className="w-full bg-[#1C1917] hover:bg-[#292524] text-white py-3 rounded-lg flex items-center justify-center gap-2 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
          >
            <LogIn className="w-4 h-4" />
            {loginMutation.isPending ? 'Logging in...' : 'Login'}
          </motion.button>
        </form>

        {/* Coffee ring stain decoration */}
        <div className="flex items-center gap-2 pt-1">
          <div className="h-px flex-1 bg-[rgba(0,0,0,0.05)]" />
          <Coffee className="w-3 h-3 text-[#E7E5E4]" />
          <div className="h-px flex-1 bg-[rgba(0,0,0,0.05)]" />
        </div>
      </motion.div>
    </div>
  );
}
