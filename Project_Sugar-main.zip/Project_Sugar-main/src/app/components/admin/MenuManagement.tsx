import { useMemo, useState } from 'react';
import { Plus, Pencil, Loader2, Coffee, Search, Eye, EyeOff, Package, LayoutGrid, List } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { AddItemMugModal } from './AddItemMugModal';
import { EditItemMugModal } from './EditItemMugModal';
import {
  useMenusQuery,
  useCreateMenuMutation,
  useUpdateMenuMutation,
  resolveMenuImageUrl,
  type MenuItemApi,
  type CreateMenuInput,
  type UpdateMenuInput,
} from '../../../hooks/useMenu';

const categoryColors: Record<string, { bg: string; text: string }> = {
  coffee: { bg: 'bg-amber-50', text: 'text-amber-700' },
  'milk-tea': { bg: 'bg-violet-50', text: 'text-violet-700' },
  desserts: { bg: 'bg-rose-50', text: 'text-rose-700' },
  snacks: { bg: 'bg-emerald-50', text: 'text-emerald-700' },
};

const categoryFilters: { id: string; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'coffee', label: 'Coffee' },
  { id: 'milk-tea', label: 'Milk Tea' },
  { id: 'desserts', label: 'Desserts' },
  { id: 'snacks', label: 'Snacks' },
];

export function MenuManagement() {
  const { data: items = [], isLoading, error } = useMenusQuery();
  const createMenuMutation = useCreateMenuMutation();
  const updateMenuMutation = useUpdateMenuMutation();
  const [showAdd, setShowAdd] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItemApi | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const isMutating = createMenuMutation.isPending || updateMenuMutation.isPending;

  const sortedItems = useMemo(
    () =>
      [...items]
        .filter(item => {
          const matchCategory = activeFilter === 'all' || item.category === activeFilter;
          const matchSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
          return matchCategory && matchSearch;
        })
        .sort((a, b) => a.name.localeCompare(b.name)),
    [items, activeFilter, searchQuery],
  );

  const stats = useMemo(() => {
    const total = items.length;
    const active = items.filter(i => i.available).length;
    const scheduled = items.filter(i => i.availabilityTime?.mode === 'period').length;
    const anytime = items.filter(i => i.availabilityTime?.mode !== 'period').length;
    return { total, active, scheduled, anytime };
  }, [items]);

  const toggleAvailability = async (item: MenuItemApi) => {
    await updateMenuMutation.mutateAsync({
      id: item._id,
      payload: { available: !item.available },
    });
  };

  const saveEdit = async (id: string, payload: UpdateMenuInput) => {
    await updateMenuMutation.mutateAsync({ id, payload });
    setEditingItem(null);
  };

  const addItemFromModal = async (formData: CreateMenuInput) => {
    await createMenuMutation.mutateAsync(formData);
    setShowAdd(false);
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-[#1C1917] tracking-tight text-lg font-semibold">Menu Management</h2>
          <p className="text-[#A8A29E] text-sm mt-0.5">{stats.total} products &middot; {stats.active} active</p>
        </div>
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => setShowAdd(true)}
          disabled={isMutating}
          className="bg-gradient-to-r from-[#78553B] to-[#D4854A] text-white px-5 py-2.5 rounded-xl flex items-center gap-2 hover:shadow-lg hover:shadow-[#D4854A]/20 transition-all text-sm font-medium shrink-0"
        >
          {createMenuMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
          {createMenuMutation.isPending ? 'Adding...' : 'Add Item'}
        </motion.button>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Total Items', value: stats.total, color: 'bg-[#78553B]/10 text-[#78553B]', icon: Coffee },
          { label: 'Active', value: stats.active, color: 'bg-emerald-50 text-emerald-600', icon: Eye },
          { label: 'Scheduled', value: stats.scheduled, color: 'bg-amber-50 text-amber-600', icon: Package },
          { label: 'Anytime', value: stats.anytime, color: 'bg-violet-50 text-violet-600', icon: EyeOff },
        ].map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className="bg-white rounded-xl border border-[rgba(0,0,0,0.04)] p-3.5 flex items-center gap-3"
            >
              <div className={`w-9 h-9 rounded-lg ${stat.color} flex items-center justify-center shrink-0`}>
                <Icon className="w-4 h-4" />
              </div>
              <div>
                <p className="text-lg font-semibold text-[#1C1917] leading-tight">{stat.value}</p>
                <p className="text-[10px] text-[#A8A29E] uppercase tracking-wide">{stat.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A8A29E]" />
          <input
            type="text"
            placeholder="Search menu items..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-white border border-[rgba(0,0,0,0.06)] rounded-xl py-2.5 pl-10 pr-4 text-sm text-[#1C1917] placeholder-[#C7BBB1] focus:outline-none focus:ring-2 focus:ring-[#78553B]/20 focus:border-[#78553B]/30 transition-shadow"
          />
        </div>
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
            {categoryFilters.map(cat => (
              <button
                key={cat.id}
                onClick={() => setActiveFilter(cat.id)}
                className={`shrink-0 px-3.5 py-2 rounded-lg text-xs font-medium transition-all ${
                  activeFilter === cat.id
                    ? 'bg-[#78553B] text-white shadow-sm'
                    : 'bg-white text-[#7C6E65] border border-[rgba(0,0,0,0.06)] hover:border-[rgba(0,0,0,0.12)]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
          <div className="flex bg-white border border-[rgba(0,0,0,0.06)] rounded-lg p-0.5 shrink-0">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-md transition-all ${
                viewMode === 'grid'
                  ? 'bg-[#78553B] text-white shadow-sm'
                  : 'text-[#A8A29E] hover:text-[#7C6E65]'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-md transition-all ${
                viewMode === 'list'
                  ? 'bg-[#78553B] text-white shadow-sm'
                  : 'text-[#A8A29E] hover:text-[#7C6E65]'
              }`}
            >
              <List className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Add Item Modal */}
      <AnimatePresence>
        {showAdd && (
          <AddItemMugModal onClose={() => setShowAdd(false)} onAdd={addItemFromModal} />
        )}
      </AnimatePresence>

      {/* Edit Item Modal */}
      <AnimatePresence>
        {editingItem && (
          <EditItemMugModal
            item={editingItem}
            onClose={() => setEditingItem(null)}
            onSave={saveEdit}
          />
        )}
      </AnimatePresence>

      {isLoading && (
        <div className="bg-white rounded-xl border border-[rgba(0,0,0,0.04)] p-8 text-center">
          <Loader2 className="w-6 h-6 animate-spin text-[#78553B] mx-auto mb-2" />
          <p className="text-sm text-[#7C6E65]">Loading menu items...</p>
        </div>
      )}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-600">
          {error.message}
        </div>
      )}

      {/* Empty State */}
      {!isLoading && !error && sortedItems.length === 0 && items.length === 0 && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl border border-[rgba(0,0,0,0.04)] shadow-[0_1px_3px_rgba(0,0,0,0.04)] py-16 px-6 flex flex-col items-center text-center"
        >
          <div className="relative mb-6">
            <motion.div
              animate={{ rotate: [0, -6, 6, -3, 0] }}
              transition={{ duration: 3, repeat: Infinity, repeatDelay: 4 }}
              className="w-20 h-20 rounded-2xl bg-[#F5F0EB] flex items-center justify-center"
            >
              <Coffee className="w-9 h-9 text-[#D4854A]" />
            </motion.div>
            <motion.div
              className="absolute -top-3 left-1/2 -translate-x-1/2 flex gap-1.5"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
            >
              {[0, 1, 2].map((i) => (
                <motion.div
                  key={i}
                  className="w-1 h-3 rounded-full bg-[#D4854A]/25"
                  animate={{ y: [-2, -14, -2], opacity: [0, 0.6, 0] }}
                  transition={{ duration: 1.8, repeat: Infinity, delay: i * 0.35, ease: 'easeOut' }}
                />
              ))}
            </motion.div>
          </div>
          <h3 className="text-[#1C1917] text-lg tracking-tight mb-1">No items on the menu yet</h3>
          <p className="text-[#A8A29E] text-sm max-w-xs mb-6">
            Brew your first product and it will appear here. Start by adding a coffee, milk tea, or snack.
          </p>
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => setShowAdd(true)}
            className="bg-gradient-to-r from-[#78553B] to-[#D4854A] text-white px-6 py-2.5 rounded-xl text-sm flex items-center gap-2 shadow-lg shadow-[#D4854A]/15 hover:shadow-[#D4854A]/25 transition-shadow"
          >
            <Plus className="w-4 h-4" />
            Brew First Item
          </motion.button>
        </motion.div>
      )}

      {/* No results for filter */}
      {!isLoading && !error && sortedItems.length === 0 && items.length > 0 && (
        <div className="bg-white rounded-xl border border-[rgba(0,0,0,0.04)] p-8 text-center">
          <Search className="w-8 h-8 text-[#A8A29E]/40 mx-auto mb-2" />
          <p className="text-sm text-[#7C6E65]">No items match your search</p>
          <p className="text-xs text-[#A8A29E] mt-1">Try a different keyword or category</p>
        </div>
      )}

      {/* Product Grid */}
      {sortedItems.length > 0 && viewMode === 'grid' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {sortedItems.map((item, index) => {
            const catColor = categoryColors[item.category] ?? { bg: 'bg-gray-50', text: 'text-gray-600' };

            return (
              <motion.div
                key={item._id}
                layout
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2, delay: index * 0.03 }}
                className={`group bg-white rounded-2xl border overflow-hidden transition-all hover:shadow-md ${
                  !item.available
                    ? 'border-[rgba(0,0,0,0.06)] opacity-60'
                    : 'border-[rgba(0,0,0,0.04)]'
                }`}
              >
                <div className="relative aspect-square bg-[#F5F0EB] overflow-hidden">
                  <ImageWithFallback
                    src={resolveMenuImageUrl(item.image)}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-2.5 left-2.5 flex gap-1.5">
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-medium ${catColor.bg} ${catColor.text}`}>
                      {item.category.replace('-', ' ')}
                    </span>
                  </div>
                  <div className="absolute top-2.5 right-2.5">
                    <button
                      onClick={() => toggleAvailability(item)}
                      disabled={updateMenuMutation.isPending}
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-medium backdrop-blur-sm transition-colors ${
                        item.available ? 'bg-emerald-500/90 text-white' : 'bg-red-500/90 text-white'
                      }`}
                    >
                      {item.available ? 'Active' : 'Disabled'}
                    </button>
                  </div>
                </div>
                <div className="p-4">
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <h4 className="text-[#1C1917] font-medium text-sm truncate flex-1">{item.name}</h4>
                    <span className="text-[#78553B] font-semibold text-sm shrink-0">&#8369;{item.price}</span>
                  </div>
                  <p className="text-[#A8A29E] text-xs line-clamp-2 mb-3 leading-relaxed">{item.description}</p>
                  <div className="flex items-center justify-between mb-3">
                    <span className={`text-[10px] px-2 py-0.5 rounded-md ${
                      item.availabilityTime?.mode === 'period'
                        ? 'text-[#A8A29E] bg-[#F5F0EB]'
                        : 'text-emerald-600 bg-emerald-50'
                    }`}>
                      {item.availabilityTime?.mode === 'period'
                        ? `${item.availabilityTime.startTime} - ${item.availabilityTime.endTime}`
                        : 'Anytime'}
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <motion.button
                      whileTap={{ scale: 0.95 }}
                      onClick={() => setEditingItem(item)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-medium bg-[#F5F0EB] text-[#78553B] hover:bg-[#EDE5DB] transition-colors"
                    >
                      <Pencil className="w-3 h-3" />
                      Edit
                    </motion.button>
                    <motion.button
                      whileTap={{ scale: 0.95 }}
                      onClick={() => toggleAvailability(item)}
                      disabled={updateMenuMutation.isPending}
                      className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-medium transition-colors ${
                        item.available
                          ? 'bg-red-50 text-red-500 hover:bg-red-100'
                          : 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100'
                      }`}
                    >
                      {item.available ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      {item.available ? 'Disable' : 'Enable'}
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Product List */}
      {sortedItems.length > 0 && viewMode === 'list' && (
        <div className="bg-white rounded-2xl border border-[rgba(0,0,0,0.04)] overflow-hidden divide-y divide-[rgba(0,0,0,0.04)]">
          {sortedItems.map((item, index) => {
            const catColor = categoryColors[item.category] ?? { bg: 'bg-gray-50', text: 'text-gray-600' };

            return (
              <motion.div
                key={item._id}
                layout
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.15, delay: index * 0.02 }}
                className={`flex items-center gap-4 p-4 hover:bg-[#FAFAF8] transition-colors ${
                  !item.available ? 'opacity-50' : ''
                }`}
              >
                {/* Thumbnail */}
                <div className="relative w-14 h-14 rounded-xl bg-[#F5F0EB] overflow-hidden shrink-0">
                  <ImageWithFallback
                    src={resolveMenuImageUrl(item.image)}
                    alt={item.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <h4 className="text-[#1C1917] font-medium text-sm truncate">{item.name}</h4>
                    <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-medium ${catColor.bg} ${catColor.text} shrink-0`}>
                      {item.category.replace('-', ' ')}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-xs">
                    <span className="text-[#78553B] font-semibold">&#8369;{item.price}</span>
                    <span className="text-[#D4D0CC]">&middot;</span>
                    <span className={`${
                      item.availabilityTime?.mode === 'period' ? 'text-[#A8A29E]' : 'text-emerald-600'
                    }`}>
                      {item.availabilityTime?.mode === 'period'
                        ? `${item.availabilityTime.startTime} - ${item.availabilityTime.endTime}`
                        : 'Anytime'}
                    </span>
                  </div>
                </div>

                {/* Status */}
                <button
                  onClick={() => toggleAvailability(item)}
                  disabled={updateMenuMutation.isPending}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-colors shrink-0 ${
                    item.available
                      ? 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100'
                      : 'bg-red-50 text-red-500 hover:bg-red-100'
                  }`}
                >
                  {item.available ? 'Active' : 'Disabled'}
                </button>

                {/* Edit */}
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  onClick={() => setEditingItem(item)}
                  className="p-2 rounded-lg bg-[#F5F0EB] text-[#78553B] hover:bg-[#EDE5DB] transition-colors shrink-0"
                >
                  <Pencil className="w-3.5 h-3.5" />
                </motion.button>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
