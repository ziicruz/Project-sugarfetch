import { DollarSign, Users, ShoppingBag, Package, Shield } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { motion } from 'motion/react';
import { salesData } from '../../data/mock-data';

const statCards = [
  { label: 'Total Revenue', value: '₱128,450', icon: DollarSign, iconBg: 'bg-emerald-50', iconColor: 'text-emerald-600' },
  { label: 'Active Admins', value: '4', icon: Users, iconBg: 'bg-blue-50', iconColor: 'text-blue-600' },
  { label: 'Total Orders', value: '312', icon: ShoppingBag, iconBg: 'bg-amber-50', iconColor: 'text-amber-600' },
  { label: 'Low Stock Items', value: '5', icon: Package, iconBg: 'bg-red-50', iconColor: 'text-red-500' },
];

const adminPerformance = [
  { name: 'Admin A', sales: 32450 },
  { name: 'Admin B', sales: 28200 },
  { name: 'Admin C', sales: 41300 },
  { name: 'Admin D', sales: 26500 },
];

export function SuperAdminDashboard() {
  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2">
        <h2 className="text-[#1C1917] tracking-tight">Super Admin Dashboard</h2>
        <motion.div
          animate={{ rotate: [0, -8, 8, -4, 0] }}
          transition={{ duration: 2, repeat: Infinity, repeatDelay: 5 }}
        >
          <Shield className="w-4 h-4 text-[#D4854A]" />
        </motion.div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {statCards.map((card, idx) => {
          const Icon = card.icon;
          return (
            <motion.div
              key={card.label}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="bg-white rounded-xl p-4 shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)]"
            >
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${card.iconBg} ${card.iconColor} mb-3`}>
                <Icon className="w-[18px] h-[18px]" />
              </div>
              <p className="text-[#A8A29E] text-xs">{card.label}</p>
              <p className="text-[#1C1917] text-xl mt-0.5">{card.value}</p>
            </motion.div>
          );
        })}
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="bg-white rounded-xl p-5 shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)]">
          <h3 className="text-[#1C1917] text-sm mb-4">Overall Sales Today</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={salesData.daily}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.04)" vertical={false} />
                <XAxis dataKey="time" tick={{ fill: '#A8A29E', fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#A8A29E', fontSize: 12 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid rgba(0,0,0,0.06)', boxShadow: '0 4px 12px rgba(0,0,0,0.06)', fontSize: '13px' }} />
                <Bar dataKey="sales" fill="#D4854A" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)]">
          <h3 className="text-[#1C1917] text-sm mb-4">Sales per Admin</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={adminPerformance} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.04)" horizontal={false} />
                <XAxis type="number" tick={{ fill: '#A8A29E', fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis dataKey="name" type="category" tick={{ fill: '#A8A29E', fontSize: 12 }} axisLine={false} tickLine={false} width={70} />
                <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid rgba(0,0,0,0.06)', boxShadow: '0 4px 12px rgba(0,0,0,0.06)', fontSize: '13px' }} />
                <Bar dataKey="sales" fill="#1C1917" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
