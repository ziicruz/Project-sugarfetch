import { useState, type FormEvent } from 'react';
import { UserPlus, Users, DollarSign, Eye, EyeOff, X, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAdminRegister, useAdminsQuery } from '../../../hooks/useAuth';

export function AdminManagement() {
  const { data: admins = [], isLoading, error } = useAdminsQuery();
  const [showModal, setShowModal] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);
  const registerMutation = useAdminRegister();

  const [form, setForm] = useState({
    f_name: '',
    m_name: '',
    l_name: '',
    email: '',
    password: '',
  });

  const updateField = (field: string, value: string) => {
    if (formError) setFormError(null);
    if (formSuccess) setFormSuccess(null);
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleCreate = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormError(null);
    setFormSuccess(null);
    try {
      await registerMutation.mutateAsync(form);
      setFormSuccess('Admin created successfully');
      setForm({ f_name: '', m_name: '', l_name: '', email: '', password: '' });
      setTimeout(() => setShowModal(false), 1200);
    } catch (error) {
      const apiError = error as { message?: string; errors?: Record<string, string[] | undefined> };
      const firstFieldError = apiError.errors
        ? Object.values(apiError.errors).find((msgs) => msgs?.length)?.[0]
        : null;
      setFormError(firstFieldError ?? apiError.message ?? 'Failed to create admin');
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <h2 className="text-[#1C1917] tracking-tight">Admin Management</h2>
          <Users className="w-4 h-4 text-[#D4854A]" />
        </div>
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => { setShowModal(true); setFormError(null); setFormSuccess(null); }}
          className="bg-[#D4854A] hover:bg-[#c07a43] text-white px-4 py-2 rounded-lg text-sm flex items-center gap-2 transition-colors"
        >
          <UserPlus className="w-4 h-4" />
          Create Admin
        </motion.button>
      </div>

      <div className="bg-white rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)] overflow-hidden">
        {isLoading && (
          <div className="p-6 text-center border-b border-[rgba(0,0,0,0.04)]">
            <Loader2 className="w-5 h-5 animate-spin text-[#D4854A] mx-auto mb-2" />
            <p className="text-sm text-[#7C6E65]">Loading admins...</p>
          </div>
        )}
        {error && (
          <div className="m-4 bg-red-50 border border-red-200 rounded-lg px-3 py-2 text-sm text-red-600">{error.message}</div>
        )}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-[#FAFAF8] text-[#A8A29E]">
                <th className="text-left py-3 px-4 text-xs uppercase tracking-wide">Name</th>
                <th className="text-left py-3 px-4 text-xs uppercase tracking-wide">Email</th>
                <th className="text-right py-3 px-4 text-xs uppercase tracking-wide">Total Sales</th>
              </tr>
            </thead>
            <tbody>
              {admins.map(admin => (
                <tr key={admin._id} className="border-t border-[rgba(0,0,0,0.04)]">
                  <td className="py-3 px-4 text-[#1C1917]">{admin.f_name} {admin.m_name}. {admin.l_name}</td>
                  <td className="py-3 px-4 text-[#57534E]">{admin.email}</td>
                  <td className="py-3 px-4 text-right">
                    <span className="inline-flex items-center gap-1 text-[#78553B]">
                      <DollarSign className="w-3.5 h-3.5" />
                      ₱{admin.totalSales.toLocaleString()}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!isLoading && !error && admins.length === 0 && (
          <div className="p-8 text-center text-sm text-[#7C6E65]">No admins found.</div>
        )}
      </div>

      {/* Create Admin Modal */}
      <AnimatePresence>
        {showModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center px-4"
          >
            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setShowModal(false)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white rounded-2xl p-6 w-full max-w-md shadow-[0_8px_40px_rgba(0,0,0,0.15)] z-10"
            >
              <button onClick={() => setShowModal(false)} className="absolute top-4 right-4 text-[#A8A29E] hover:text-[#57534E] transition-colors">
                <X className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-2 mb-5">
                <UserPlus className="w-5 h-5 text-[#D4854A]" />
                <h3 className="text-[#1C1917] text-lg tracking-tight">Create New Admin</h3>
              </div>

              <form className="space-y-3" onSubmit={handleCreate}>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="text-[#57534E] text-xs mb-1 block">First Name</label>
                    <input
                      type="text" value={form.f_name} onChange={(e) => updateField('f_name', e.target.value)}
                      className="w-full bg-[#F7F4F1] border border-[rgba(0,0,0,0.06)] rounded-lg py-2 px-3 text-sm text-[#1C1917] placeholder-[#A8A29E] focus:outline-none focus:ring-2 focus:ring-[#D4854A]/20"
                      placeholder="Juan"
                    />
                  </div>
                  <div>
                    <label className="text-[#57534E] text-xs mb-1 block">Middle Name</label>
                    <input
                      type="text" value={form.m_name} onChange={(e) => updateField('m_name', e.target.value)}
                      className="w-full bg-[#F7F4F1] border border-[rgba(0,0,0,0.06)] rounded-lg py-2 px-3 text-sm text-[#1C1917] placeholder-[#A8A29E] focus:outline-none focus:ring-2 focus:ring-[#D4854A]/20"
                      placeholder="D"
                    />
                  </div>
                  <div>
                    <label className="text-[#57534E] text-xs mb-1 block">Last Name</label>
                    <input
                      type="text" value={form.l_name} onChange={(e) => updateField('l_name', e.target.value)}
                      className="w-full bg-[#F7F4F1] border border-[rgba(0,0,0,0.06)] rounded-lg py-2 px-3 text-sm text-[#1C1917] placeholder-[#A8A29E] focus:outline-none focus:ring-2 focus:ring-[#D4854A]/20"
                      placeholder="Cruz"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[#57534E] text-xs mb-1 block">Email</label>
                  <input
                    type="email" value={form.email} onChange={(e) => updateField('email', e.target.value)}
                    className="w-full bg-[#F7F4F1] border border-[rgba(0,0,0,0.06)] rounded-lg py-2 px-3 text-sm text-[#1C1917] placeholder-[#A8A29E] focus:outline-none focus:ring-2 focus:ring-[#D4854A]/20"
                    placeholder="admin@sugarcafe.com"
                  />
                </div>

                <div>
                  <label className="text-[#57534E] text-xs mb-1 block">Password</label>
                  <div className="relative">
                    <input
                      type={showPass ? 'text' : 'password'} value={form.password} onChange={(e) => updateField('password', e.target.value)}
                      className="w-full bg-[#F7F4F1] border border-[rgba(0,0,0,0.06)] rounded-lg py-2 px-3 pr-10 text-sm text-[#1C1917] placeholder-[#A8A29E] focus:outline-none focus:ring-2 focus:ring-[#D4854A]/20"
                      placeholder="Min 8 characters"
                    />
                    <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#A8A29E] hover:text-[#7C6E65]">
                      {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {formError && (
                  <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{formError}</p>
                )}
                {formSuccess && (
                  <p className="text-sm text-emerald-600 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2">{formSuccess}</p>
                )}

                <motion.button
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  disabled={registerMutation.isPending}
                  className="w-full bg-[#D4854A] hover:bg-[#c07a43] text-white py-2.5 rounded-lg text-sm flex items-center justify-center gap-2 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  <UserPlus className="w-4 h-4" />
                  {registerMutation.isPending ? 'Creating...' : 'Create Admin'}
                </motion.button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
