import { NavLink, Outlet, useNavigate } from 'react-router';
import { LayoutDashboard, Users, FileText, Package, LogOut, Menu, X, Shield } from 'lucide-react';
import { useState } from 'react';

const navItems = [
  { to: '/super-admin/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/super-admin/admins', icon: Users, label: 'Admin Management' },
  { to: '/super-admin/z-read', icon: FileText, label: 'Z-Read' },
  { to: '/super-admin/inventory', icon: Package, label: 'Inventory' },
];

export function SuperAdminLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const navigate = useNavigate();

  const SidebarContent = () => (
    <>
      <div className="flex items-center gap-3 px-5 py-5 border-b border-white/6">
        <div className="w-9 h-9 rounded-lg bg-[#D4854A] flex items-center justify-center shrink-0">
          <Shield className="w-4 h-4 text-white" />
        </div>
        <div>
          <h3 className="text-white text-sm tracking-tight">SugarFETCH</h3>
          <p className="text-[#D4854A]/60 text-xs">Super Admin</p>
        </div>
      </div>
      <nav className="flex-1 py-3 space-y-0.5 px-3">
        {navItems.map(item => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={() => setSidebarOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${
                  isActive
                    ? 'bg-[#D4854A]/15 text-[#D4854A]'
                    : 'text-white/50 hover:bg-white/5 hover:text-white/80'
                }`
              }
            >
              <Icon className="w-[18px] h-[18px]" />
              {item.label}
            </NavLink>
          );
        })}
      </nav>
      <div className="px-3 pb-4">
        <button
          onClick={() => navigate('/super-admin')}
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-white/40 hover:text-white/80 hover:bg-white/5 w-full transition-all"
        >
          <LogOut className="w-[18px] h-[18px]" />
          Logout
        </button>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-[#F5F3F0] flex">
      <aside className="hidden lg:flex w-56 bg-[#0F0D0C] flex-col shrink-0 fixed inset-y-0 left-0 z-30">
        <SidebarContent />
      </aside>

      {sidebarOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <aside className="absolute left-0 top-0 bottom-0 w-56 bg-[#0F0D0C] flex flex-col z-50">
            <button onClick={() => setSidebarOpen(false)} className="absolute top-4 right-4 text-white/40 hover:text-white/80 transition-colors">
              <X className="w-4 h-4" />
            </button>
            <SidebarContent />
          </aside>
        </div>
      )}

      <main className="flex-1 lg:ml-56 min-h-screen">
        <div className="lg:hidden sticky top-0 z-20 bg-[#F5F3F0]/80 backdrop-blur-xl px-4 py-3 flex items-center gap-3 border-b border-[rgba(0,0,0,0.04)]">
          <button onClick={() => setSidebarOpen(true)} className="p-2 rounded-lg bg-white border border-[rgba(0,0,0,0.06)]">
            <Menu className="w-4 h-4 text-[#1C1917]" />
          </button>
          <h3 className="text-[#1C1917] tracking-tight text-sm flex items-center gap-1.5">
            SugarFETCH
            <span className="text-[#D4854A] text-xs bg-[#D4854A]/10 px-1.5 py-0.5 rounded">SA</span>
          </h3>
        </div>
        <div className="p-4 lg:p-6">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
