import { useMemo, useState } from 'react';
import { FileText, Download, Calendar, DollarSign, ShoppingBag, CreditCard, Banknote, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { useOrdersQuery } from '../../../hooks/useOrderManagement';
import { exportAnalyticsReport } from '../../../hooks/useAnalytics';

type ZReadEntry = {
  id: string;
  date: string;
  totalSales: number;
  totalOrders: number;
  cashSales: number;
  gcashSales: number;
  mayaSales: number;
  bankQrSales: number;
  closedBy: string;
};

function formatDateKey(value: string): string {
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function ZReadPage() {
  const { data: orders = [], isLoading, error } = useOrdersQuery();
  const [selected, setSelected] = useState<ZReadEntry | null>(null);
  const [isExporting, setIsExporting] = useState(false);
  const [exportError, setExportError] = useState<string | null>(null);

  const zReadEntries = useMemo(() => {
    const grouped = new Map<string, ZReadEntry>();

    orders.forEach((order) => {
      const key = formatDateKey(order.createdAt);
      const existing = grouped.get(key) ?? {
        id: key,
        date: key,
        totalSales: 0,
        totalOrders: 0,
        cashSales: 0,
        gcashSales: 0,
        mayaSales: 0,
        bankQrSales: 0,
        closedBy: 'System',
      };

      existing.totalSales += order.amount;
      existing.totalOrders += 1;
      if (order.paymentMethod === 'Cash') existing.cashSales += order.amount;
      if (order.paymentMethod === 'GCash') existing.gcashSales += order.amount;
      if (order.paymentMethod === 'Maya') existing.mayaSales += order.amount;
      if (order.paymentMethod === 'Bank QR') existing.bankQrSales += order.amount;

      grouped.set(key, existing);
    });

    return [...grouped.values()].sort((a, b) => b.date.localeCompare(a.date));
  }, [orders]);

  const totalRevenue = zReadEntries.reduce((sum, z) => sum + z.totalSales, 0);
  const totalOrders = zReadEntries.reduce((sum, z) => sum + z.totalOrders, 0);

  const handleExportAll = async () => {
    setExportError(null);
    setIsExporting(true);
    try {
      await exportAnalyticsReport('yearly', { format: 'pdf' });
    } catch (error) {
      const message = (error as { message?: string })?.message ?? 'Failed to export report';
      setExportError(message);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <h2 className="text-[#1C1917] tracking-tight">Z-Read Reports</h2>
          <FileText className="w-4 h-4 text-[#D4854A]" />
        </div>
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={handleExportAll}
          disabled={isExporting}
          className="bg-white border border-[rgba(0,0,0,0.06)] text-[#57534E] px-4 py-2 rounded-lg text-sm flex items-center gap-2 hover:bg-[#FAFAF8] transition-colors"
        >
          {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
          {isExporting ? 'Exporting...' : 'Export All'}
        </motion.button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
        {[
          { label: 'Total Revenue', value: `₱${totalRevenue.toLocaleString()}`, Icon: DollarSign, iconBg: 'bg-emerald-50', iconColor: 'text-emerald-600' },
          { label: 'Total Orders', value: totalOrders, Icon: ShoppingBag, iconBg: 'bg-blue-50', iconColor: 'text-blue-600' },
          { label: 'Reports Generated', value: zReadEntries.length, Icon: FileText, iconBg: 'bg-amber-50', iconColor: 'text-amber-600' },
        ].map((card, idx) => (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className={`bg-white rounded-xl p-4 shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)] ${idx === 2 ? 'col-span-2 lg:col-span-1' : ''}`}
          >
            <div className={`w-9 h-9 rounded-lg ${card.iconBg} ${card.iconColor} flex items-center justify-center mb-2`}>
              <card.Icon className="w-[18px] h-[18px]" />
            </div>
            <p className="text-[#A8A29E] text-xs">{card.label}</p>
            <p className="text-[#1C1917] text-xl">{card.value}</p>
          </motion.div>
        ))}
      </div>

      {exportError && (
        <div className="bg-red-50 border border-red-200 rounded-lg px-3 py-2 text-sm text-red-600">{exportError}</div>
      )}

      {/* Z-Read Table */}
      <div className="bg-white rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)] overflow-hidden">
        {isLoading && (
          <div className="p-6 text-center border-b border-[rgba(0,0,0,0.04)]">
            <Loader2 className="w-5 h-5 animate-spin text-[#D4854A] mx-auto mb-2" />
            <p className="text-sm text-[#7C6E65]">Loading reports...</p>
          </div>
        )}
        {error && (
          <div className="m-4 bg-red-50 border border-red-200 rounded-lg px-3 py-2 text-sm text-red-600">{error.message}</div>
        )}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-[#FAFAF8] text-[#A8A29E]">
                <th className="text-left py-3 px-4 text-xs uppercase tracking-wide">Date</th>
                <th className="text-right py-3 px-4 text-xs uppercase tracking-wide">Total Sales</th>
                <th className="text-right py-3 px-4 text-xs uppercase tracking-wide">Orders</th>
                <th className="text-left py-3 px-4 text-xs uppercase tracking-wide">Closed By</th>
                <th className="text-center py-3 px-4 text-xs uppercase tracking-wide">Details</th>
              </tr>
            </thead>
            <tbody>
              {zReadEntries.map(entry => (
                <tr key={entry.id} className="border-t border-[rgba(0,0,0,0.04)]">
                  <td className="py-3 px-4 text-[#1C1917]">
                    <span className="inline-flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-[#A8A29E]" />
                      {new Date(entry.date).toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' })}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right text-[#78553B] tabular-nums">₱{entry.totalSales.toLocaleString()}</td>
                  <td className="py-3 px-4 text-right text-[#57534E] tabular-nums">{entry.totalOrders}</td>
                  <td className="py-3 px-4 text-[#57534E]">{entry.closedBy}</td>
                  <td className="py-3 px-4 text-center">
                    <button
                      onClick={() => setSelected(selected?.id === entry.id ? null : entry)}
                      className="text-[#D4854A] hover:text-[#c07a43] text-xs underline underline-offset-2 transition-colors"
                    >
                      {selected?.id === entry.id ? 'Hide' : 'View'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!isLoading && !error && zReadEntries.length === 0 && (
          <div className="p-8 text-center text-sm text-[#7C6E65]">No Z-read data available yet.</div>
        )}
      </div>

      {/* Z-Read Detail */}
      {selected && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl p-5 shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-[rgba(0,0,0,0.04)]"
        >
          <h3 className="text-[#1C1917] text-sm mb-4">
            Z-Read Detail — {new Date(selected.date).toLocaleDateString('en-PH', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
          </h3>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { label: 'Cash', value: selected.cashSales, Icon: Banknote, color: 'text-emerald-600 bg-emerald-50' },
              { label: 'GCash', value: selected.gcashSales, Icon: CreditCard, color: 'text-blue-600 bg-blue-50' },
              { label: 'Maya', value: selected.mayaSales, Icon: CreditCard, color: 'text-purple-600 bg-purple-50' },
              { label: 'Bank QR', value: selected.bankQrSales, Icon: CreditCard, color: 'text-amber-600 bg-amber-50' },
            ].map(method => (
              <div key={method.label} className="bg-[#FAFAF8] rounded-lg p-3 border border-[rgba(0,0,0,0.04)]">
                <div className={`w-8 h-8 rounded-md flex items-center justify-center ${method.color} mb-2`}>
                  <method.Icon className="w-4 h-4" />
                </div>
                <p className="text-[#A8A29E] text-xs">{method.label}</p>
                <p className="text-[#1C1917] text-lg tabular-nums">₱{method.value.toLocaleString()}</p>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-3 border-t border-[rgba(0,0,0,0.06)] flex items-center justify-between">
            <span className="text-[#A8A29E] text-sm">Grand Total</span>
            <span className="text-[#1C1917] text-lg tabular-nums">₱{selected.totalSales.toLocaleString()}</span>
          </div>
        </motion.div>
      )}
    </div>
  );
}
