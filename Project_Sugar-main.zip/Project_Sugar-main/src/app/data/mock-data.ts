export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'coffee' | 'milk-tea' | 'desserts' | 'snacks';
  image: string;
  available: boolean;
}

export interface CartItem extends MenuItem {
  quantity: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  tableNumber: number;
  items: CartItem[];
  total: number;
  status: 'received' | 'preparing' | 'ready' | 'completed';
  paymentMethod: string;
  paymentConfirmed: boolean;
  createdAt: string;
}

export const menuItems: MenuItem[] = [
  {
    id: '1',
    name: 'Iced Café Latte',
    description: 'Smooth espresso blended with cold milk and ice. A refreshing classic.',
    price: 145,
    category: 'coffee',
    image: 'https://images.unsplash.com/photo-1709689242523-c6d8027c7499?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpY2VkJTIwY29mZmVlJTIwbGF0dGUlMjBjYWZlfGVufDF8fHx8MTc3MzA2MzczMnww&ixlib=rb-4.1.0&q=80&w=1080',
    available: true,
  },
  {
    id: '2',
    name: 'Cappuccino',
    description: 'Rich espresso topped with steamed milk foam. A warm hug in a cup.',
    price: 135,
    category: 'coffee',
    image: 'https://images.unsplash.com/photo-1643909618082-d916d591c2a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXBwdWNjaW5vJTIwY29mZmVlJTIwYXJ0fGVufDF8fHx8MTc3MzA2MzczM3ww&ixlib=rb-4.1.0&q=80&w=1080',
    available: true,
  },
  {
    id: '3',
    name: 'Matcha Latte',
    description: 'Premium Japanese matcha whisked with creamy milk. Earthy and smooth.',
    price: 160,
    category: 'coffee',
    image: 'https://images.unsplash.com/photo-1638978127697-e4d55e88a6e4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXRjaGElMjBsYXR0ZSUyMGdyZWVuJTIwdGVhfGVufDF8fHx8MTc3MzA0MjYyN3ww&ixlib=rb-4.1.0&q=80&w=1080',
    available: true,
  },
  {
    id: '4',
    name: 'Classic Milk Tea',
    description: 'Traditional milk tea with chewy tapioca pearls. Sweet and satisfying.',
    price: 120,
    category: 'milk-tea',
    image: 'https://images.unsplash.com/photo-1572932759882-bb34c848d1b3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWxrJTIwdGVhJTIwYm9iYSUyMGRyaW5rfGVufDF8fHx8MTc3MzAyNzc3M3ww&ixlib=rb-4.1.0&q=80&w=1080',
    available: true,
  },
  {
    id: '5',
    name: 'Taro Milk Tea',
    description: 'Creamy taro-flavored milk tea with boba pearls. A purple delight.',
    price: 130,
    category: 'milk-tea',
    image: 'https://images.unsplash.com/photo-1572932759882-bb34c848d1b3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWxrJTIwdGVhJTIwYm9iYSUyMGRyaW5rfGVufDF8fHx8MTc3MzAyNzc3M3ww&ixlib=rb-4.1.0&q=80&w=1080',
    available: true,
  },
  {
    id: '6',
    name: 'Strawberry Cheesecake',
    description: 'Creamy cheesecake topped with fresh strawberry glaze.',
    price: 180,
    category: 'desserts',
    image: 'https://images.unsplash.com/photo-1615200961449-0d6d5a818f8e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWZlJTIwZGVzc2VydCUyMGNha2UlMjBzbGljZXxlbnwxfHx8fDE3NzMwNjM3MzJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    available: true,
  },
  {
    id: '7',
    name: 'Chocolate Brownie',
    description: 'Warm, fudgy brownie with a crisp top. Pure chocolate indulgence.',
    price: 120,
    category: 'desserts',
    image: 'https://images.unsplash.com/photo-1570145820259-b5b80c5c8bd6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaG9jb2xhdGUlMjBicm93bmllJTIwZGVzc2VydHxlbnwxfHx8fDE3NzI5ODkwMzV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    available: true,
  },
  {
    id: '8',
    name: 'Butter Croissant',
    description: 'Flaky, golden-baked French croissant. Light and buttery.',
    price: 95,
    category: 'snacks',
    image: 'https://images.unsplash.com/photo-1769138885103-7d6e2c02fae7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWZlJTIwY3JvaXNzYW50JTIwcGFzdHJ5JTIwc25hY2t8ZW58MXx8fHwxNzczMDYzNzMzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    available: true,
  },
  {
    id: '9',
    name: 'Club Sandwich',
    description: 'Triple-decker sandwich with chicken, bacon, lettuce, and tomato.',
    price: 175,
    category: 'snacks',
    image: 'https://images.unsplash.com/photo-1716535232833-a58b93c9b134?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWZlJTIwc2FuZHdpY2glMjBmb29kfGVufDF8fHx8MTc3MzA2MzczNHww&ixlib=rb-4.1.0&q=80&w=1080',
    available: false,
  },
];

export const mockOrders: Order[] = [
  {
    id: 'o1',
    orderNumber: 'SC-0042',
    tableNumber: 3,
    items: [
      { ...menuItems[0], quantity: 2 },
      { ...menuItems[5], quantity: 1 },
    ],
    total: 470,
    status: 'preparing',
    paymentMethod: 'GCash',
    paymentConfirmed: true,
    createdAt: '2026-03-09T09:15:00',
  },
  {
    id: 'o2',
    orderNumber: 'SC-0043',
    tableNumber: 7,
    items: [
      { ...menuItems[3], quantity: 3 },
      { ...menuItems[7], quantity: 2 },
    ],
    total: 550,
    status: 'received',
    paymentMethod: 'Maya',
    paymentConfirmed: false,
    createdAt: '2026-03-09T09:22:00',
  },
  {
    id: 'o3',
    orderNumber: 'SC-0041',
    tableNumber: 1,
    items: [
      { ...menuItems[1], quantity: 1 },
      { ...menuItems[6], quantity: 2 },
    ],
    total: 375,
    status: 'ready',
    paymentMethod: 'GCash',
    paymentConfirmed: true,
    createdAt: '2026-03-09T08:50:00',
  },
  {
    id: 'o4',
    orderNumber: 'SC-0040',
    tableNumber: 5,
    items: [
      { ...menuItems[2], quantity: 1 },
    ],
    total: 160,
    status: 'completed',
    paymentMethod: 'Bank QR',
    paymentConfirmed: true,
    createdAt: '2026-03-09T08:30:00',
  },
];

export const salesData = {
  daily: [
    { time: '8AM', sales: 1200 },
    { time: '9AM', sales: 2400 },
    { time: '10AM', sales: 3100 },
    { time: '11AM', sales: 2800 },
    { time: '12PM', sales: 4200 },
    { time: '1PM', sales: 3800 },
    { time: '2PM', sales: 2600 },
    { time: '3PM', sales: 3400 },
    { time: '4PM', sales: 2900 },
    { time: '5PM', sales: 1800 },
  ],
  weekly: [
    { day: 'Mon', sales: 12400 },
    { day: 'Tue', sales: 15200 },
    { day: 'Wed', sales: 13800 },
    { day: 'Thu', sales: 16500 },
    { day: 'Fri', sales: 19200 },
    { day: 'Sat', sales: 22100 },
    { day: 'Sun', sales: 18700 },
  ],
  monthly: [
    { week: 'Week 1', sales: 85000 },
    { week: 'Week 2', sales: 92000 },
    { week: 'Week 3', sales: 78000 },
    { week: 'Week 4', sales: 96000 },
  ],
  paymentMethods: [
    { name: 'GCash', value: 45 },
    { name: 'Maya', value: 30 },
    { name: 'Bank QR', value: 15 },
    { name: 'Cash', value: 10 },
  ],
  bestSelling: [
    { name: 'Iced Café Latte', sold: 142 },
    { name: 'Classic Milk Tea', sold: 128 },
    { name: 'Cappuccino', sold: 95 },
    { name: 'Butter Croissant', sold: 87 },
    { name: 'Chocolate Brownie', sold: 72 },
  ],
};

export const categories = [
  { id: 'all', label: 'All' },
  { id: 'coffee', label: 'Coffee' },
  { id: 'milk-tea', label: 'Milk Tea' },
  { id: 'desserts', label: 'Desserts' },
  { id: 'snacks', label: 'Snacks' },
];
