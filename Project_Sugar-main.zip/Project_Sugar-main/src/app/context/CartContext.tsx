import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { MenuItem } from '../data/mock-data';

export type DrinkSize = 'Medium' | 'Large';

export type CartAddOn = {
  name: string;
  price: number;
};

export interface CartItem extends MenuItem {
  cartItemId: string;
  quantity: number;
  basePrice: number;
  unitPrice: number;
  size?: DrinkSize;
  addOns: CartAddOn[];
  notes: string;
}

export type AddToCartOptions = {
  qty?: number;
  size?: DrinkSize;
  addOns?: CartAddOn[];
  notes?: string;
  unitPrice?: number;
};

interface CartContextType {
  cart: CartItem[];
  addToCart: (item: MenuItem, options?: AddToCartOptions) => void;
  removeFromCart: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, qty: number) => void;
  clearCart: () => void;
  total: number;
  itemCount: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);
const CART_COOKIE_KEY = 'sugar_cart';
const COOKIE_MAX_AGE_SECONDS = 60 * 60 * 24;

function normalizeCartItem(raw: any): CartItem | null {
  if (!raw || typeof raw !== 'object') return null;
  if (!raw.id || !raw.name) return null;

  const addOns = Array.isArray(raw.addOns)
    ? raw.addOns
      .filter((addOn) => addOn && typeof addOn.name === 'string')
      .map((addOn) => ({
        name: String(addOn.name),
        price: Number(addOn.price) || 0,
      }))
    : [];

  const basePrice = Number(raw.basePrice ?? raw.price) || 0;
  const unitPrice = Number(raw.unitPrice ?? raw.price) || 0;
  const quantity = Math.max(1, Number(raw.quantity) || 1);

  return {
    ...raw,
    cartItemId: String(raw.cartItemId ?? `${raw.id}-${Date.now()}-${Math.round(Math.random() * 1e6)}`),
    quantity,
    basePrice,
    unitPrice,
    size: raw.size === 'Large' || raw.size === 'Medium' ? raw.size : undefined,
    addOns,
    notes: typeof raw.notes === 'string' ? raw.notes : '',
  } as CartItem;
}

function readCartFromCookie(): CartItem[] {
  const encoded = document.cookie
    .split('; ')
    .find((entry) => entry.startsWith(`${CART_COOKIE_KEY}=`))
    ?.split('=')[1];
  if (!encoded) return [];

  try {
    const parsed = JSON.parse(decodeURIComponent(encoded));
    if (!Array.isArray(parsed)) return [];
    return parsed
      .map((item) => normalizeCartItem(item))
      .filter((item): item is CartItem => Boolean(item));
  } catch {
    return [];
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>(() => readCartFromCookie());

  useEffect(() => {
    const serialized = encodeURIComponent(JSON.stringify(cart));
    document.cookie = `${CART_COOKIE_KEY}=${serialized}; Path=/; Max-Age=${COOKIE_MAX_AGE_SECONDS}; SameSite=Strict`;
  }, [cart]);

  const addToCart = (item: MenuItem, options?: AddToCartOptions) => {
    const qty = Math.max(1, options?.qty ?? 1);
    const size = options?.size;
    const addOns = options?.addOns ?? [];
    const notes = (options?.notes ?? '').trim();
    const unitPrice = options?.unitPrice ?? item.price;
    const variantKey = JSON.stringify({
      id: item.id,
      size: size ?? null,
      addOns: addOns
        .map((addOn) => ({ name: addOn.name, price: addOn.price }))
        .sort((a, b) => a.name.localeCompare(b.name)),
      notes,
    });

    setCart(prev => {
      const existing = prev.find((c) => {
        const existingKey = JSON.stringify({
          id: c.id,
          size: c.size ?? null,
          addOns: c.addOns
            .map((addOn) => ({ name: addOn.name, price: addOn.price }))
            .sort((a, b) => a.name.localeCompare(b.name)),
          notes: c.notes,
        });
        return existingKey === variantKey;
      });

      if (existing) {
        return prev.map(c =>
          c.cartItemId === existing.cartItemId
            ? { ...c, quantity: c.quantity + qty }
            : c
        );
      }
      return [
        ...prev,
        {
          ...item,
          cartItemId: `${item.id}-${Date.now()}-${Math.round(Math.random() * 1e6)}`,
          quantity: qty,
          basePrice: item.price,
          unitPrice,
          size,
          addOns,
          notes,
        },
      ];
    });
  };

  const removeFromCart = (cartItemId: string) => setCart(prev => prev.filter(c => c.cartItemId !== cartItemId));

  const updateQuantity = (cartItemId: string, qty: number) => {
    if (qty <= 0) return removeFromCart(cartItemId);
    setCart(prev => prev.map(c => c.cartItemId === cartItemId ? { ...c, quantity: qty } : c));
  };

  const clearCart = () => setCart([]);

  const total = cart.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <CartContext.Provider value={{ cart, addToCart, removeFromCart, updateQuantity, clearCart, total, itemCount }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}
