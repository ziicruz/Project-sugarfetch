import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

const steamVariants = {
  animate: (i: number) => ({
    y: [-2, -18, -30],
    x: [0, i % 2 === 0 ? 4 : -4, i % 2 === 0 ? -2 : 2],
    opacity: [0, 0.7, 0],
    scale: [0.5, 1, 1.3],
    transition: {
      duration: 1.6,
      repeat: Infinity,
      delay: i * 0.35,
      ease: 'easeOut',
    },
  }),
};

const loadingMessages = [
  'Brewing your experience...',
  'Steaming the milk...',
  'Adding a shot of espresso...',
  'Almost ready...',
];

function CoffeeCup() {
  return (
    <div className="relative">
      {/* Steam particles */}
      <div className="absolute -top-8 left-1/2 -translate-x-1/2 flex gap-2.5">
        {[0, 1, 2].map(i => (
          <motion.div
            key={i}
            custom={i}
            variants={steamVariants}
            animate="animate"
            className="w-1.5 rounded-full bg-[#D4854A]/40"
            style={{ height: 10 }}
          />
        ))}
      </div>

      {/* Cup SVG */}
      <svg width="72" height="72" viewBox="0 0 72 72" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Saucer */}
        <ellipse cx="36" cy="62" rx="28" ry="5" fill="#E7E5E4" />
        {/* Cup body */}
        <path
          d="M14 26C14 24.8954 14.8954 24 16 24H52C53.1046 24 54 24.8954 54 26V48C54 54.6274 48.6274 60 42 60H26C19.3726 60 14 54.6274 14 48V26Z"
          fill="#1C1917"
        />
        {/* Coffee liquid */}
        <motion.path
          d="M17 30H51V48C51 52.9706 46.9706 57 42 57H26C21.0294 57 17 52.9706 17 48V30Z"
          fill="#78553B"
          animate={{
            d: [
              'M17 30 Q26 33 34 30 Q42 27 51 30 V48C51 52.97 46.97 57 42 57H26C21.03 57 17 52.97 17 48Z',
              'M17 30 Q26 27 34 30 Q42 33 51 30 V48C51 52.97 46.97 57 42 57H26C21.03 57 17 52.97 17 48Z',
              'M17 30 Q26 33 34 30 Q42 27 51 30 V48C51 52.97 46.97 57 42 57H26C21.03 57 17 52.97 17 48Z',
            ],
          }}
          transition={{ duration: 1.2, repeat: Infinity, ease: 'easeInOut' }}
        />
        {/* Foam / crema top */}
        <motion.ellipse
          cx="34"
          cy="30"
          rx="17"
          ry="2.5"
          fill="#C9A882"
          animate={{
            ry: [2.5, 3, 2.5],
          }}
          transition={{ duration: 1.2, repeat: Infinity, ease: 'easeInOut' }}
        />
        {/* Handle */}
        <path
          d="M54 32H56C59.3137 32 62 34.6863 62 38V40C62 43.3137 59.3137 46 56 46H54"
          stroke="#1C1917"
          strokeWidth="3.5"
          strokeLinecap="round"
          fill="none"
        />
        {/* Latte art hint */}
        <motion.path
          d="M30 32C30 32 32 34 34 32C36 30 38 32 38 32"
          stroke="#F5F0EB"
          strokeWidth="1"
          strokeLinecap="round"
          fill="none"
          opacity={0.5}
          animate={{ opacity: [0.3, 0.6, 0.3] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      </svg>
    </div>
  );
}

function SplashDots() {
  return (
    <div className="flex gap-1.5 mt-1">
      {[0, 1, 2].map(i => (
        <motion.div
          key={i}
          className="w-1.5 h-1.5 rounded-full bg-[#D4854A]"
          animate={{ scale: [1, 1.4, 1], opacity: [0.4, 1, 0.4] }}
          transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.2 }}
        />
      ))}
    </div>
  );
}

export function LoadingScreen({ onFinish }: { onFinish: () => void }) {
  const [msgIdx, setMsgIdx] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const msgTimer = setInterval(() => {
      setMsgIdx(prev => (prev + 1) % loadingMessages.length);
    }, 800);
    return () => clearInterval(msgTimer);
  }, []);

  useEffect(() => {
    const start = Date.now();
    const duration = 3200;
    const tick = () => {
      const elapsed = Date.now() - start;
      const p = Math.min(elapsed / duration, 1);
      setProgress(p);
      if (p < 1) {
        requestAnimationFrame(tick);
      } else {
        setTimeout(onFinish, 300);
      }
    };
    requestAnimationFrame(tick);
  }, [onFinish]);

  return (
    <motion.div
      exit={{ opacity: 0, scale: 1.02 }}
      transition={{ duration: 0.4 }}
      className="fixed inset-0 z-[100] bg-[#FAFAF8] flex flex-col items-center justify-center gap-6"
    >
      {/* Shaking coffee cup */}
      <motion.div
        animate={{
          rotate: [-1.5, 1.5, -2, 2, -1, 1, 0],
          y: [0, -2, 0, -1.5, 0],
        }}
        transition={{
          duration: 0.6,
          repeat: Infinity,
          repeatDelay: 0.3,
          ease: 'easeInOut',
        }}
      >
        <CoffeeCup />
      </motion.div>

      {/* Brand */}
      <div className="text-center space-y-1.5">
        <motion.h1
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-[#1C1917] tracking-tight"
        >
          SugarFETCH
        </motion.h1>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="flex flex-col items-center gap-2"
        >
          <AnimatePresence mode="wait">
            <motion.p
              key={msgIdx}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.2 }}
              className="text-[#A8A29E] text-sm h-5"
            >
              {loadingMessages[msgIdx]}
            </motion.p>
          </AnimatePresence>
          <SplashDots />
        </motion.div>
      </div>

      {/* Progress bar */}
      <motion.div
        initial={{ opacity: 0, width: 0 }}
        animate={{ opacity: 1, width: 160 }}
        transition={{ delay: 0.3 }}
        className="h-1 bg-[#F0EBE6] rounded-full overflow-hidden"
        style={{ width: 160 }}
      >
        <motion.div
          className="h-full bg-gradient-to-r from-[#78553B] to-[#D4854A] rounded-full"
          style={{ width: `${progress * 100}%` }}
        />
      </motion.div>

      {/* Coffee bean decorations */}
      {[
        { x: '12%', y: '18%', rotate: 30, size: 6, delay: 0 },
        { x: '82%', y: '25%', rotate: -20, size: 5, delay: 0.5 },
        { x: '20%', y: '78%', rotate: 45, size: 7, delay: 1 },
        { x: '75%', y: '72%', rotate: -35, size: 5, delay: 0.8 },
        { x: '90%', y: '50%', rotate: 15, size: 4, delay: 0.3 },
      ].map((bean, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full bg-[#78553B]"
          style={{
            left: bean.x,
            top: bean.y,
            width: bean.size,
            height: bean.size,
            rotate: bean.rotate,
          }}
          initial={{ opacity: 0, scale: 0 }}
          animate={{
            opacity: [0, 0.12, 0.08],
            scale: [0, 1, 0.9],
            y: [0, -3, 0],
          }}
          transition={{
            duration: 2.5,
            repeat: Infinity,
            delay: bean.delay,
          }}
        />
      ))}
    </motion.div>
  );
}
