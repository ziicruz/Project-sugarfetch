import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';

export type OrderTimeFilter = 'today' | 'history';
type ApiError = {
  message: string;
  errors?: Record<string, string[] | undefined>;
};

const API_BASE_URL =
  (import.meta as ImportMeta & { env?: { VITE_API_BASE_URL?: string } }).env?.VITE_API_BASE_URL ??
  'http://localhost:3000';

export type OrderApi = {
  _id: string;
  customerName: string;
  orderNumber: string;
  paymentMethod: 'GCash' | 'Maya' | 'Bank QR' | 'Cash';
  amount: number;
  cart: Array<{
    itemId?: string;
    name: string;
    quantity: number;
    price: number;
    size?: 'Medium' | 'Large';
    notes?: string;
    addOns?: Array<{ name: string; price: number }>;
    lineTotal?: number;
  }>;
  proofImage: string;
  status: 'received' | 'preparing' | 'ready' | 'completed';
  paymentConfirmed: boolean;
  createdAt: string;
};

export function resolveOrderProofUrl(pathOrUrl: string): string {
  if (!pathOrUrl) return '';
  if (pathOrUrl.startsWith('http://') || pathOrUrl.startsWith('https://')) return pathOrUrl;
  return `${API_BASE_URL}${pathOrUrl.startsWith('/') ? pathOrUrl : `/${pathOrUrl}`}`;
}

function isToday(dateStr: string): boolean {
  const d = new Date(dateStr);
  const now = new Date();
  return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() && d.getDate() === now.getDate();
}

function getCookieToken(name: string): string | null {
  const token = document.cookie
    .split('; ')
    .find((cookie) => cookie.startsWith(`${name}=`))
    ?.split('=')[1];
  return token ? decodeURIComponent(token) : null;
}

function getAuthToken(): string | null {
  return getCookieToken('admin_token') ?? getCookieToken('super_admin_token');
}

type OrdersQueryOptions = {
  enabled?: boolean;
};

export function useOrdersQuery(options: OrdersQueryOptions = {}) {
  const { enabled = true } = options;
  return useQuery<OrderApi[], ApiError>({
    queryKey: ['orders'],
    enabled,
    staleTime: 2000,
    refetchInterval: 3000,
    refetchIntervalInBackground: true,
    refetchOnWindowFocus: true,
    queryFn: async () => {
      const token = getAuthToken();
      const response = await fetch(`${API_BASE_URL}/orders`, {
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      });

      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw {
          message: body?.message ?? 'Request failed',
          errors: body?.errors,
        } as ApiError;
      }

      const fetchedOrders = body?.orders || body?.payments || body?.data || [];
      return (Array.isArray(fetchedOrders) ? fetchedOrders : []) as OrderApi[];
    },
  });
}

export function useUpdateOrderStatusMutation() {
  const queryClient = useQueryClient();
  return useMutation<OrderApi, ApiError, { id: string; status: OrderApi['status'] }>({
    mutationFn: async ({ id, status }) => {
      const token = getAuthToken();
      const response = await fetch(`${API_BASE_URL}/orders/${id}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ status }),
      });

      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw {
          message: body?.message ?? 'Request failed',
          errors: body?.errors,
        } as ApiError;
      }

      return (body.order || body.payment || body.data) as OrderApi;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['analytics', 'dashboard'] });
      queryClient.invalidateQueries({ queryKey: ['analytics', 'sales'] });
      queryClient.invalidateQueries({ queryKey: ['payments'] });
    },
  });
}

export function useConfirmOrderPaymentMutation() {
  const queryClient = useQueryClient();
  return useMutation<OrderApi, ApiError, { id: string }>({
    mutationFn: async ({ id }) => {
      const token = getAuthToken();
      const response = await fetch(`${API_BASE_URL}/orders/${id}/confirm`, {
        method: 'PATCH',
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      });

      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw {
          message: body?.message ?? 'Request failed',
          errors: body?.errors,
        } as ApiError;
      }

      return (body.order || body.payment || body.data) as OrderApi;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['analytics', 'dashboard'] });
      queryClient.invalidateQueries({ queryKey: ['analytics', 'sales'] });
      queryClient.invalidateQueries({ queryKey: ['payments'] });
    },
  });
}

export function useOrderManagement() {
  const { data: orders = [], isLoading, error } = useOrdersQuery();
  const updateStatusMutation = useUpdateOrderStatusMutation();
  const confirmPaymentMutation = useConfirmOrderPaymentMutation();

  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [timeFilter, setTimeFilter] = useState<OrderTimeFilter>('today');

  const filteredOrders = useMemo(() => {
    let list = orders;
    if (timeFilter === 'today') {
      list = list.filter((o) => isToday(o.createdAt));
    }
    if (statusFilter !== 'all') {
      list = list.filter((o) => o.status === statusFilter);
    }
    return list;
  }, [orders, statusFilter, timeFilter]);

  const selectedOrder = useMemo(
    () => orders.find((order) => order._id === selectedOrderId) ?? filteredOrders[0] ?? null,
    [orders, selectedOrderId, filteredOrders],
  );

  const todayStats = useMemo(() => {
    const todayOrders = orders.filter((o) => isToday(o.createdAt));
    const totalRevenue = todayOrders.reduce((sum, o) => sum + o.amount, 0);
    const pending = todayOrders.filter((o) => o.status === 'received' || o.status === 'preparing').length;
    const completed = todayOrders.filter((o) => o.status === 'completed').length;
    return { count: todayOrders.length, revenue: totalRevenue, pending, completed };
  }, [orders]);

  const isMutating = updateStatusMutation.isPending || confirmPaymentMutation.isPending;

  const updateStatus = (orderId: string, status: OrderApi['status']) =>
    updateStatusMutation.mutateAsync({ id: orderId, status });

  const confirmPayment = (orderId: string) =>
    confirmPaymentMutation.mutateAsync({ id: orderId });

  return {
    orders,
    filteredOrders,
    selectedOrder,
    selectedOrderId,
    setSelectedOrderId,
    statusFilter,
    setStatusFilter,
    timeFilter,
    setTimeFilter,
    todayStats,
    isLoading,
    error,
    isMutating,
    confirmPaymentMutation,
    updateStatus,
    confirmPayment,
  };
}
