import { useQuery } from '@tanstack/react-query';
import type { PaymentApi } from './usePayment';

const API_BASE_URL =
  (import.meta as ImportMeta & { env?: { VITE_API_BASE_URL?: string } }).env?.VITE_API_BASE_URL ??
  'http://localhost:3000';

type ApiError = {
  message: string;
  errors?: Record<string, string[] | undefined>;
};

function getCookieToken(name: string): string | null {
  const token = document.cookie
    .split('; ')
    .find((cookie) => cookie.startsWith(`${name}=`))
    ?.split('=')[1];
  return token ? decodeURIComponent(token) : null;
}

function getAuthToken(): string | null {
  return getCookieToken('admin_token') ?? getCookieToken('super_admin_token');
}

async function fetchWithAuth<T>(url: string): Promise<T> {
  const token = getAuthToken();
  const response = await fetch(url, {
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  });

  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw {
      message: body?.message ?? 'Request failed',
      errors: body?.errors,
    } as ApiError;
  }

  return body.data as T;
}

export type DashboardAnalytics = {
  summary: {
    revenueToday: number;
    ordersToday: number;
    inProgressToday: number;
    completedToday: number;
    bestSeller: string;
    topItems: Array<{ name: string; sold: number }>;
  };
  hourlySales: Array<{ time: string; sales: number }>;
  recentOrders: PaymentApi[];
  alerts: Array<{
    level: 'info' | 'warning';
    title: string;
    message: string;
  }>;
};

export type AnalyticsPeriod = 'daily' | 'weekly' | 'monthly';

export type SalesAnalytics = {
  period: AnalyticsPeriod;
  summary: {
    revenue: number;
    orders: number;
    averagePerOrder: number;
    revenueChange: string;
    orderChange: string;
  };
  revenueSeries: Array<
    | { time: string; sales: number }
    | { day: string; sales: number }
    | { week: string; sales: number }
  >;
  paymentMethods: Array<{ name: string; value: number; count: number }>;
  bestSelling: Array<{ name: string; sold: number }>;
};

export function useDashboardAnalyticsQuery() {
  return useQuery<DashboardAnalytics, ApiError>({
    queryKey: ['analytics', 'dashboard'],
    queryFn: () => fetchWithAuth<DashboardAnalytics>(`${API_BASE_URL}/analytics/dashboard`),
    refetchInterval: 15000,
  });
}

export function useSalesAnalyticsQuery(period: AnalyticsPeriod) {
  return useQuery<SalesAnalytics, ApiError>({
    queryKey: ['analytics', 'sales', period],
    queryFn: () => fetchWithAuth<SalesAnalytics>(`${API_BASE_URL}/analytics/sales?period=${period}`),
  });
}

export type ExportPeriod = 'weekly' | 'monthly' | 'yearly' | 'range';
export type ExportFormat = 'csv' | 'pdf';

export async function exportAnalyticsReport(
  period: ExportPeriod,
  options?: { format?: ExportFormat; range?: { from: string; to: string } },
): Promise<void> {
  const token = getAuthToken();
  const format = options?.format ?? 'csv';
  const range = options?.range;

  const params = new URLSearchParams();
  params.set('format', format);

  if (period === 'range' && range) {
    params.set('from', range.from);
    params.set('to', range.to);
  } else {
    params.set('period', period);
  }

  const url = `${API_BASE_URL}/analytics/export?${params.toString()}`;

  const response = await fetch(url, {
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  });

  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw { message: body?.message ?? 'Export failed' } as ApiError;
  }

  const blob = await response.blob();
  const disposition = response.headers.get('Content-Disposition') ?? '';
  const filenameMatch = disposition.match(/filename="?([^"]+)"?/);
  const fallbackExt = format === 'pdf' ? '.pdf' : '.csv';
  const filename = filenameMatch?.[1] ?? `sugar_cafe_report_${period}${fallbackExt}`;

  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(a.href);
}
