import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  createPaymentSchema,
  type CreatePaymentInput,
} from '../schema/paymentSchema';

const API_BASE_URL =
  (import.meta as ImportMeta & { env?: { VITE_API_BASE_URL?: string } }).env?.VITE_API_BASE_URL ??
  'http://localhost:3000';

type ApiError = {
  message: string;
  errors?: Record<string, string[] | undefined>;
};

function getCookieToken(name: string): string | null {
  const token = document.cookie
    .split('; ')
    .find((cookie) => cookie.startsWith(`${name}=`))
    ?.split('=')[1];
  return token ? decodeURIComponent(token) : null;
}

function getAuthToken(): string | null {
  return getCookieToken('admin_token') ?? getCookieToken('super_admin_token');
}

export type PaymentApi = {
  _id: string;
  customerName: string;
  orderNumber: string;
  paymentMethod: 'GCash' | 'Maya' | 'Bank QR' | 'Cash';
  amount: number;
  cart: Array<{
    itemId?: string;
    name: string;
    quantity: number;
    price: number;
    size?: 'Medium' | 'Large';
    notes?: string;
    addOns?: Array<{ name: string; price: number }>;
    lineTotal?: number;
  }>;
  proofImage: string;
  status: 'received' | 'preparing' | 'ready' | 'completed';
  paymentConfirmed: boolean;
  createdAt: string;
};

type CreatePaymentPayload = CreatePaymentInput & {
  paymentImage?: File | null;
};

export function useCreatePaymentMutation() {
  const queryClient = useQueryClient();
  return useMutation<PaymentApi, ApiError, CreatePaymentPayload>({
    mutationFn: async (payload) => {
      const parsed = createPaymentSchema.safeParse(payload);
      if (!parsed.success) {
        throw {
          message: 'Validation failed',
          errors: parsed.error.flatten().fieldErrors,
        } as ApiError;
      }

      const formData = new FormData();
      formData.append('customerName', parsed.data.customerName);
      formData.append('orderNumber', parsed.data.orderNumber ?? '');
      formData.append('paymentMethod', parsed.data.paymentMethod);
      formData.append('amount', String(parsed.data.amount));
      formData.append('cart', JSON.stringify(parsed.data.cart));
      if (payload.paymentImage instanceof File) {
        formData.append('paymentImage', payload.paymentImage);
      }

      const response = await fetch(`${API_BASE_URL}/payments`, {
        method: 'POST',
        body: formData,
      });

      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw {
          message: body?.message ?? 'Request failed',
          errors: body?.errors,
        } as ApiError;
      }

      return body.payment as PaymentApi;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payments'] });
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['analytics', 'dashboard'] });
      queryClient.invalidateQueries({ queryKey: ['analytics', 'sales'] });
    },
  });
}

export function usePaymentsQuery() {
  return useQuery<PaymentApi[], ApiError>({
    queryKey: ['payments'],
    queryFn: async () => {
      const token = getAuthToken();
      const response = await fetch(`${API_BASE_URL}/payments`, {
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      });

      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw {
          message: body?.message ?? 'Request failed',
          errors: body?.errors,
        } as ApiError;
      }

      return (body?.payments ?? []) as PaymentApi[];
    },
  });
}

export function useTrackPaymentQuery(paymentId: string | null) {
  return useQuery<PaymentApi, ApiError>({
    queryKey: ['payment-track', paymentId],
    enabled: Boolean(paymentId),
    refetchInterval: 5000,
    queryFn: async () => {
      const response = await fetch(`${API_BASE_URL}/payments/track/${paymentId}`);
      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw {
          message: body?.message ?? 'Request failed',
          errors: body?.errors,
        } as ApiError;
      }
      return body.payment as PaymentApi;
    },
  });
}

export function useUpdatePaymentStatusMutation() {
  const queryClient = useQueryClient();
  return useMutation<PaymentApi, ApiError, { id: string; status: PaymentApi['status'] }>({
    mutationFn: async ({ id, status }) => {
      const token = getAuthToken();
      const response = await fetch(`${API_BASE_URL}/payments/${id}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ status }),
      });

      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw {
          message: body?.message ?? 'Request failed',
          errors: body?.errors,
        } as ApiError;
      }
      return body.payment as PaymentApi;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payments'] });
    },
  });
}

export function useConfirmPaymentMutation() {
  const queryClient = useQueryClient();
  return useMutation<PaymentApi, ApiError, { id: string }>({
    mutationFn: async ({ id }) => {
      const token = getAuthToken();
      const response = await fetch(`${API_BASE_URL}/payments/${id}/confirm`, {
        method: 'PATCH',
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      });

      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw {
          message: body?.message ?? 'Request failed',
          errors: body?.errors,
        } as ApiError;
      }
      return body.payment as PaymentApi;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payments'] });
    },
  });
}
