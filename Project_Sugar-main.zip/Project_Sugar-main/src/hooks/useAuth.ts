import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';

import {
  loginSchema,
  registerSchema,
  type LoginInput,
  type RegisterInput,
} from '../schema/authSchema';

const API_BASE_URL =
  (import.meta as ImportMeta & { env?: { VITE_API_BASE_URL?: string } }).env?.VITE_API_BASE_URL ??
  'http://localhost:3000';

type AdminProfile = {
  _id: string;
  f_name: string;
  m_name: string;
  l_name: string;
  email: string;
};

type AuthResponse = {
  message: string;
  token: string;
  admin: AdminProfile;
};

type SuperAdminAuthResponse = {
  message: string;
  token: string;
  superAdmin: AdminProfile;
};

type RegisterResponse = {
  message: string;
  admin: {
    _id: string;
    f_name: string;
    m_name: string;
    l_name: string;
    email: string;
  };
};

export type AdminListItem = {
  _id: string;
  f_name: string;
  m_name: string;
  l_name: string;
  email: string;
  totalSales: number;
};

type ApiError = {
  message: string;
  errors?: Record<string, string[] | undefined>;
};

function setAuthCookie(name: string, token: string): void {
  const maxAgeSeconds = 60 * 60 * 24 * 7;
  document.cookie = `${name}=${encodeURIComponent(token)}; Path=/; Max-Age=${maxAgeSeconds}; SameSite=Strict`;
}

function setUserProfileCookie(name: string, profile: AdminProfile): void {
  const maxAgeSeconds = 60 * 60 * 24 * 7;
  const payload = JSON.stringify({
    f_name: profile.f_name,
    m_name: profile.m_name,
    l_name: profile.l_name,
  });
  document.cookie = `${name}=${encodeURIComponent(payload)}; Path=/; Max-Age=${maxAgeSeconds}; SameSite=Strict`;
}

async function handleRequest<T>(path: string, payload: unknown): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw {
      message: body?.message ?? 'Request failed',
      errors: body?.errors,
    } as ApiError;
  }

  return body as T;
}

function getCookieToken(name: string): string | null {
  const token = document.cookie
    .split('; ')
    .find((cookie) => cookie.startsWith(`${name}=`))
    ?.split('=')[1];
  return token ? decodeURIComponent(token) : null;
}

export function useAdminsQuery() {
  return useQuery<AdminListItem[], ApiError>({
    queryKey: ['admins'],
    queryFn: async () => {
      const token = getCookieToken('super_admin_token');
      const response = await fetch(`${API_BASE_URL}/admins`, {
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      });

      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw {
          message: body?.message ?? 'Request failed',
          errors: body?.errors,
        } as ApiError;
      }

      return (body?.admins ?? []) as AdminListItem[];
    },
  });
}

export function useAdminLogin() {
  return useMutation<AuthResponse, ApiError, LoginInput>({
    mutationFn: async (payload) => {
      const parsed = loginSchema.safeParse(payload);
      if (!parsed.success) {
        throw {
          message: 'Validation failed',
          errors: parsed.error.flatten().fieldErrors,
        } as ApiError;
      }

      const data = await handleRequest<AuthResponse>('/admins/login', parsed.data);
      setAuthCookie('admin_token', data.token);
      setUserProfileCookie('admin_profile', data.admin);
      return data;
    },
  });
}

export function useAdminRegister() {
  const queryClient = useQueryClient();
  return useMutation<RegisterResponse, ApiError, RegisterInput>({
    mutationFn: async (payload) => {
      const parsed = registerSchema.safeParse(payload);
      if (!parsed.success) {
        throw {
          message: 'Validation failed',
          errors: parsed.error.flatten().fieldErrors,
        } as ApiError;
      }

      const token = document.cookie
        .split('; ')
        .find(c => c.startsWith('super_admin_token='))
        ?.split('=')[1];

      const response = await fetch(`${API_BASE_URL}/admins`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${decodeURIComponent(token)}` } : {}),
        },
        body: JSON.stringify(parsed.data),
      });

      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw { message: body?.message ?? 'Request failed', errors: body?.errors } as ApiError;
      }
      return body as RegisterResponse;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admins'] });
    },
  });
}

export function useSuperAdminLogin() {
  return useMutation<SuperAdminAuthResponse, ApiError, LoginInput>({
    mutationFn: async (payload) => {
      const parsed = loginSchema.safeParse(payload);
      if (!parsed.success) {
        throw {
          message: 'Validation failed',
          errors: parsed.error.flatten().fieldErrors,
        } as ApiError;
      }

      const data = await handleRequest<SuperAdminAuthResponse>('/super-admins/login', parsed.data);
      setAuthCookie('super_admin_token', data.token);
      setUserProfileCookie('super_admin_profile', data.superAdmin);
      return data;
    },
  });
}
