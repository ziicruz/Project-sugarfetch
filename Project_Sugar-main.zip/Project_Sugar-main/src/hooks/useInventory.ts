import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  createInventorySchema,
  updateInventorySchema,
  type CreateInventoryInput,
  type UpdateInventoryInput,
} from '../schema/inventorySchema';

const API_BASE_URL =
  (import.meta as ImportMeta & { env?: { VITE_API_BASE_URL?: string } }).env?.VITE_API_BASE_URL ??
  'http://localhost:3000';

type ApiError = {
  message: string;
  errors?: Record<string, string[] | undefined>;
};

export type InventoryItemApi = {
  _id: string;
  skuCode: string;
  itemName: string;
  category: string;
  unit: string;
  stockQuantity: number;
  reorderLevel: number;
  unitCost: number;
  createdAt?: string;
  updatedAt?: string;
};

export type AddOnInventoryItemApi = {
  itemName: string;
  stockQuantity: number;
  updatedAt?: string;
};

function getCookieToken(name: string): string | null {
  const token = document.cookie
    .split('; ')
    .find((cookie) => cookie.startsWith(`${name}=`))
    ?.split('=')[1];
  return token ? decodeURIComponent(token) : null;
}

function getAuthToken(): string | null {
  return getCookieToken('super_admin_token') ?? getCookieToken('admin_token');
}

export function hasAuthToken(): boolean {
  return Boolean(getAuthToken());
}

async function parseResponse<T>(response: Response): Promise<T> {
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw {
      message: body?.message ?? 'Request failed',
      errors: body?.errors,
    } as ApiError;
  }
  return body as T;
}

export function useInventoriesQuery(options?: { enabled?: boolean }) {
  const token = getAuthToken();
  const enabled = options?.enabled ?? Boolean(token);
  return useQuery<InventoryItemApi[], ApiError>({
    queryKey: ['inventories'],
    enabled,
    queryFn: async () => {
      if (!token) {
        return [];
      }
      const response = await fetch(`${API_BASE_URL}/inventories`, {
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      });
      const data = await parseResponse<{ inventories: InventoryItemApi[] }>(response);
      return data.inventories;
    },
  });
}

export function useAddOnInventoryQuery() {
  return useQuery<AddOnInventoryItemApi[], ApiError>({
    queryKey: ['inventories', 'public-add-ons'],
    queryFn: async () => {
      const response = await fetch(`${API_BASE_URL}/inventories/public/add-ons`);
      const data = await parseResponse<{ addOns: AddOnInventoryItemApi[] }>(response);
      return data.addOns;
    },
  });
}

export function useInventoryByIdQuery(id: string | null) {
  return useQuery<InventoryItemApi, ApiError>({
    queryKey: ['inventories', id],
    enabled: Boolean(id),
    queryFn: async () => {
      const token = getAuthToken();
      const response = await fetch(`${API_BASE_URL}/inventories/${id}`, {
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      });
      const data = await parseResponse<{ inventory: InventoryItemApi }>(response);
      return data.inventory;
    },
  });
}

export function useCreateInventoryMutation() {
  const queryClient = useQueryClient();
  return useMutation<InventoryItemApi, ApiError, CreateInventoryInput>({
    mutationFn: async (payload) => {
      const parsed = createInventorySchema.safeParse(payload);
      if (!parsed.success) {
        throw {
          message: 'Validation failed',
          errors: parsed.error.flatten().fieldErrors,
        } as ApiError;
      }

      const token = getAuthToken();
      const response = await fetch(`${API_BASE_URL}/inventories`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(parsed.data),
      });
      const data = await parseResponse<{ inventory: InventoryItemApi }>(response);
      return data.inventory;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['inventories'] });
    },
  });
}

export function useUpdateInventoryMutation() {
  const queryClient = useQueryClient();
  return useMutation<InventoryItemApi, ApiError, { id: string; payload: UpdateInventoryInput }>({
    mutationFn: async ({ id, payload }) => {
      const parsed = updateInventorySchema.safeParse(payload);
      if (!parsed.success) {
        throw {
          message: 'Validation failed',
          errors: parsed.error.flatten().fieldErrors,
        } as ApiError;
      }

      const token = getAuthToken();
      const response = await fetch(`${API_BASE_URL}/inventories/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(parsed.data),
      });
      const data = await parseResponse<{ inventory: InventoryItemApi }>(response);
      return data.inventory;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['inventories'] });
    },
  });
}

export function useDeleteInventoryMutation() {
  const queryClient = useQueryClient();
  return useMutation<{ message: string }, ApiError, { id: string }>({
    mutationFn: async ({ id }) => {
      const token = getAuthToken();
      const response = await fetch(`${API_BASE_URL}/inventories/${id}`, {
        method: 'DELETE',
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      });
      return parseResponse<{ message: string }>(response);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['inventories'] });
    },
  });
}

export async function exportInventoryItemsCsv(): Promise<void> {
  const token = getAuthToken();
  const response = await fetch(`${API_BASE_URL}/inventories/export`, {
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  });

  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw {
      message: body?.message ?? 'Export failed',
      errors: body?.errors,
    } as ApiError;
  }

  const blob = await response.blob();
  const disposition = response.headers.get('Content-Disposition') ?? '';
  const filenameMatch = disposition.match(/filename="?([^\"]+)"?/);
  const filename = filenameMatch?.[1] ?? `inventory_${new Date().toISOString().slice(0, 10)}.csv`;

  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(a.href);
}
