import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { z } from 'zod';

const API_BASE_URL =
  (import.meta as ImportMeta & { env?: { VITE_API_BASE_URL?: string } }).env?.VITE_API_BASE_URL ??
  'http://localhost:3000';

export const menuCategorySchema = z.enum(['coffee', 'milk-tea', 'desserts', 'snacks']);
export type MenuCategory = z.infer<typeof menuCategorySchema>;

export const menuAvailabilitySchema = z.discriminatedUnion('mode', [
  z.object({ mode: z.literal('anytime') }),
  z.object({
    mode: z.literal('period'),
    startTime: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/),
    endTime: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/),
  }),
]);

export type MenuAvailability = z.infer<typeof menuAvailabilitySchema>;

export const createMenuSchema = z.object({
  name: z.string().trim().min(1),
  description: z.string().trim().min(1),
  price: z.number().min(0),
  category: menuCategorySchema,
  image: z.string().optional().default(''),
  available: z.boolean().optional().default(true),
  availabilityTime: menuAvailabilitySchema.optional().default({ mode: 'anytime' }),
});

export type CreateMenuInput = z.infer<typeof createMenuSchema>;

const updateMenuSchema = z.object({
  name: z.string().trim().min(1).optional(),
  description: z.string().trim().min(1).optional(),
  price: z.number().min(0).optional(),
  category: menuCategorySchema.optional(),
  image: z.string().optional(),
  available: z.boolean().optional(),
  availabilityTime: menuAvailabilitySchema.optional(),
});
export type UpdateMenuInput = z.infer<typeof updateMenuSchema>;

export type MenuItemApi = {
  _id: string;
  name: string;
  description: string;
  price: number;
  category: MenuCategory;
  image: string;
  available: boolean;
  availabilityTime: {
    mode: 'anytime' | 'period';
    startTime?: string | null;
    endTime?: string | null;
  };
  isAvailableNow?: boolean;
};

type ApiError = {
  message: string;
  errors?: Record<string, string[] | undefined>;
};

function getCookieToken(name: string): string | null {
  const token = document.cookie
    .split('; ')
    .find((cookie) => cookie.startsWith(`${name}=`))
    ?.split('=')[1];
  return token ? decodeURIComponent(token) : null;
}

function getMenuAuthToken(): string | null {
  return getCookieToken('super_admin_token') ?? getCookieToken('admin_token');
}

export function resolveMenuImageUrl(image: string): string {
  if (!image) return '';
  if (image.startsWith('http://') || image.startsWith('https://') || image.startsWith('data:image')) {
    return image;
  }
  if (image.startsWith('/')) {
    return `${API_BASE_URL}${image}`;
  }
  return image;
}

async function parseResponse<T>(response: Response): Promise<T> {
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw {
      message: body?.message ?? 'Request failed',
      errors: body?.errors,
    } as ApiError;
  }
  return body as T;
}

export function useMenusQuery() {
  return useQuery<MenuItemApi[], ApiError>({
    queryKey: ['menus'],
    queryFn: async () => {
      const response = await fetch(`${API_BASE_URL}/menus`);
      const data = await parseResponse<{ menus: MenuItemApi[] }>(response);
      return data.menus;
    },
  });
}

export function useCreateMenuMutation() {
  const queryClient = useQueryClient();
  return useMutation<MenuItemApi, ApiError, CreateMenuInput>({
    mutationFn: async (payload) => {
      const parsed = createMenuSchema.safeParse(payload);
      if (!parsed.success) {
        throw {
          message: 'Validation failed',
          errors: parsed.error.flatten().fieldErrors,
        } as ApiError;
      }

      const token = getMenuAuthToken();
      const response = await fetch(`${API_BASE_URL}/menus`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(parsed.data),
      });

      const data = await parseResponse<{ menu: MenuItemApi }>(response);
      return data.menu;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['menus'] });
    },
  });
}

export function useUpdateMenuMutation() {
  const queryClient = useQueryClient();
  return useMutation<MenuItemApi, ApiError, { id: string; payload: UpdateMenuInput }>({
    mutationFn: async ({ id, payload }) => {
      const parsed = updateMenuSchema.safeParse(payload);
      if (!parsed.success) {
        throw {
          message: 'Validation failed',
          errors: parsed.error.flatten().fieldErrors,
        } as ApiError;
      }

      const token = getMenuAuthToken();
      const response = await fetch(`${API_BASE_URL}/menus/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(parsed.data),
      });

      const data = await parseResponse<{ menu: MenuItemApi }>(response);
      return data.menu;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['menus'] });
    },
  });
}
