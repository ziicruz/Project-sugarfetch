import { z } from 'zod';

export const paymentMethodSchema = z.enum(['GCash', 'Maya', 'Bank QR', 'Cash']);

export const paymentCartItemSchema = z.object({
  itemId: z.string().optional().default(''),
  name: z.string().trim().min(1, 'Item name is required'),
  quantity: z.number().int().min(1, 'Quantity must be at least 1'),
  price: z.number().min(0, 'Price cannot be negative'),
  size: z.enum(['Medium', 'Large']).optional(),
  notes: z.string().trim().optional().default(''),
  addOns: z.array(z.object({
    name: z.string().trim().min(1),
    price: z.number().min(0),
  })).optional().default([]),
  lineTotal: z.number().min(0).optional(),
});

export const createPaymentSchema = z.object({
  customerName: z.string().trim().min(1, 'Customer name is required'),
  orderNumber: z.string().trim().optional().default(''),
  paymentMethod: paymentMethodSchema,
  amount: z.number().min(0, 'Amount cannot be negative'),
  cart: z.array(paymentCartItemSchema).min(1, 'Cart must have at least one item'),
});

export type PaymentMethod = z.infer<typeof paymentMethodSchema>;
export type PaymentCartItem = z.infer<typeof paymentCartItemSchema>;
export type CreatePaymentInput = z.infer<typeof createPaymentSchema>;
