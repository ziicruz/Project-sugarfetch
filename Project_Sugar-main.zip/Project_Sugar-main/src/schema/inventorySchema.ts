import { z } from 'zod';

export const createInventorySchema = z.object({
  skuCode: z.string().trim().min(1, 'SKU code is required'),
  itemName: z.string().trim().min(1, 'Item name is required'),
  category: z.string().trim().min(1, 'Category is required'),
  unit: z.string().trim().min(1, 'Unit is required'),
  stockQuantity: z.number().min(0, 'Stock quantity cannot be negative').optional().default(0),
  reorderLevel: z.number().min(0, 'Reorder level cannot be negative').optional().default(0),
  unitCost: z.number().min(0, 'Unit cost cannot be negative').optional().default(0),
});

export const updateInventorySchema = z.object({
  skuCode: z.string().trim().min(1, 'SKU code is required').optional(),
  itemName: z.string().trim().min(1, 'Item name is required').optional(),
  category: z.string().trim().min(1, 'Category is required').optional(),
  unit: z.string().trim().min(1, 'Unit is required').optional(),
  stockQuantity: z.number().min(0, 'Stock quantity cannot be negative').optional(),
  reorderLevel: z.number().min(0, 'Reorder level cannot be negative').optional(),
  unitCost: z.number().min(0, 'Unit cost cannot be negative').optional(),
});

export type CreateInventoryInput = z.infer<typeof createInventorySchema>;
export type UpdateInventoryInput = z.infer<typeof updateInventorySchema>;
