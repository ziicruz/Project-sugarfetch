Design a modern, clean, and mobile-first café POS system called SugarFETCH. The system is a QR Code–Based Café Point of Sale, Inventory Management, and Sales Analytics platform for Sugar Café.

The design should follow a modern café aesthetic with a friendly, minimal, and fast ordering experience similar to modern food ordering apps. The UI should feel simple, intuitive, and efficient for both customers and café staff.

Use a warm café-inspired color palette (cream, coffee brown, soft orange, light beige) with rounded components, modern typography, and clean spacing.

The system has two main interfaces:

1. Customer Side (Mobile Web App)

This interface is accessed when a customer scans a QR code on the table.

Design the following screens:

QR Code Menu Landing Page

Café logo and branding

Table number indicator

"Browse Menu" button

Mobile-first layout

Digital Menu Page

Categories (Coffee, Milk Tea, Desserts, Snacks)

Product cards showing:

Product image

Product name

Description

Price

Add to Cart button

Category filter tabs

Floating cart icon

Product Detail Modal/Page

Large product image

Description

Price

Quantity selector

Add to Cart button

Cart Page

List of selected items

Quantity adjustment

Remove item option

Order summary

Total price

Confirm Order button

Order Confirmation Page

Order number

Order summary

Payment options

QR Code Payment Page

Generate a payment QR code supporting:

GCash

Maya

Bank QR

Include:

Order total

Payment instructions

Upload payment proof option (optional)

Order Tracking Page

Show a progress tracker with these stages:

Order Received

Preparing

Ready for Pickup

Completed

Include:

Estimated waiting time

Order number

Items ordered

2. Admin Side (Café Staff Dashboard)

Design a desktop-first POS dashboard for café staff.

Admin Login Screen

Café branding

Email/username

Password

Login button

Admin Dashboard Overview

Show key analytics cards:

Today’s Sales

Total Orders

Best-Selling Item

Low Stock Items

Include:

Sales chart

Recent orders table

Order Management (POS Screen)

This screen should resemble a restaurant POS interface.

Features:

Real-time order list

Order details panel

Order status controls:

Received

Preparing

Ready

Completed

Payment confirmation button

Menu Management

Admin should be able to:

Add new menu items

Edit item details

Upload product images

Enable/disable items

Set price and category

Use a table view with edit buttons.

Inventory Management

Include:

Product stock levels

Automatic stock deduction per order

Low stock indicator

Restock button

Inventory table with:

Item Name

Current Stock

Status (Low/OK)

Sales Analytics

Create a data dashboard showing:

Daily sales

Weekly sales

Monthly sales

Best-selling items

Payment method breakdown

Include:

Bar charts

Line charts

Downloadable report button

Design Requirements

UI Style:

Modern POS interface

Minimalistic layout

Mobile-first for customer side

Dashboard-first for admin side

Components:

Rounded cards

Clear icons

Simple navigation

Fast ordering UX

Typography:

Clean sans-serif fonts

Clear hierarchy

Include:

Empty states

Loading states

Success confirmations

If possible, also include:

Design system

Color palette

Component library

Button styles

Input styles

Card components

Icon set

✅ Deliverables:

Full UI screens

Mobile customer interface

Desktop admin dashboard

Design system

Component variants